package com.civilizationcore.command;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.HallOfFameEntry;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class SeasonCommand implements CommandExecutor, TabCompleter {

    private final CivilizationCore plugin;

    public SeasonCommand(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            info(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "info" -> info(sender);
            case "stats" -> stats(sender);
            case "leaderboard" -> leaderboard(sender, args);
            case "halloffame", "hof" -> hallOfFame(sender);
            default -> sender.sendMessage(ChatColor.RED + "Usage: /season [info|stats|leaderboard|halloffame]");
        }
        return true;
    }

    private void info(CommandSender sender) {
        var season = plugin.getSeasonManager().getCurrentSeason();
        if (season == null) {
            sender.sendMessage(ChatColor.GRAY + "No season data loaded yet.");
            return;
        }
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        sender.sendMessage(ChatColor.GOLD + "Season " + season.getNumber() + " - " + season.getState());
        sender.sendMessage(ChatColor.GRAY + "Started: " + ChatColor.WHITE + fmt.format(new Date(season.getStartDate())));
        if (season.getWinnerCivId() != null) {
            String name = plugin.getCivilizationManager().get(season.getWinnerCivId()).map(Civilization::getName).orElse(season.getWinnerCivId());
            sender.sendMessage(ChatColor.GRAY + "Winner: " + ChatColor.GOLD + name);
        }
    }

    private void stats(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "Season Statistics:");
        for (Civilization civ : plugin.getCivilizationManager().getAll()) {
            sender.sendMessage(plugin.getMessageManager().color(civ.getPrefix()) + ChatColor.WHITE + " " + civ.getName()
                    + ChatColor.GRAY + " - Wars: " + ChatColor.WHITE + civ.getStats().getWarsWon() + "W/" + civ.getStats().getWarsLost() + "L"
                    + ChatColor.GRAY + " Weapons: " + ChatColor.WHITE + plugin.getWeaponManager().getOwnedBy(civ.getId()).size() + "/3"
                    + ChatColor.GRAY + " Treasury: " + ChatColor.WHITE + String.format("%,.0f", civ.getTreasuryBalance()));
        }
    }

    private void leaderboard(CommandSender sender, String[] args) {
        var category = com.civilizationcore.manager.StatisticsManager.parseCategory(args.length > 1 ? args[1] : null);
        var ranking = plugin.getStatisticsManager().leaderboard(category);
        sender.sendMessage(ChatColor.GOLD + "Season Leaderboard - " + category);
        int place = 1;
        for (Civilization civ : ranking) {
            sender.sendMessage(ChatColor.WHITE + "" + place + ". " + plugin.getMessageManager().color(civ.getPrefix()) + " " + civ.getName());
            place++;
        }
    }

    private void hallOfFame(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "\uD83C\uDFDB HALL OF FAME");
        plugin.getStorageManager().loadHallOfFame().thenAccept(entries ->
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    if (entries.isEmpty()) {
                        sender.sendMessage(ChatColor.GRAY + "No seasons have concluded yet.");
                        return;
                    }
                    for (HallOfFameEntry entry : entries) {
                        sender.sendMessage("");
                        sender.sendMessage(ChatColor.WHITE + "Season " + entry.getSeasonNumber());
                        sender.sendMessage(ChatColor.GOLD + "\uD83C\uDFC6 " + entry.getWinnerCivName());
                        if (entry.getLeaderName() != null) {
                            sender.sendMessage("\uD83D\uDC51 " + entry.getLeaderName());
                        }
                    }
                }));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("info", "stats", "leaderboard", "halloffame").stream()
                    .filter(o -> o.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("leaderboard")) {
            return List.of("wars", "wealth", "members", "weapons", "events", "overall").stream()
                    .filter(o -> o.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
}
