package com.civilizationcore.command;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.CivPlayer;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.Map;

/** Handles /civ bank, /civ treasury, /civ deposit <amount>, /civ withdraw <amount>. */
public class EconomySubcommand {

    private final CivilizationCore plugin;

    public EconomySubcommand(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    private Civilization requireCiv(Player player, CivPlayer cp) {
        if (cp == null || !cp.hasCivilization()) {
            plugin.getMessageManager().sendRaw(player, "&cYou must belong to a civilization for treasury commands.");
            return null;
        }
        return plugin.getCivilizationManager().get(cp.getCivilizationId()).orElse(null);
    }

    public void showBalance(Player player) {
        CivPlayer cp = plugin.getPlayerManager().get(player.getUniqueId()).orElse(null);
        Civilization civ = requireCiv(player, cp);
        if (civ == null) return;

        plugin.getMessageManager().send(player, "bank-balance", Map.of(
                "civilization", civ.getName(),
                "amount", String.format("%,.2f", civ.getTreasuryBalance())
        ));
    }

    public void showTransactions(Player player) {
        CivPlayer cp = plugin.getPlayerManager().get(player.getUniqueId()).orElse(null);
        Civilization civ = requireCiv(player, cp);
        if (civ == null) return;

        plugin.getStorageManager().loadRecentTransactions(civ.getId(), 10).thenAccept(list ->
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    if (!player.isOnline()) return;
                    player.sendMessage(ChatColor.GOLD + civ.getName() + " Treasury Ledger (last " + list.size() + "):");
                    for (var tx : list) {
                        player.sendMessage(ChatColor.GRAY + "- " + tx.getType() + " " + ChatColor.WHITE
                                + String.format("%,.2f", tx.getAmount()) + ChatColor.GRAY
                                + (tx.getReason() != null ? " (" + tx.getReason() + ")" : ""));
                    }
                }));
    }

    public void deposit(Player player, String[] args) {
        CivPlayer cp = plugin.getPlayerManager().get(player.getUniqueId()).orElse(null);
        Civilization civ = requireCiv(player, cp);
        if (civ == null) return;

        if (!plugin.getEconomyManager().isAvailable()) {
            plugin.getMessageManager().send(player, "economy-unavailable");
            return;
        }
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Usage: /civ deposit <amount>");
            return;
        }
        double amount = parseAmount(args[1]);
        if (amount <= 0) {
            plugin.getMessageManager().send(player, "deposit-invalid-amount");
            return;
        }
        if (!plugin.getEconomyManager().hasEnough(player, amount)) {
            plugin.getMessageManager().send(player, "deposit-insufficient-funds");
            return;
        }

        boolean success = plugin.getEconomyManager().deposit(civ, player, amount, "Player deposit");
        if (success) {
            plugin.getMessageManager().send(player, "deposit-success", Map.of(
                    "amount", String.format("%,.2f", amount), "civilization", civ.getName()));
        } else {
            plugin.getMessageManager().send(player, "economy-unavailable");
        }
    }

    public void withdraw(Player player, String[] args) {
        CivPlayer cp = plugin.getPlayerManager().get(player.getUniqueId()).orElse(null);
        Civilization civ = requireCiv(player, cp);
        if (civ == null) return;

        if (!plugin.getLeaderManager().isLeaderOf(player, civ) && !player.hasPermission("civilization.leader.economy")) {
            plugin.getMessageManager().send(player, "withdraw-no-permission");
            return;
        }
        if (!plugin.getEconomyManager().isAvailable()) {
            plugin.getMessageManager().send(player, "economy-unavailable");
            return;
        }
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Usage: /civ withdraw <amount>");
            return;
        }
        double amount = parseAmount(args[1]);
        if (amount <= 0) {
            plugin.getMessageManager().send(player, "deposit-invalid-amount");
            return;
        }
        if (civ.getTreasuryBalance() < amount) {
            plugin.getMessageManager().send(player, "withdraw-insufficient-treasury");
            return;
        }

        boolean success = plugin.getEconomyManager().withdraw(civ, player, amount, "Leader withdrawal");
        if (success) {
            plugin.getMessageManager().send(player, "withdraw-success", Map.of(
                    "amount", String.format("%,.2f", amount), "civilization", civ.getName()));
        } else {
            plugin.getMessageManager().send(player, "economy-unavailable");
        }
    }

    private double parseAmount(String input) {
        try {
            return Double.parseDouble(input);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
