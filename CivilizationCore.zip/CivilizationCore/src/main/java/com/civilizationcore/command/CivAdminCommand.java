package com.civilizationcore.command;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.CivPlayer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class CivAdminCommand implements CommandExecutor, TabCompleter {

    private final CivilizationCore plugin;

    public CivAdminCommand(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("civilization.admin")) {
            plugin.getMessageManager().send(sender, "no-permission");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage("Usage: /civadmin <assign|remove|setleader|setcapital|reload|debug|election|giveweapon|resetseason>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "assign" -> assign(sender, args);
            case "remove" -> remove(sender, args);
            case "setleader" -> setLeader(sender, args);
            case "setcapital" -> setCapital(sender, args);
            case "reload" -> reload(sender);
            case "debug" -> debug(sender);
            case "election" -> election(sender, args);
            case "giveweapon" -> giveWeapon(sender, args);
            case "resetseason" -> resetSeason(sender, args);
            default -> sender.sendMessage("Usage: /civadmin <assign|remove|setleader|setcapital|reload|debug|election|giveweapon|resetseason>");
        }
        return true;
    }

    private void election(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /civadmin election <start|setwinner> <civilization> [player]");
            return;
        }
        Optional<Civilization> civOpt = plugin.getCivilizationManager().get(args[2]);
        if (civOpt.isEmpty()) {
            plugin.getMessageManager().send(sender, "unknown-civilization", Map.of("civilization", args[2]));
            return;
        }
        Civilization civ = civOpt.get();

        switch (args[1].toLowerCase()) {
            case "start" -> {
                boolean started = plugin.getElectionManager().startElection(civ, sender);
                if (started) {
                    sender.sendMessage("§aStarted an election for " + civ.getName() + ".");
                } else {
                    plugin.getMessageManager().send(sender, "election-already-running", Map.of("civilization", civ.getName()));
                }
            }
            case "setwinner" -> {
                if (args.length < 4) {
                    sender.sendMessage("Usage: /civadmin election setwinner <civilization> <player>");
                    return;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[3]);
                if (target.getUniqueId() == null) {
                    plugin.getMessageManager().send(sender, "player-not-found", Map.of("player", args[3]));
                    return;
                }
                plugin.getElectionManager().adminSetWinner(civ, target.getUniqueId());
                sender.sendMessage("§aSet " + args[3] + " as the winner of " + civ.getName() + "'s election.");
            }
            default -> sender.sendMessage("Usage: /civadmin election <start|setwinner> <civilization> [player]");
        }
    }

    private void assign(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /civadmin assign <player> <civilization>");
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (target.getUniqueId() == null) {
            plugin.getMessageManager().send(sender, "player-not-found", Map.of("player", args[1]));
            return;
        }
        Optional<Civilization> civOpt = plugin.getCivilizationManager().get(args[2]);
        if (civOpt.isEmpty()) {
            plugin.getMessageManager().send(sender, "unknown-civilization", Map.of("civilization", args[2]));
            return;
        }

        CivPlayer cp = plugin.getPlayerManager().getOrEmpty(target.getUniqueId(), target.getName() != null ? target.getName() : args[1]);

        if (target.isOnline()) {
            Player online = target.getPlayer();
            plugin.getAssignmentManager().movePlayer(online, cp, civOpt.get(), false);
        } else {
            // Offline: mutate data directly and persist. No membership-count
            // events fire for offline players since there's no Player object.
            Optional<Civilization> previous = cp.hasCivilization()
                    ? plugin.getCivilizationManager().get(cp.getCivilizationId()) : Optional.empty();
            previous.ifPresent(p -> {
                p.removeMember(target.getUniqueId());
                plugin.getCivilizationManager().save(p);
            });
            cp.setCivilizationId(civOpt.get().getId());
            if (cp.getJoinTimestamp() == 0) cp.setJoinTimestamp(System.currentTimeMillis());
            civOpt.get().addMember(target.getUniqueId());
            plugin.getPlayerManager().save(cp);
            plugin.getCivilizationManager().save(civOpt.get());
        }

        plugin.getMessageManager().send(sender, "admin-assigned", Map.of(
                "player", args[1], "civilization", civOpt.get().getName()));
    }

    private void remove(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("Usage: /civadmin remove <player>");
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        Optional<CivPlayer> cpOpt = plugin.getPlayerManager().get(target.getUniqueId());
        if (cpOpt.isEmpty() || !cpOpt.get().hasCivilization()) {
            plugin.getMessageManager().send(sender, "player-not-found", Map.of("player", args[1]));
            return;
        }
        CivPlayer cp = cpOpt.get();
        plugin.getCivilizationManager().get(cp.getCivilizationId()).ifPresent(civ -> {
            civ.removeMember(target.getUniqueId());
            if (civ.hasLeader() && civ.getLeaderUuid().equals(target.getUniqueId())) {
                plugin.getLeaderManager().clearLeader(civ);
            }
            plugin.getCivilizationManager().save(civ);
        });
        cp.setCivilizationId(null);
        plugin.getPlayerManager().save(cp);

        plugin.getMessageManager().send(sender, "admin-removed", Map.of("player", args[1]));
    }

    private void setLeader(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /civadmin setleader <civilization> <player>");
            return;
        }
        Optional<Civilization> civOpt = plugin.getCivilizationManager().get(args[1]);
        if (civOpt.isEmpty()) {
            plugin.getMessageManager().send(sender, "unknown-civilization", Map.of("civilization", args[1]));
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[2]);
        Player online = target.getPlayer();
        if (online == null) {
            sender.sendMessage("§cThat player must be online to be made a leader (they need to receive the crown).");
            return;
        }
        CivPlayer cp = plugin.getPlayerManager().get(target.getUniqueId()).orElse(null);
        if (cp == null || !civOpt.get().getId().equalsIgnoreCase(cp.getCivilizationId())) {
            sender.sendMessage("§cThat player must be a member of " + civOpt.get().getName() + " first. Use /civadmin assign.");
            return;
        }

        boolean success = plugin.getLeaderManager().setLeader(civOpt.get(), online, cp);
        if (success) {
            plugin.getMessageManager().send(sender, "leader-set", Map.of(
                    "player", online.getName(), "civilization", civOpt.get().getName()));
        } else {
            sender.sendMessage("§cFailed to set leader.");
        }
    }

    private void setCapital(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().send(sender, "player-only");
            return;
        }
        if (args.length < 2) {
            sender.sendMessage("Usage: /civadmin setcapital <civilization>");
            return;
        }
        Optional<Civilization> civOpt = plugin.getCivilizationManager().get(args[1]);
        if (civOpt.isEmpty()) {
            plugin.getMessageManager().send(sender, "unknown-civilization", Map.of("civilization", args[1]));
            return;
        }
        plugin.getCapitalManager().setCapital(civOpt.get(), player.getLocation());
        plugin.getMessageManager().send(sender, "capital-set", Map.of("civilization", civOpt.get().getName()));
    }

    private void giveWeapon(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage("Usage: /civadmin giveweapon <weapon> <civilization> <player>");
            return;
        }
        var weaponOpt = plugin.getWeaponManager().get(args[1]);
        if (weaponOpt.isEmpty()) {
            sender.sendMessage("§cUnknown weapon: " + args[1]);
            return;
        }
        Optional<Civilization> civOpt = plugin.getCivilizationManager().get(args[2]);
        if (civOpt.isEmpty()) {
            plugin.getMessageManager().send(sender, "unknown-civilization", Map.of("civilization", args[2]));
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[3]);
        if (target.getUniqueId() == null) {
            plugin.getMessageManager().send(sender, "player-not-found", Map.of("player", args[3]));
            return;
        }
        plugin.getWeaponManager().adminTransfer(weaponOpt.get(), civOpt.get(), target.getUniqueId());
        sender.sendMessage("§a" + weaponOpt.get().getDisplayName() + " has been transferred to " + civOpt.get().getName() + ".");
    }

    private void resetSeason(CommandSender sender, String[] args) {
        boolean confirmed = args.length >= 2 && args[1].equalsIgnoreCase("confirm");
        if (!confirmed) {
            sender.sendMessage("§cThis will reset weapon ownership, war stats, and civilization points for a new season.");
            sender.sendMessage("§cRun §f/civadmin resetseason confirm §cto proceed.");
            return;
        }
        plugin.getSeasonManager().resetSeason();
        sender.sendMessage("§aSeason has been reset. A new season has begun.");
    }

    private void reload(CommandSender sender) {
        plugin.reload();
        plugin.getMessageManager().send(sender, "reload-complete");
    }

    private void debug(CommandSender sender) {
        sender.sendMessage("§6=== CivilizationCore Debug ===");
        sender.sendMessage("§7Civilizations loaded: §f" + plugin.getCivilizationManager().getAll().size());
        for (Civilization civ : plugin.getCivilizationManager().getAll()) {
            String leader = civ.hasLeader() ? civ.getLeaderUuid().toString() : "none";
            sender.sendMessage(String.format("§7- §f%s §7(id=%s, members=%d, leader=%s, capital=%s)",
                    civ.getName(), civ.getId(), civ.getMemberCount(), leader,
                    civ.hasCapital() ? plugin.getCapitalManager().formatCapital(civ) : "unset"));
        }
        sender.sendMessage("§7Cached players: §f" + plugin.getPlayerManager().getCache().size());
        sender.sendMessage("§7Switching: §f" + plugin.getConfigManager().getSwitchModeRaw()
                + " (enabled=" + plugin.getConfigManager().isSwitchingEnabled() + ")");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("assign", "remove", "setleader", "setcapital", "reload", "debug", "election", "giveweapon", "resetseason"), args[0]);
        }
        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "assign", "remove" -> Bukkit.getOnlinePlayers().stream().map(Player::getName)
                        .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
                case "setleader", "setcapital" -> filter(
                        plugin.getCivilizationManager().getAll().stream().map(Civilization::getId).toList(), args[1]);
                default -> Collections.emptyList();
            };
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("assign")) {
            return filter(plugin.getCivilizationManager().getAll().stream().map(Civilization::getId).toList(), args[2]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setleader")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[2].toLowerCase())).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
