package com.civilizationcore.command;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.CivPlayer;
import com.civilizationcore.model.DiplomacyRequest;
import com.civilizationcore.model.RelationType;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class DiplomacyCommand implements CommandExecutor, TabCompleter {

    private final CivilizationCore plugin;

    public DiplomacyCommand(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    private Civilization requireCiv(Player player) {
        CivPlayer cp = plugin.getPlayerManager().get(player.getUniqueId()).orElse(null);
        if (cp == null || !cp.hasCivilization()) {
            plugin.getMessageManager().sendRaw(player, "&cYou must belong to a civilization.");
            return null;
        }
        return plugin.getCivilizationManager().get(cp.getCivilizationId()).orElse(null);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().send(sender, "player-only");
            return true;
        }
        Civilization civ = requireCiv(player);
        if (civ == null) return true;

        if (args.length == 0) {
            status(player, civ);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "status" -> status(player, civ);
            case "request" -> request(player, civ, args);
            case "accept" -> respond(player, civ, true);
            case "deny" -> respond(player, civ, false);
            case "cancel" -> cancel(player, civ);
            default -> player.sendMessage(ChatColor.RED + "Usage: /diplomacy <status|request|accept|deny|cancel>");
        }
        return true;
    }

    private void status(Player player, Civilization civ) {
        Map<String, RelationType> relations = plugin.getDiplomacyManager().getRelationsFor(civ.getId());
        player.sendMessage(ChatColor.GOLD + civ.getName() + " - Diplomatic Relations:");
        if (relations.isEmpty()) {
            player.sendMessage(ChatColor.GRAY + "No active relationships.");
        }
        for (var entry : relations.entrySet()) {
            var otherCiv = plugin.getCivilizationManager().get(entry.getKey());
            String otherName = otherCiv.map(Civilization::getName).orElse(entry.getKey());
            player.sendMessage(ChatColor.WHITE + otherName + ChatColor.GRAY + ": " + ChatColor.YELLOW + entry.getValue());
        }
    }

    private void request(Player player, Civilization civ, String[] args) {
        if (!plugin.getLeaderManager().isLeaderOf(player, civ) && !player.hasPermission("civilization.leader.diplomacy")) {
            plugin.getMessageManager().send(player, "diplomacy-no-permission");
            return;
        }
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Usage: /diplomacy request <civilization> <type>");
            return;
        }
        Optional<Civilization> targetOpt = plugin.getCivilizationManager().get(args[1]);
        if (targetOpt.isEmpty()) {
            plugin.getMessageManager().send(player, "unknown-civilization", Map.of("civilization", args[1]));
            return;
        }
        Civilization target = targetOpt.get();
        if (target.getId().equalsIgnoreCase(civ.getId())) {
            plugin.getMessageManager().send(player, "diplomacy-cannot-target-self");
            return;
        }
        RelationType type = RelationType.fromString(args[2]);
        if (type == null) {
            plugin.getMessageManager().send(player, "diplomacy-unknown-relation", Map.of("type", args[2]));
            return;
        }

        var conflict = plugin.getDiplomacyManager().findConflict(civ.getId(), target.getId(), type);
        if (conflict.isPresent()) {
            plugin.getMessageManager().send(player, "diplomacy-conflict", Map.of("existing", conflict.get().toString()));
            return;
        }

        DiplomacyRequest request = plugin.getDiplomacyManager().createRequest(civ.getId(), target.getId(), type);
        plugin.getMessageManager().send(player, "diplomacy-request-sent", Map.of("civilization", target.getName(), "type", type.toString()));

        // Notify the target's leader if online.
        if (target.hasLeader()) {
            Player targetLeader = Bukkit.getPlayer(target.getLeaderUuid());
            if (targetLeader != null) {
                plugin.getMessageManager().send(targetLeader, "diplomacy-request-received", Map.of(
                        "civilization", civ.getName(), "type", type.toString()));
            }
        }
    }

    private void respond(Player player, Civilization civ, boolean accept) {
        if (!plugin.getLeaderManager().isLeaderOf(player, civ) && !player.hasPermission("civilization.leader.diplomacy")) {
            plugin.getMessageManager().send(player, "diplomacy-no-permission");
            return;
        }
        Optional<DiplomacyRequest> requestOpt = plugin.getDiplomacyManager().findAnyIncomingRequest(civ.getId());
        if (requestOpt.isEmpty()) {
            plugin.getMessageManager().send(player, "diplomacy-no-pending-request");
            return;
        }
        DiplomacyRequest request = requestOpt.get();
        Civilization requester = plugin.getCivilizationManager().get(request.getRequesterCivId()).orElse(null);
        String requesterName = requester != null ? requester.getName() : request.getRequesterCivId();

        if (accept) {
            plugin.getDiplomacyManager().acceptRequest(request);
            plugin.getMessageManager().send(player, "diplomacy-request-accepted", Map.of(
                    "civilization_a", requesterName, "civilization_b", civ.getName(), "type", request.getRelationType().toString()));
        } else {
            plugin.getDiplomacyManager().denyRequest(request);
            plugin.getMessageManager().send(player, "diplomacy-request-denied");
        }
    }

    private void cancel(Player player, Civilization civ) {
        if (!plugin.getLeaderManager().isLeaderOf(player, civ) && !player.hasPermission("civilization.leader.diplomacy")) {
            plugin.getMessageManager().send(player, "diplomacy-no-permission");
            return;
        }
        var pending = plugin.getDiplomacyManager();
        // Find any outgoing request from this civ (small scan; request volume is tiny).
        for (Civilization other : plugin.getCivilizationManager().getAll()) {
            var reqOpt = pending.findOutgoingRequest(civ.getId(), other.getId());
            if (reqOpt.isPresent()) {
                pending.cancelRequest(reqOpt.get());
                plugin.getMessageManager().send(player, "diplomacy-request-cancelled");
                return;
            }
        }
        plugin.getMessageManager().send(player, "diplomacy-no-pending-request");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("status", "request", "accept", "deny", "cancel"), args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("request")) {
            return filter(plugin.getCivilizationManager().getAll().stream().map(Civilization::getId).toList(), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("request")) {
            return filter(List.of("ALLY", "PEACE", "TRADE", "WAR"), args[2]);
        }
        return Collections.emptyList();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
