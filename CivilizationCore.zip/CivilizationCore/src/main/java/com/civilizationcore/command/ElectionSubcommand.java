package com.civilizationcore.command;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.manager.ElectionManager;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.CivPlayer;
import com.civilizationcore.model.Election;
import com.civilizationcore.model.ElectionState;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.Optional;

/** Handles /civ election <nominate|candidates|vote|confirm|decline|withdraw>. */
public class ElectionSubcommand {

    private final CivilizationCore plugin;

    public ElectionSubcommand(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public void handle(Player player, String[] args) {
        CivPlayer cp = plugin.getPlayerManager().get(player.getUniqueId()).orElse(null);
        if (cp == null || !cp.hasCivilization()) {
            plugin.getMessageManager().sendRaw(player, "&cYou must belong to a civilization to use elections.");
            return;
        }
        Civilization civ = plugin.getCivilizationManager().get(cp.getCivilizationId()).orElse(null);
        if (civ == null) return;

        if (args.length < 2) {
            showStatus(player, civ);
            return;
        }

        switch (args[1].toLowerCase()) {
            case "nominate" -> nominate(player, civ, args);
            case "candidates" -> candidates(player, civ);
            case "vote" -> vote(player, civ, args);
            case "confirm" -> confirm(player, civ);
            case "decline", "withdraw" -> withdraw(player, civ);
            default -> showStatus(player, civ);
        }
    }

    private void showStatus(Player player, Civilization civ) {
        Optional<Election> electionOpt = plugin.getElectionManager().getActive(civ.getId());
        if (electionOpt.isEmpty()) {
            plugin.getMessageManager().sendRaw(player, "&7There is no election currently running for " + civ.getName() + ".");
            return;
        }
        Election election = electionOpt.get();
        plugin.getMessageManager().sendRaw(player, civ.getPrefix() + " &fElection status: &6" + election.getState());
        if (election.getState() == ElectionState.NOMINATION) {
            player.sendMessage(ChatColor.GRAY + "Nominate with /civ election nominate <player>.");
        } else if (election.getState() == ElectionState.VOTING) {
            player.sendMessage(ChatColor.GRAY + "Vote with /civ election vote <player>.");
        }
    }

    private void nominate(Player player, Civilization civ, String[] args) {
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Usage: /civ election nominate <player>");
            return;
        }
        Player candidate = Bukkit.getPlayer(args[2]);
        if (candidate == null) {
            plugin.getMessageManager().send(player, "player-not-found", Map.of("player", args[2]));
            return;
        }

        ElectionManager.ActionResult result = plugin.getElectionManager().nominate(civ, player, candidate);
        switch (result) {
            case SUCCESS -> plugin.getMessageManager().send(player, "election-nominated", Map.of("player", candidate.getName()));
            case NEEDS_CONFIRMATION -> player.sendMessage(ChatColor.YELLOW + candidate.getName() + " has been asked to confirm their candidacy.");
            case NO_ELECTION -> plugin.getMessageManager().send(player, "election-not-running", Map.of("civilization", civ.getName()));
            case WRONG_PHASE -> plugin.getMessageManager().send(player, "election-wrong-phase", Map.of("phase", "current"));
            case NOT_MEMBER -> plugin.getMessageManager().send(player, "election-not-member", Map.of("civilization", civ.getName()));
            case INSUFFICIENT_PLAYTIME -> plugin.getMessageManager().send(player, "election-insufficient-playtime");
            case ALREADY_CANDIDATE -> plugin.getMessageManager().send(player, "election-already-candidate", Map.of("player", candidate.getName()));
            case SELF_NOMINATION_DISABLED -> plugin.getMessageManager().send(player, "election-self-nomination-disabled");
            default -> player.sendMessage(ChatColor.RED + "Could not nominate that player.");
        }
    }

    private void candidates(Player player, Civilization civ) {
        Optional<Election> electionOpt = plugin.getElectionManager().getActive(civ.getId());
        if (electionOpt.isEmpty()) {
            plugin.getMessageManager().send(player, "election-not-running", Map.of("civilization", civ.getName()));
            return;
        }
        Election election = electionOpt.get();
        var candidates = election.getAllNonWithdrawnCandidates();
        if (candidates.isEmpty()) {
            plugin.getMessageManager().send(player, "election-no-candidates");
            return;
        }
        player.sendMessage(ChatColor.GOLD + "Candidates for " + civ.getName() + ":");
        for (var uuid : candidates) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
            String name = op.getName() != null ? op.getName() : uuid.toString();
            String status = election.isConfirmed(uuid) ? "" : ChatColor.GRAY + " (pending confirmation)";
            player.sendMessage(ChatColor.WHITE + "- " + name + status);
        }
    }

    private void vote(Player player, Civilization civ, String[] args) {
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Usage: /civ election vote <player>");
            return;
        }
        Player candidate = Bukkit.getPlayer(args[2]);
        if (candidate == null) {
            plugin.getMessageManager().send(player, "player-not-found", Map.of("player", args[2]));
            return;
        }
        ElectionManager.ActionResult result = plugin.getElectionManager().vote(civ, player, candidate);
        switch (result) {
            case SUCCESS -> plugin.getMessageManager().send(player, "election-vote-cast");
            case ALREADY_VOTED -> plugin.getMessageManager().send(player, "election-already-voted");
            case INVALID_CANDIDATE -> plugin.getMessageManager().send(player, "election-vote-invalid-candidate", Map.of("player", args[2]));
            case NO_ELECTION -> plugin.getMessageManager().send(player, "election-not-running", Map.of("civilization", civ.getName()));
            case WRONG_PHASE -> plugin.getMessageManager().send(player, "election-wrong-phase", Map.of("phase", "current"));
            default -> player.sendMessage(ChatColor.RED + "Could not cast that vote.");
        }
    }

    private void confirm(Player player, Civilization civ) {
        ElectionManager.ActionResult result = plugin.getElectionManager().confirmCandidacy(civ, player);
        switch (result) {
            case SUCCESS -> player.sendMessage(ChatColor.GREEN + "You are now a confirmed candidate!");
            case NOT_YOUR_NOMINATION -> player.sendMessage(ChatColor.RED + "You haven't been nominated in this election.");
            case NO_ELECTION -> plugin.getMessageManager().send(player, "election-not-running", Map.of("civilization", civ.getName()));
            default -> player.sendMessage(ChatColor.RED + "Could not confirm candidacy.");
        }
    }

    private void withdraw(Player player, Civilization civ) {
        ElectionManager.ActionResult result = plugin.getElectionManager().withdraw(civ, player);
        switch (result) {
            case SUCCESS -> plugin.getMessageManager().send(player, "election-withdrawn", Map.of("player", player.getName()));
            case NOT_CANDIDATE -> plugin.getMessageManager().send(player, "election-not-candidate", Map.of("player", player.getName()));
            case NO_ELECTION -> plugin.getMessageManager().send(player, "election-not-running", Map.of("civilization", civ.getName()));
            default -> player.sendMessage(ChatColor.RED + "Could not withdraw candidacy.");
        }
    }
}
