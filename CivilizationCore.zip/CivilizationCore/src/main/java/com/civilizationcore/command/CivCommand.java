package com.civilizationcore.command;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.manager.AssignmentManager;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.CivPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;
import java.util.Arrays;

public class CivCommand implements CommandExecutor, TabCompleter {

    private final CivilizationCore plugin;
    private final ElectionSubcommand electionSubcommand;
    private final EconomySubcommand economySubcommand;

    public CivCommand(CivilizationCore plugin) {
        this.plugin = plugin;
        this.electionSubcommand = new ElectionSubcommand(plugin);
        this.economySubcommand = new EconomySubcommand(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().send(sender, "player-only");
            return true;
        }

        if (args.length == 0) {
            showOwnCivilization(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "info" -> showInfo(player, args);
            case "members" -> showMembers(player, args);
            case "stats" -> showStats(player, args);
            case "switch" -> handleSwitch(player, args);
            case "capital" -> showCapital(player, args);
            case "election" -> electionSubcommand.handle(player, args);
            case "bank", "treasury" -> economySubcommand.showBalance(player);
            case "ledger" -> economySubcommand.showTransactions(player);
            case "deposit" -> economySubcommand.deposit(player, args);
            case "withdraw" -> economySubcommand.withdraw(player, args);
            case "chat" -> handleChat(player, args);
            case "leaderboard" -> showLeaderboard(player, args);
            default -> plugin.getMessageManager().sendRaw(player, "&cUnknown subcommand. Try /civ info, members, stats, switch, capital, election, bank, deposit, withdraw, chat, leaderboard.");
        }
        return true;
    }

    private Optional<CivPlayer> requireCivPlayer(Player player) {
        return plugin.getPlayerManager().get(player.getUniqueId());
    }

    private Optional<Civilization> resolveTargetCivilization(Player player, String[] args, int nameIndex) {
        if (args.length > nameIndex) {
            Optional<Civilization> byName = plugin.getCivilizationManager().get(args[nameIndex]);
            if (byName.isEmpty()) {
                plugin.getMessageManager().send(player, "unknown-civilization", Map.of("civilization", args[nameIndex]));
            }
            return byName;
        }
        return requireCivPlayer(player).flatMap(cp -> plugin.getCivilizationManager().get(cp.getCivilizationId()));
    }

    private void showOwnCivilization(Player player) {
        CivPlayer cp = requireCivPlayer(player).orElse(null);
        if (cp == null || !cp.hasCivilization()) {
            plugin.getMessageManager().sendRaw(player, "&cYou are not currently assigned to a civilization.");
            return;
        }
        Civilization civ = plugin.getCivilizationManager().get(cp.getCivilizationId()).orElse(null);
        if (civ == null) {
            plugin.getMessageManager().sendRaw(player, "&cYour civilization could not be found.");
            return;
        }
        plugin.getMessageManager().sendRaw(player, civ.getPrefix() + " &fYou belong to &r" + civ.getPrefix() + " &f" + civ.getName());
    }

    private void showInfo(Player player, String[] args) {
        Optional<Civilization> civOpt = resolveTargetCivilization(player, args, 1);
        if (civOpt.isEmpty()) {
            if (args.length <= 1) plugin.getMessageManager().sendRaw(player, "&cYou are not currently assigned to a civilization.");
            return;
        }
        Civilization civ = civOpt.get();

        String leaderName = "Unclaimed";
        if (civ.hasLeader()) {
            OfflinePlayer leader = Bukkit.getOfflinePlayer(civ.getLeaderUuid());
            leaderName = leader.getName() != null ? leader.getName() : "Unknown";
        }
        String capital = civ.hasCapital() ? plugin.getCapitalManager().formatCapital(civ) : "Not set";

        player.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━");
        plugin.getMessageManager().sendRaw(player, civ.getPrefix() + " &f" + civ.getName().toUpperCase());
        player.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━");
        player.sendMessage(ChatColor.GRAY + "Leader: " + ChatColor.WHITE + leaderName);
        player.sendMessage(ChatColor.GRAY + "Members: " + ChatColor.WHITE + civ.getMemberCount());
        player.sendMessage("");
        player.sendMessage(ChatColor.GRAY + "Capital: " + ChatColor.WHITE + capital);
        player.sendMessage("");
        player.sendMessage(ChatColor.GRAY + "Wars Won: " + ChatColor.WHITE + civ.getStats().getWarsWon());
        player.sendMessage(ChatColor.GRAY + "Wars Lost: " + ChatColor.WHITE + civ.getStats().getWarsLost());
        player.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━");
    }

    private void showMembers(Player player, String[] args) {
        Optional<Civilization> civOpt = resolveTargetCivilization(player, args, 1);
        if (civOpt.isEmpty()) return;
        Civilization civ = civOpt.get();

        List<String> names = civ.getMembers().stream()
                .map(uuid -> {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
                    String name = op.getName() != null ? op.getName() : uuid.toString();
                    return civ.hasLeader() && civ.getLeaderUuid().equals(uuid) ? name + " (Leader)" : name;
                })
                .collect(Collectors.toList());

        plugin.getMessageManager().sendRaw(player, civ.getPrefix() + " &fMembers (" + names.size() + "):");
        player.sendMessage(ChatColor.WHITE + String.join(", ", names));
    }

    private void showStats(Player player, String[] args) {
        Optional<Civilization> civOpt = resolveTargetCivilization(player, args, 1);
        if (civOpt.isEmpty()) return;
        Civilization civ = civOpt.get();

        plugin.getMessageManager().sendRaw(player, civ.getPrefix() + " &fStatistics");
        player.sendMessage(ChatColor.GRAY + "Members: " + ChatColor.WHITE + civ.getMemberCount());
        player.sendMessage(ChatColor.GRAY + "Wars Won: " + ChatColor.WHITE + civ.getStats().getWarsWon());
        player.sendMessage(ChatColor.GRAY + "Wars Lost: " + ChatColor.WHITE + civ.getStats().getWarsLost());
    }

    private void showCapital(Player player, String[] args) {
        Optional<Civilization> civOpt = resolveTargetCivilization(player, args, 1);
        if (civOpt.isEmpty()) return;
        Civilization civ = civOpt.get();
        plugin.getMessageManager().sendRaw(player, civ.getPrefix() + " &fCapital: &f" + plugin.getCapitalManager().formatCapital(civ));
    }

    private void handleSwitch(Player player, String[] args) {
        CivPlayer cp = requireCivPlayer(player).orElse(null);
        if (cp == null) return;

        AssignmentManager.SwitchEligibility eligibility = plugin.getAssignmentManager().checkEligibility(cp);

        if (args.length <= 1) {
            // Just checking eligibility.
            if (eligibility.eligible()) {
                plugin.getMessageManager().send(player, "switch-eligible");
            } else if ("switch-on-cooldown".equals(eligibility.reasonMessageKey())) {
                plugin.getMessageManager().send(player, "switch-on-cooldown",
                        Map.of("time", AssignmentManager.formatDuration(eligibility.remainingMillis())));
            } else {
                plugin.getMessageManager().send(player, eligibility.reasonMessageKey());
            }
            return;
        }

        // Attempting an actual switch to a named civilization.
        if (!eligibility.eligible()) {
            if ("switch-on-cooldown".equals(eligibility.reasonMessageKey())) {
                plugin.getMessageManager().send(player, "switch-on-cooldown",
                        Map.of("time", AssignmentManager.formatDuration(eligibility.remainingMillis())));
            } else {
                plugin.getMessageManager().send(player, eligibility.reasonMessageKey());
            }
            return;
        }

        Optional<Civilization> target = plugin.getCivilizationManager().get(args[1]);
        if (target.isEmpty()) {
            plugin.getMessageManager().send(player, "unknown-civilization", Map.of("civilization", args[1]));
            return;
        }

        if (target.get().getId().equalsIgnoreCase(cp.getCivilizationId())) {
            plugin.getMessageManager().send(player, "already-in-civilization", Map.of("civilization", target.get().getName()));
            return;
        }

        plugin.getAssignmentManager().movePlayer(player, cp, target.get(), true);
        plugin.getMessageManager().send(player, "switched", Map.of("civilization", target.get().getName()));
        plugin.getScoreboardManager().update(player);
    }

    private void handleChat(Player player, String[] args) {
        if (!plugin.getChatManager().isEnabled()) {
            plugin.getMessageManager().send(player, "chat-disabled");
            return;
        }
        CivPlayer cp = requireCivPlayer(player).orElse(null);
        if (cp == null || !cp.hasCivilization()) {
            plugin.getMessageManager().sendRaw(player, "&cYou must belong to a civilization to use civilization chat.");
            return;
        }
        Civilization civ = plugin.getCivilizationManager().get(cp.getCivilizationId()).orElse(null);
        if (civ == null) return;

        if (args.length < 2) {
            // No message: show/toggle current channel.
            plugin.getMessageManager().sendRaw(player, "&7Your active civilization chat channel is &f" + plugin.getChatManager().getChannel(player));
            return;
        }

        // Optional explicit channel switch: /civ chat channel <name>
        if (args[1].equalsIgnoreCase("channel") && args.length >= 3) {
            try {
                var channel = com.civilizationcore.model.ChatChannel.valueOf(args[2].toUpperCase());
                plugin.getChatManager().setChannel(player, channel);
                plugin.getMessageManager().sendRaw(player, "&aSwitched civilization chat channel to " + channel + ".");
            } catch (IllegalArgumentException e) {
                plugin.getMessageManager().sendRaw(player, "&cUnknown channel. Try CIVILIZATION, ALLIANCE, or LEADER.");
            }
            return;
        }

        String message = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        var channel = plugin.getChatManager().getChannel(player);
        if (channel == com.civilizationcore.model.ChatChannel.LEADER && !cp.isLeader()) {
            plugin.getMessageManager().send(player, "not-leader");
            return;
        }
        plugin.getChatManager().send(player, civ, channel, message);
    }

    private void showLeaderboard(Player player, String[] args) {
        var category = com.civilizationcore.manager.StatisticsManager.parseCategory(args.length > 1 ? args[1] : null);
        var ranking = plugin.getStatisticsManager().leaderboard(category);

        player.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━");
        player.sendMessage(ChatColor.GOLD + "LEADERBOARD - " + category);
        player.sendMessage(ChatColor.GOLD + "━━━━━━━━━━━━━━━━━━");
        int place = 1;
        for (Civilization civ : ranking) {
            player.sendMessage(ChatColor.WHITE + "" + place + ". " + plugin.getMessageManager().color(civ.getPrefix()) + " " + civ.getName());
            place++;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("info", "members", "stats", "switch", "capital", "election", "bank",
                    "treasury", "deposit", "withdraw", "chat", "leaderboard"), args[0]);
        }
        if (args.length == 2 && List.of("info", "members", "stats", "switch", "capital").contains(args[0].toLowerCase())) {
            List<String> civIds = plugin.getCivilizationManager().getAll().stream().map(Civilization::getId).toList();
            return filter(civIds, args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("election")) {
            return filter(List.of("nominate", "candidates", "vote", "confirm", "decline", "withdraw"), args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("leaderboard")) {
            return filter(List.of("wars", "wealth", "members", "weapons", "events", "overall"), args[1]);
        }
        return Collections.emptyList();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
