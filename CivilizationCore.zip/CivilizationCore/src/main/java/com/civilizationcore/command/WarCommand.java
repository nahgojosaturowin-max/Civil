package com.civilizationcore.command;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.*;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class WarCommand implements CommandExecutor, TabCompleter {

    private final CivilizationCore plugin;

    public WarCommand(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    private Civilization requireCiv(Player player) {
        CivPlayer cp = plugin.getPlayerManager().get(player.getUniqueId()).orElse(null);
        if (cp == null || !cp.hasCivilization()) {
            plugin.getMessageManager().sendRaw(player, "&cYou must belong to a civilization.");
            return null;
        }
        return plugin.getCivilizationManager().get(cp.getCivilizationId()).orElse(null);
    }

    private boolean requireLeader(Player player, Civilization civ) {
        if (!plugin.getLeaderManager().isLeaderOf(player, civ) && !player.hasPermission("civilization.leader.war")) {
            plugin.getMessageManager().send(player, "war-no-permission");
            return false;
        }
        return true;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageManager().send(sender, "player-only");
            return true;
        }
        if (!plugin.getWarManager().isEnabled()) {
            player.sendMessage(ChatColor.RED + "The war system is currently disabled.");
            return true;
        }

        if (args.length == 0) {
            list(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create" -> create(player, args);
            case "accept" -> respond(player, args, true);
            case "deny" -> respond(player, args, false);
            case "info" -> info(player, args);
            case "schedule" -> schedule(player, args);
            case "cancel" -> cancel(player, args);
            case "list" -> list(player);
            case "winner" -> declareWinner(player, args);
            default -> player.sendMessage(ChatColor.RED + "Usage: /war <create|accept|deny|info|schedule|cancel|list>");
        }
        return true;
    }

    /** Admin-only: manually resolves an ACTIVE war's winner, since automatic combat/objective detection isn't built. */
    private void declareWinner(Player player, String[] args) {
        if (!player.hasPermission("civilization.admin")) {
            plugin.getMessageManager().send(player, "no-permission");
            return;
        }
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Usage: /war winner <war id> <civilization>");
            return;
        }
        War war = plugin.getWarManager().get(parseId(args[1])).orElse(null);
        if (war == null) {
            plugin.getMessageManager().send(player, "war-not-found");
            return;
        }
        Optional<Civilization> winnerOpt = plugin.getCivilizationManager().get(args[2]);
        if (winnerOpt.isEmpty() || !war.involves(winnerOpt.get().getId())) {
            player.sendMessage(ChatColor.RED + "That civilization isn't part of this war.");
            return;
        }
        plugin.getWarManager().finishWar(war, winnerOpt.get().getId());
        player.sendMessage(ChatColor.GREEN + "War #" + war.getId() + " resolved.");
    }

    private void create(Player player, String[] args) {
        Civilization civ = requireCiv(player);
        if (civ == null || !requireLeader(player, civ)) return;

        if (!plugin.getSeasonManager().areWarsAllowed()) {
            player.sendMessage(ChatColor.RED + "No new wars can be declared during the current season's grace period.");
            return;
        }
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Usage: /war create <civilization> <type>");
            return;
        }
        Optional<Civilization> defenderOpt = plugin.getCivilizationManager().get(args[1]);
        if (defenderOpt.isEmpty()) {
            plugin.getMessageManager().send(player, "unknown-civilization", Map.of("civilization", args[1]));
            return;
        }
        Civilization defender = defenderOpt.get();
        if (defender.getId().equalsIgnoreCase(civ.getId())) {
            player.sendMessage(ChatColor.RED + "You cannot declare war on your own civilization.");
            return;
        }
        WarType type = WarType.fromString(args[2]);
        if (type == null) {
            plugin.getMessageManager().send(player, "war-unknown-type", Map.of("type", args[2]));
            return;
        }
        if (!plugin.getWarManager().getActiveFor(civ.getId()).stream()
                .filter(w -> w.involves(defender.getId())).toList().isEmpty()) {
            plugin.getMessageManager().send(player, "war-already-active");
            return;
        }

        War war = plugin.getWarManager().createWar(civ, defender, type);
        plugin.getMessageManager().sendRaw(player, "&aWar declared! Waiting for " + defender.getName() + " to respond.");

        if (defender.hasLeader()) {
            var defLeader = org.bukkit.Bukkit.getPlayer(defender.getLeaderUuid());
            if (defLeader != null) {
                plugin.getMessageManager().send(defLeader, "war-created", Map.of(
                        "attacker", civ.getName(), "defender", defender.getName(), "type", type.toString()));
            }
        }
    }

    private void respond(Player player, String[] args, boolean accept) {
        Civilization civ = requireCiv(player);
        if (civ == null || !requireLeader(player, civ)) return;

        War war = findWarArg(player, args);
        if (war == null) return;
        if (!war.getDefenderCivId().equalsIgnoreCase(civ.getId())) {
            plugin.getMessageManager().send(player, "war-not-defender");
            return;
        }

        if (accept) {
            plugin.getWarManager().accept(war);
            plugin.getMessageManager().send(player, "war-accepted");
        } else {
            plugin.getWarManager().deny(war);
            plugin.getMessageManager().send(player, "war-denied");
        }
    }

    private void info(Player player, String[] args) {
        War war = findWarArg(player, args);
        if (war == null) return;

        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        player.sendMessage(ChatColor.GOLD + "War #" + war.getId() + " - " + war.getType());
        player.sendMessage(ChatColor.GRAY + "Attacker: " + ChatColor.WHITE + nameOf(war.getAttackerCivId()));
        player.sendMessage(ChatColor.GRAY + "Defender: " + ChatColor.WHITE + nameOf(war.getDefenderCivId()));
        player.sendMessage(ChatColor.GRAY + "State: " + ChatColor.WHITE + war.getState());
        if (war.getScheduledStart() > 0) {
            player.sendMessage(ChatColor.GRAY + "Scheduled: " + ChatColor.WHITE + fmt.format(new Date(war.getScheduledStart())));
        }
        if (war.getTargetWeaponId() != null) {
            player.sendMessage(ChatColor.GRAY + "Objective: " + ChatColor.WHITE + "Capture " + war.getTargetWeaponId());
        }
        if (war.getWinnerCivId() != null) {
            player.sendMessage(ChatColor.GRAY + "Winner: " + ChatColor.WHITE + nameOf(war.getWinnerCivId()));
        }
    }

    private void schedule(Player player, String[] args) {
        Civilization civ = requireCiv(player);
        if (civ == null || !requireLeader(player, civ)) return;
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Usage: /war schedule <war id> <minutes from now>");
            return;
        }
        War war = plugin.getWarManager().get(parseId(args[1])).orElse(null);
        if (war == null) {
            plugin.getMessageManager().send(player, "war-not-found");
            return;
        }
        if (!war.involves(civ.getId())) {
            plugin.getMessageManager().send(player, "war-not-found");
            return;
        }
        try {
            long minutes = Long.parseLong(args[2]);
            long startTime = System.currentTimeMillis() + minutes * 60_000L;
            boolean success = plugin.getWarManager().schedule(war, startTime);
            if (success) {
                player.sendMessage(ChatColor.GREEN + "War scheduled to begin in " + minutes + " minutes.");
            } else {
                player.sendMessage(ChatColor.RED + "The war must be accepted before it can be scheduled.");
            }
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Usage: /war schedule <war id> <minutes from now>");
        }
    }

    private void cancel(Player player, String[] args) {
        Civilization civ = requireCiv(player);
        if (civ == null || !requireLeader(player, civ)) return;
        War war = findWarArg(player, args);
        if (war == null) return;
        if (!war.involves(civ.getId())) {
            plugin.getMessageManager().send(player, "war-not-found");
            return;
        }
        plugin.getWarManager().cancel(war);
        plugin.getMessageManager().send(player, "war-cancelled");
    }

    private void list(Player player) {
        Civilization civ = requireCiv(player);
        if (civ == null) return;
        var wars = plugin.getWarManager().getActiveFor(civ.getId());
        if (wars.isEmpty()) {
            player.sendMessage(ChatColor.GRAY + "No active wars.");
            return;
        }
        player.sendMessage(ChatColor.GOLD + "Active wars for " + civ.getName() + ":");
        for (War war : wars) {
            player.sendMessage(ChatColor.WHITE + "#" + war.getId() + " " + war.getType() + " vs "
                    + nameOf(war.otherSide(civ.getId())) + ChatColor.GRAY + " (" + war.getState() + ")");
        }
    }

    private War findWarArg(Player player, String[] args) {
        if (args.length < 2) {
            Civilization civ = requireCiv(player);
            if (civ == null) return null;
            var wars = plugin.getWarManager().getActiveFor(civ.getId());
            if (wars.size() == 1) return wars.get(0);
            player.sendMessage(ChatColor.RED + "Specify a war id - use /war list to see active wars.");
            return null;
        }
        War war = plugin.getWarManager().get(parseId(args[1])).orElse(null);
        if (war == null) {
            plugin.getMessageManager().send(player, "war-not-found");
        }
        return war;
    }

    private long parseId(String input) {
        try {
            return Long.parseLong(input);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private String nameOf(String civId) {
        return plugin.getCivilizationManager().get(civId).map(Civilization::getName).orElse(civId);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("create", "accept", "deny", "info", "schedule", "cancel", "list"), args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("create")) {
            return filter(plugin.getCivilizationManager().getAll().stream().map(Civilization::getId).toList(), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("create")) {
            return filter(List.of("TERRITORY_WAR", "CASTLE_SIEGE", "WEAPON_WAR", "CIVILIZATION_BATTLE"), args[2]);
        }
        return Collections.emptyList();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
