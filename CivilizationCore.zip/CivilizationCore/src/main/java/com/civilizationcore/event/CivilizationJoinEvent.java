package com.civilizationcore.event;

import com.civilizationcore.model.Civilization;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.entity.Player;

/**
 * Fired when a player is assigned to (or joins) a civilization, whether via
 * automatic balancing on first join or an admin/manual assignment.
 */
public class CivilizationJoinEvent extends PlayerEvent {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Civilization civilization;
    private final boolean automatic;

    public CivilizationJoinEvent(Player who, Civilization civilization, boolean automatic) {
        super(who);
        this.civilization = civilization;
        this.automatic = automatic;
    }

    public Civilization getCivilization() {
        return civilization;
    }

    public boolean isAutomatic() {
        return automatic;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
