package com.civilizationcore.event;

import com.civilizationcore.model.Civilization;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.entity.Player;

/**
 * Fired when a player is removed from a civilization, either by an admin
 * or as the first step of a civilization switch.
 */
public class CivilizationLeaveEvent extends PlayerEvent {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Civilization civilization;

    public CivilizationLeaveEvent(Player who, Civilization civilization) {
        super(who);
        this.civilization = civilization;
    }

    public Civilization getCivilization() {
        return civilization;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
