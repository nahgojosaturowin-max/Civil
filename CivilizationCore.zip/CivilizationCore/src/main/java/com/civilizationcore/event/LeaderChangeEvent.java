package com.civilizationcore.event;

import com.civilizationcore.model.Civilization;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import java.util.UUID;

/**
 * Fired whenever a civilization's leader changes. Either uuid may be null:
 * oldLeader is null if the civilization had no prior leader, newLeader is
 * null if leadership is being cleared.
 */
public class LeaderChangeEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Civilization civilization;
    private final UUID oldLeader;
    private final UUID newLeader;

    public LeaderChangeEvent(Civilization civilization, UUID oldLeader, UUID newLeader) {
        this.civilization = civilization;
        this.oldLeader = oldLeader;
        this.newLeader = newLeader;
    }

    public Civilization getCivilization() {
        return civilization;
    }

    public UUID getOldLeader() {
        return oldLeader;
    }

    public UUID getNewLeader() {
        return newLeader;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
