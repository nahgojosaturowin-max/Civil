package com.civilizationcore.event;

import com.civilizationcore.model.Season;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class SeasonEndEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    private final Season season;

    public SeasonEndEvent(Season season) {
        this.season = season;
    }

    public Season getSeason() {
        return season;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
