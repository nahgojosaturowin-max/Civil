package com.civilizationcore.event;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class CivilizationVictoryEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    private final String civilizationId;
    private final int seasonNumber;

    public CivilizationVictoryEvent(String civilizationId, int seasonNumber) {
        this.civilizationId = civilizationId;
        this.seasonNumber = seasonNumber;
    }

    public String getCivilizationId() {
        return civilizationId;
    }

    public int getSeasonNumber() {
        return seasonNumber;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
