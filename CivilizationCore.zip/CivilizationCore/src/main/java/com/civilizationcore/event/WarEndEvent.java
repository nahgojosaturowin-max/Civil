package com.civilizationcore.event;

import com.civilizationcore.model.War;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class WarEndEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    private final War war;
    private final String winnerCivId;

    public WarEndEvent(War war, String winnerCivId) {
        this.war = war;
        this.winnerCivId = winnerCivId;
    }

    public War getWar() {
        return war;
    }

    public String getWinnerCivId() {
        return winnerCivId;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
