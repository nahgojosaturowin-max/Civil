package com.civilizationcore.event;

import com.civilizationcore.model.LegendaryWeapon;
import com.civilizationcore.model.War;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import java.util.UUID;

public class WeaponCapturedEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final LegendaryWeapon weapon;
    private final String previousOwnerCivId;
    private final String newOwnerCivId;
    private final UUID capturedBy;
    private final War war; // nullable - may be an admin transfer
    private final long timestamp = System.currentTimeMillis();

    public WeaponCapturedEvent(LegendaryWeapon weapon, String previousOwnerCivId, String newOwnerCivId, UUID capturedBy, War war) {
        this.weapon = weapon;
        this.previousOwnerCivId = previousOwnerCivId;
        this.newOwnerCivId = newOwnerCivId;
        this.capturedBy = capturedBy;
        this.war = war;
    }

    public LegendaryWeapon getWeapon() {
        return weapon;
    }

    public String getPreviousOwnerCivId() {
        return previousOwnerCivId;
    }

    public String getNewOwnerCivId() {
        return newOwnerCivId;
    }

    public UUID getCapturedBy() {
        return capturedBy;
    }

    public War getWar() {
        return war;
    }

    public long getTimestamp() {
        return timestamp;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
