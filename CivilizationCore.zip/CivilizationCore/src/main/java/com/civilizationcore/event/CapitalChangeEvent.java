package com.civilizationcore.event;

import com.civilizationcore.model.Civilization;
import org.bukkit.Location;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class CapitalChangeEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Civilization civilization;
    private final Location newCapital;

    public CapitalChangeEvent(Civilization civilization, Location newCapital) {
        this.civilization = civilization;
        this.newCapital = newCapital;
    }

    public Civilization getCivilization() {
        return civilization;
    }

    public Location getNewCapital() {
        return newCapital;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
