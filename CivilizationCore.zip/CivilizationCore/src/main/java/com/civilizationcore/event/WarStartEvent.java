package com.civilizationcore.event;

import com.civilizationcore.model.War;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class WarStartEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    private final War war;

    public WarStartEvent(War war) {
        this.war = war;
    }

    public War getWar() {
        return war;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
