package com.civilizationcore.manager;

import com.civilizationcore.model.*;
import com.civilizationcore.CivilizationCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Drives the election state machine (IDLE -> NOMINATION -> VOTING ->
 * FINISHED) for every civilization. A single repeating task checks all
 * in-progress elections for phase transitions rather than scheduling one
 * task per election, keeping this cheap even with many civilizations.
 *
 * Playtime verification for candidates requires them to be online (Bukkit's
 * play-time statistic isn't reliably readable for offline players without
 * parsing raw player data), so nominations of offline players are rejected
 * with a clear message rather than silently skipping the check.
 */
public class ElectionManager {

    private final CivilizationCore plugin;
    private final Map<String, Election> activeElections = new ConcurrentHashMap<>();
    private BukkitTask tickTask;

    public ElectionManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        stop();
        tickTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 100L, 100L); // every 5s
    }

    public void stop() {
        if (tickTask != null) {
            tickTask.cancel();
            tickTask = null;
        }
    }

    public boolean isEnabled() {
        return plugin.getConfigManager().getConfig().getBoolean("election.enabled", true);
    }

    public Optional<Election> getActive(String civId) {
        return Optional.ofNullable(activeElections.get(civId.toLowerCase()));
    }

    private void tick() {
        long now = System.currentTimeMillis();
        for (Election election : List.copyOf(activeElections.values())) {
            try {
                if (election.getState() == ElectionState.NOMINATION && now >= election.getNominationEndsAt()) {
                    beginVoting(election);
                } else if (election.getState() == ElectionState.VOTING && now >= election.getVotingEndsAt()) {
                    finalizeElection(election);
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Error advancing election for " + election.getCivilizationId() + ": " + e.getMessage());
            }
        }
    }

    // ---------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------

    public boolean startElection(Civilization civ, CommandSender initiator) {
        if (!isEnabled()) return false;
        if (activeElections.containsKey(civ.getId().toLowerCase())) return false;

        Election election = new Election(civ.getId());
        election.setPreviousLeader(civ.getLeaderUuid());
        election.setState(ElectionState.NOMINATION);
        long nominationMs = AssignmentManager.parseDuration(
                plugin.getConfigManager().getConfig().getString("election.nomination-duration", "24h"));
        election.setNominationEndsAt(System.currentTimeMillis() + nominationMs);

        activeElections.put(civ.getId().toLowerCase(), election);
        plugin.getStorageManager().createElection(election).thenAccept(election::setId);

        if (plugin.getConfigManager().getConfig().getBoolean("election.announce-on-start", true)) {
            broadcastToCiv(civ, plugin.getMessageManager().raw("election-started", Map.of("civilization", civ.getName())));
        }
        return true;
    }

    private void beginVoting(Election election) {
        election.setState(ElectionState.VOTING);
        long votingMs = AssignmentManager.parseDuration(
                plugin.getConfigManager().getConfig().getString("election.voting-duration", "24h"));
        election.setVotingEndsAt(System.currentTimeMillis() + votingMs);
        plugin.getStorageManager().updateElection(election);

        plugin.getCivilizationManager().get(election.getCivilizationId()).ifPresent(civ -> {
            List<UUID> candidates = election.getActiveCandidates();
            if (candidates.isEmpty()) {
                // No confirmed candidates - nothing to vote on. End quietly, keep previous leader.
                broadcastToCiv(civ, ChatColor.RED + "The election for " + civ.getName() + " ended with no candidates - the current leader remains in place.");
                election.setState(ElectionState.FINISHED);
                plugin.getStorageManager().updateElection(election);
                activeElections.remove(civ.getId().toLowerCase());
                return;
            }
            broadcastToCiv(civ, ChatColor.GOLD + "Voting has begun for " + civ.getName() + "! Use /civ election vote <player>.");
        });
    }

    private void finalizeElection(Election election) {
        Civilization civ = plugin.getCivilizationManager().get(election.getCivilizationId()).orElse(null);
        if (civ == null) {
            activeElections.remove(election.getCivilizationId().toLowerCase());
            return;
        }

        Map<UUID, Integer> tally = election.tally();
        if (tally.isEmpty()) {
            election.setState(ElectionState.FINISHED);
            plugin.getStorageManager().updateElection(election);
            activeElections.remove(civ.getId().toLowerCase());
            return;
        }

        int maxVotes = Collections.max(tally.values());
        List<UUID> tied = tally.entrySet().stream()
                .filter(e -> e.getValue() == maxVotes)
                .map(Map.Entry::getKey)
                .toList();

        if (tied.size() == 1) {
            completeElection(civ, election, tied.get(0), tally);
            return;
        }

        // Tie handling.
        TieMethod method = TieMethod.fromString(plugin.getConfigManager().getConfig().getString("election.tie-method", "RUNOFF"));
        switch (method) {
            case RUNOFF -> {
                if (election.getRunoffCount() < 1) {
                    election.incrementRunoffCount();
                    election.resetForRunoff(tied);
                    // Re-confirm the tied candidates (resetForRunoff clears withdrawn but keeps the confirmed map values).
                    long votingMs = AssignmentManager.parseDuration(
                            plugin.getConfigManager().getConfig().getString("election.voting-duration", "24h"));
                    election.setVotingEndsAt(System.currentTimeMillis() + votingMs);
                    election.setState(ElectionState.VOTING);
                    plugin.getStorageManager().updateElection(election);
                    broadcastToCiv(civ, ChatColor.YELLOW + "The election for " + civ.getName() + " was tied - a runoff vote has begun between the tied candidates!");
                    return;
                }
                // Already had a runoff and still tied - fall through to RANDOM.
                UUID winner = tied.get(new Random().nextInt(tied.size()));
                completeElection(civ, election, winner, tally);
            }
            case RANDOM -> {
                UUID winner = tied.get(new Random().nextInt(tied.size()));
                completeElection(civ, election, winner, tally);
            }
            case PREVIOUS_LEADER -> {
                UUID winner = (election.getPreviousLeader() != null && tied.contains(election.getPreviousLeader()))
                        ? election.getPreviousLeader()
                        : tied.get(new Random().nextInt(tied.size()));
                completeElection(civ, election, winner, tally);
            }
            case ADMIN_DECISION -> {
                broadcastToCiv(civ, ChatColor.RED + "The election for " + civ.getName() + " ended in a tie. An admin must break the tie with /civadmin election setwinner " + civ.getId() + " <player>.");
                // Leave the election active (still VOTING state) so admins/players can inspect it;
                // /civadmin election setwinner will call completeElection directly.
            }
        }
    }

    /** Called directly by /civadmin election setwinner for the ADMIN_DECISION tie path. */
    public void adminSetWinner(Civilization civ, UUID winner) {
        Election election = activeElections.get(civ.getId().toLowerCase());
        if (election == null) return;
        completeElection(civ, election, winner, election.tally());
    }

    private void completeElection(Civilization civ, Election election, UUID winnerUuid, Map<UUID, Integer> tally) {
        election.setWinner(winnerUuid);
        election.setState(ElectionState.FINISHED);
        plugin.getStorageManager().updateElection(election);
        activeElections.remove(civ.getId().toLowerCase());

        OfflinePlayer winnerOffline = Bukkit.getOfflinePlayer(winnerUuid);
        String winnerName = winnerOffline.getName() != null ? winnerOffline.getName() : winnerUuid.toString();

        // Announce the result board.
        StringBuilder sb = new StringBuilder();
        sb.append(ChatColor.GOLD).append("━━━━━━━━━━━━━━━━━━━━\n");
        sb.append("\uD83D\uDC51 ").append(ChatColor.BOLD).append("ELECTION RESULT\n");
        sb.append(ChatColor.GOLD).append("━━━━━━━━━━━━━━━━━━━━\n");
        sb.append(ChatColor.WHITE).append(civ.getName().toUpperCase()).append("\n\n");
        tally.entrySet().stream()
                .sorted((a, b) -> b.getValue() - a.getValue())
                .forEach(e -> {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(e.getKey());
                    String name = op.getName() != null ? op.getName() : e.getKey().toString();
                    sb.append(ChatColor.GRAY).append(name).append(" \u2014 ").append(e.getValue()).append(" votes\n");
                });
        sb.append("\n").append(ChatColor.YELLOW).append("Winner:\n\uD83D\uDC51 ").append(ChatColor.BOLD).append(winnerName.toUpperCase()).append("\n");
        sb.append(ChatColor.GOLD).append("━━━━━━━━━━━━━━━━━━━━");
        Bukkit.broadcastMessage(sb.toString());

        // Apply leadership (see PRD section 5: remove old leader/perms/crown, assign new, give crown, announce).
        Player onlineWinner = Bukkit.getPlayer(winnerUuid);
        UUID previousLeader = civ.getLeaderUuid();

        if (onlineWinner != null) {
            plugin.getPlayerManager().get(winnerUuid).ifPresentOrElse(
                    cp -> plugin.getLeaderManager().setLeader(civ, onlineWinner, cp),
                    () -> plugin.getLogger().warning("Election winner " + winnerName + " has no cached player data; leadership not applied.")
            );
        } else {
            plugin.getStorageManager().loadPlayer(winnerUuid).thenAccept(opt -> opt.ifPresent(cp ->
                    Bukkit.getScheduler().runTask(plugin, () -> plugin.getLeaderManager().setLeaderOffline(civ, winnerUuid, cp))
            ));
        }

        plugin.getDiscordIntegrationManager().announceElectionResult(civ.getName(), winnerName);
        plugin.getDiscordIntegrationManager().syncLeaderRoles(civ.getId(), previousLeader, winnerUuid);
    }

    // ---------------------------------------------------------------
    // Nomination / voting actions (called from commands)
    // ---------------------------------------------------------------

    public enum ActionResult {
        SUCCESS, NO_ELECTION, WRONG_PHASE, NOT_MEMBER, INSUFFICIENT_PLAYTIME,
        ALREADY_CANDIDATE, SELF_NOMINATION_DISABLED, NOT_CANDIDATE, ALREADY_VOTED,
        INVALID_CANDIDATE, NEEDS_CONFIRMATION, NOT_YOUR_NOMINATION
    }

    public ActionResult nominate(Civilization civ, Player nominator, Player candidate) {
        Election election = activeElections.get(civ.getId().toLowerCase());
        if (election == null) return ActionResult.NO_ELECTION;
        if (election.getState() != ElectionState.NOMINATION) return ActionResult.WRONG_PHASE;

        var candidateData = plugin.getPlayerManager().get(candidate.getUniqueId()).orElse(null);
        if (candidateData == null || !civ.getId().equalsIgnoreCase(candidateData.getCivilizationId())) {
            return ActionResult.NOT_MEMBER;
        }

        boolean isSelf = nominator.getUniqueId().equals(candidate.getUniqueId());
        if (isSelf && !plugin.getConfigManager().getConfig().getBoolean("election.allow-self-nomination", false)) {
            return ActionResult.SELF_NOMINATION_DISABLED;
        }

        long minPlaytimeMs = AssignmentManager.parseDuration(
                plugin.getConfigManager().getConfig().getString("election.minimum-playtime", "10h"));
        long candidatePlaytimeMs = candidate.getStatistic(Statistic.PLAY_ONE_MINUTE) * 50L; // ticks -> ms
        if (candidatePlaytimeMs < minPlaytimeMs) {
            return ActionResult.INSUFFICIENT_PLAYTIME;
        }

        if (election.getCandidates().containsKey(candidate.getUniqueId())
                && !election.getCandidates().get(candidate.getUniqueId()).equals(Boolean.FALSE)) {
            return ActionResult.ALREADY_CANDIDATE;
        }

        boolean requireConfirmation = plugin.getConfigManager().getConfig().getBoolean("election.require-candidate-confirmation", true);
        boolean confirmed = isSelf || !requireConfirmation;

        election.addCandidate(candidate.getUniqueId(), confirmed);
        plugin.getStorageManager().saveCandidate(election.getId(), candidate.getUniqueId(), confirmed, false);

        if (!confirmed) {
            plugin.getMessageManager().sendRaw(candidate,
                    "&6You've been nominated for leader of " + civ.getName() + "! Use /civ election confirm to accept, or /civ election decline to refuse.");
            return ActionResult.NEEDS_CONFIRMATION;
        }
        return ActionResult.SUCCESS;
    }

    public ActionResult confirmCandidacy(Civilization civ, Player player) {
        Election election = activeElections.get(civ.getId().toLowerCase());
        if (election == null) return ActionResult.NO_ELECTION;
        if (election.getState() != ElectionState.NOMINATION) return ActionResult.WRONG_PHASE;
        if (!election.getCandidates().containsKey(player.getUniqueId())) return ActionResult.NOT_YOUR_NOMINATION;

        election.addCandidate(player.getUniqueId(), true);
        plugin.getStorageManager().saveCandidate(election.getId(), player.getUniqueId(), true, false);
        return ActionResult.SUCCESS;
    }

    public ActionResult withdraw(Civilization civ, Player player) {
        Election election = activeElections.get(civ.getId().toLowerCase());
        if (election == null) return ActionResult.NO_ELECTION;
        if (!election.getCandidates().containsKey(player.getUniqueId())) return ActionResult.NOT_CANDIDATE;

        election.withdrawCandidate(player.getUniqueId());
        plugin.getStorageManager().saveCandidate(election.getId(), player.getUniqueId(),
                election.isConfirmed(player.getUniqueId()), true);
        return ActionResult.SUCCESS;
    }

    public ActionResult vote(Civilization civ, Player voter, Player candidate) {
        Election election = activeElections.get(civ.getId().toLowerCase());
        if (election == null) return ActionResult.NO_ELECTION;
        if (election.getState() != ElectionState.VOTING) return ActionResult.WRONG_PHASE;
        if (!election.isCandidate(candidate.getUniqueId())) return ActionResult.INVALID_CANDIDATE;
        if (election.hasVoted(voter.getUniqueId())) return ActionResult.ALREADY_VOTED;

        // DB is the source of truth for duplicate prevention; mirror into memory on success.
        plugin.getStorageManager().recordVote(election.getId(), voter.getUniqueId(), candidate.getUniqueId())
                .thenAccept(success -> {
                    if (success) election.castVote(voter.getUniqueId(), candidate.getUniqueId());
                });
        return ActionResult.SUCCESS;
    }

    private void broadcastToCiv(Civilization civ, String message) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (civ.getMembers().contains(p.getUniqueId())) {
                p.sendMessage(message);
            }
        }
    }
}
