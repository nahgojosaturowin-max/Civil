package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import org.bukkit.command.CommandSender;

import java.util.Map;

public class MessageManager {

    private final CivilizationCore plugin;

    public MessageManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    private String prefix() {
        return color(plugin.getConfigManager().getConfig().getString("messages.prefix", ""));
    }

    public String color(String input) {
        if (input == null) return "";
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', input);
    }

    /** Fetches messages.<key> from config, applies placeholders, colorizes. No prefix. */
    public String raw(String key, Map<String, String> placeholders) {
        String msg = plugin.getConfigManager().getConfig().getString("messages." + key, key);
        if (placeholders != null) {
            for (Map.Entry<String, String> e : placeholders.entrySet()) {
                msg = msg.replace("%" + e.getKey() + "%", e.getValue());
            }
        }
        return color(msg);
    }

    public String raw(String key) {
        return raw(key, null);
    }

    /** Sends messages.<key> to the sender with the configured prefix. */
    public void send(CommandSender sender, String key, Map<String, String> placeholders) {
        sender.sendMessage(prefix() + raw(key, placeholders));
    }

    public void send(CommandSender sender, String key) {
        send(sender, key, null);
    }

    /** Sends a raw pre-built message (already colorized) with prefix. */
    public void sendRaw(CommandSender sender, String message) {
        sender.sendMessage(prefix() + color(message));
    }
}
