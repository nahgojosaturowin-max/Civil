package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.DiplomacyRequest;
import com.civilizationcore.model.DiplomacyStatus;
import com.civilizationcore.model.RelationType;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Owns diplomatic relationships between civilizations and the pending
 * request flow that changes them. Relationships are always bilateral -
 * a request only takes effect once the target civilization's leader
 * accepts it - and the manager actively refuses to create a relation that
 * would conflict with an existing one (e.g. proposing ALLY while WAR is
 * already active for that pair).
 *
 * Note: WAR is modeled here purely as a diplomatic label per the Part 2
 * PRD (section 11). No combat, territory, or war-resolution mechanics are
 * implemented - that's explicitly out of scope until Part 3.
 */
public class DiplomacyManager {

    private final CivilizationCore plugin;

    // canonical "civA|civB" -> relation
    private final Map<String, RelationType> relations = new ConcurrentHashMap<>();

    // one pending request per (requester, target) pair at a time, keyed by "requester|target"
    private final Map<String, DiplomacyRequest> pendingRequests = new ConcurrentHashMap<>();

    public DiplomacyManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public CompletableFuture<Void> loadAll() {
        relations.clear();
        return plugin.getStorageManager().loadAllRelations().thenAccept(relations::putAll);
    }

    private String canonicalKey(String civA, String civB) {
        return civA.compareTo(civB) <= 0 ? civA + "|" + civB : civB + "|" + civA;
    }

    public RelationType getRelation(String civA, String civB) {
        if (civA.equalsIgnoreCase(civB)) return RelationType.NEUTRAL;
        return relations.getOrDefault(canonicalKey(civA, civB), RelationType.NEUTRAL);
    }

    private void setRelation(String civA, String civB, RelationType relation) {
        relations.put(canonicalKey(civA, civB), relation);
        plugin.getStorageManager().saveRelation(civA, civB, relation);
    }

    /**
     * Checks whether proposing `type` between civA and civB would conflict
     * with their current relationship (e.g. ALLY while WAR is active).
     */
    public Optional<RelationType> findConflict(String civA, String civB, RelationType type) {
        RelationType current = getRelation(civA, civB);
        if (current.conflictsWith(type)) return Optional.of(current);
        return Optional.empty();
    }

    private String requestKey(String requesterCiv, String targetCiv) {
        return requesterCiv + "|" + targetCiv;
    }

    /** Creates a new pending request from requesterCiv to targetCiv. Overwrites any prior pending request in that direction. */
    public DiplomacyRequest createRequest(String requesterCiv, String targetCiv, RelationType type) {
        DiplomacyRequest request = new DiplomacyRequest(requesterCiv, targetCiv, type);
        pendingRequests.put(requestKey(requesterCiv, targetCiv), request);
        plugin.getStorageManager().createDiplomacyRequest(request).thenAccept(request::setId);
        return request;
    }

    /** Finds a pending request FROM otherCiv TO viewingCiv (i.e. one viewingCiv can accept/deny). */
    public Optional<DiplomacyRequest> findIncomingRequest(String viewingCiv, String otherCiv) {
        DiplomacyRequest request = pendingRequests.get(requestKey(otherCiv, viewingCiv));
        if (request != null && request.getStatus() == DiplomacyStatus.PENDING) return Optional.of(request);
        return Optional.empty();
    }

    /** Finds any single pending incoming request for a civilization, regardless of sender - used when the command omits a target. */
    public Optional<DiplomacyRequest> findAnyIncomingRequest(String viewingCiv) {
        return pendingRequests.values().stream()
                .filter(r -> r.getStatus() == DiplomacyStatus.PENDING && r.getTargetCivId().equalsIgnoreCase(viewingCiv))
                .findFirst();
    }

    public Optional<DiplomacyRequest> findOutgoingRequest(String requesterCiv, String targetCiv) {
        DiplomacyRequest request = pendingRequests.get(requestKey(requesterCiv, targetCiv));
        if (request != null && request.getStatus() == DiplomacyStatus.PENDING) return Optional.of(request);
        return Optional.empty();
    }

    /** Accepts a request: applies the relation to both civilizations and marks it resolved. */
    public void acceptRequest(DiplomacyRequest request) {
        setRelation(request.getRequesterCivId(), request.getTargetCivId(), request.getRelationType());
        request.setStatus(DiplomacyStatus.ACCEPTED);
        plugin.getStorageManager().updateDiplomacyRequestStatus(request.getId(), DiplomacyStatus.ACCEPTED);
        pendingRequests.remove(requestKey(request.getRequesterCivId(), request.getTargetCivId()));
    }

    public void denyRequest(DiplomacyRequest request) {
        request.setStatus(DiplomacyStatus.DENIED);
        plugin.getStorageManager().updateDiplomacyRequestStatus(request.getId(), DiplomacyStatus.DENIED);
        pendingRequests.remove(requestKey(request.getRequesterCivId(), request.getTargetCivId()));
    }

    public void cancelRequest(DiplomacyRequest request) {
        request.setStatus(DiplomacyStatus.CANCELLED);
        plugin.getStorageManager().updateDiplomacyRequestStatus(request.getId(), DiplomacyStatus.CANCELLED);
        pendingRequests.remove(requestKey(request.getRequesterCivId(), request.getTargetCivId()));
    }

    /** All non-NEUTRAL relations involving the given civilization, keyed by the other civilization's id. */
    public Map<String, RelationType> getRelationsFor(String civId) {
        Map<String, RelationType> result = new HashMap<>();
        for (Map.Entry<String, RelationType> entry : relations.entrySet()) {
            String[] parts = entry.getKey().split("\\|", 2);
            if (parts[0].equalsIgnoreCase(civId)) {
                result.put(parts[1], entry.getValue());
            } else if (parts[1].equalsIgnoreCase(civId)) {
                result.put(parts[0], entry.getValue());
            }
        }
        return result;
    }

    public boolean isAllianceFriendlyFireDisabled() {
        return !plugin.getConfigManager().getConfig().getBoolean("diplomacy.alliances.friendly-fire", false);
    }

    public boolean isAllianceChatShared() {
        return plugin.getConfigManager().getConfig().getBoolean("diplomacy.alliances.shared-chat", true);
    }

    public double getTradeFeeReduction() {
        return plugin.getConfigManager().getConfig().getDouble("diplomacy.trade.fee-reduction-percentage", 10);
    }
}
