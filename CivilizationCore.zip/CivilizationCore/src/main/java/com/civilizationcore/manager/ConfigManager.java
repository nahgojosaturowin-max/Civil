package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import org.bukkit.configuration.file.FileConfiguration;

/**
 * Thin wrapper around the plugin's config.yml. Centralizing access here
 * means other managers never call plugin.getConfig() directly, so reload
 * behaviour stays consistent in one place.
 */
public class ConfigManager {

    private final CivilizationCore plugin;

    public ConfigManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
    }

    public void reload() {
        plugin.reloadConfig();
    }

    public FileConfiguration getConfig() {
        return plugin.getConfig();
    }

    public boolean isSwitchingEnabled() {
        return getConfig().getBoolean("switching.enabled", true);
    }

    public String getSwitchModeRaw() {
        return getConfig().getString("switching.mode", "COOLDOWN");
    }

    public String getSwitchCooldownRaw() {
        return getConfig().getString("switching.cooldown", "7d");
    }

    public boolean isScoreboardEnabled() {
        return getConfig().getBoolean("scoreboard.enabled", true);
    }

    public int getScoreboardUpdateInterval() {
        return getConfig().getInt("scoreboard.update-interval-ticks", 40);
    }
}
