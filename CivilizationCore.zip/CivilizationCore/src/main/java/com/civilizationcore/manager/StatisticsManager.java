package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;

import java.util.Comparator;
import java.util.List;
import java.util.function.ToDoubleFunction;

/**
 * Provides sortable leaderboard views over the civilizations' cached
 * statistics. Part 2 populates members/wealth directly; wars, weapons, and
 * events are tracked fields ready for Part 3 to actually feed data into.
 */
public class StatisticsManager {

    public enum LeaderboardCategory {
        WARS, WEALTH, MEMBERS, WEAPONS, EVENTS, OVERALL
    }

    private final CivilizationCore plugin;

    public StatisticsManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    private double scoreFor(Civilization civ, LeaderboardCategory category) {
        return switch (category) {
            case WARS -> civ.getStats().getWarsWon();
            case WEALTH -> civ.getTreasuryBalance();
            case MEMBERS -> civ.getMemberCount();
            case WEAPONS -> civ.getStats().getWeaponsControlled();
            case EVENTS -> civ.getStats().getEventsWon();
            case OVERALL -> civ.getStats().getWarsWon() * 3.0
                    + civ.getStats().getEventsWon() * 2.0
                    + civ.getMemberCount()
                    + civ.getStats().getWeaponsControlled() * 2.0
                    + civ.getStats().getTerritory();
        };
    }

    public List<Civilization> leaderboard(LeaderboardCategory category) {
        ToDoubleFunction<Civilization> score = civ -> scoreFor(civ, category);
        return plugin.getCivilizationManager().getAll().stream()
                .sorted(Comparator.comparingDouble(score).reversed())
                .toList();
    }

    public static LeaderboardCategory parseCategory(String input) {
        if (input == null) return LeaderboardCategory.OVERALL;
        try {
            return LeaderboardCategory.valueOf(input.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return LeaderboardCategory.OVERALL;
        }
    }
}
