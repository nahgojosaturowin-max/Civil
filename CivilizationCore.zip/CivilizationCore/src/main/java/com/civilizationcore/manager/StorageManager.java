package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.*;

import java.io.File;
import java.sql.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;

/**
 * Owns the JDBC connection and all SQL. Every public method that touches the
 * database runs on a single background executor thread so the main server
 * thread is never blocked. Callers get a CompletableFuture back and should
 * hop back to the main thread (via Bukkit scheduler) before touching Bukkit
 * API objects with the result.
 *
 * Only SQLite is implemented, but all access goes through this class and
 * plain JDBC, so adding a MySQL/MariaDB backend later only means changing
 * how the Connection is opened plus swapping any SQLite-specific syntax
 * (there is very little of it here - mainly the upsert "ON CONFLICT" clauses,
 * which MySQL spells differently).
 */
public class StorageManager {

    private final CivilizationCore plugin;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "CivilizationCore-DB");
        t.setDaemon(true);
        return t;
    });

    private Connection connection;

    public StorageManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public void init() {
        try {
            File dataFolder = plugin.getDataFolder();
            if (!dataFolder.exists()) dataFolder.mkdirs();
            String fileName = plugin.getConfigManager().getConfig().getString("database.file", "civilizationcore.db");
            File dbFile = new File(dataFolder, fileName);

            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());

            try (Statement st = connection.createStatement()) {
                st.execute("PRAGMA journal_mode=WAL;");
                st.execute("PRAGMA foreign_keys=ON;");
            }

            createTables();
            migrateSchema();
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to initialize database", e);
        }
    }

    private void createTables() throws SQLException {
        try (Statement st = connection.createStatement()) {
            st.execute("""
                CREATE TABLE IF NOT EXISTS civilizations (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    color TEXT NOT NULL,
                    prefix TEXT NOT NULL,
                    leader_uuid TEXT,
                    capital_world TEXT,
                    capital_x REAL,
                    capital_y REAL,
                    capital_z REAL,
                    wars_won INTEGER NOT NULL DEFAULT 0,
                    wars_lost INTEGER NOT NULL DEFAULT 0,
                    treasury REAL NOT NULL DEFAULT 0,
                    events_won INTEGER NOT NULL DEFAULT 0,
                    territory INTEGER NOT NULL DEFAULT 0,
                    weapons_controlled INTEGER NOT NULL DEFAULT 0
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS players (
                    uuid TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    civilization TEXT,
                    leader INTEGER NOT NULL DEFAULT 0,
                    join_date INTEGER NOT NULL DEFAULT 0,
                    last_switch INTEGER NOT NULL DEFAULT 0
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS elections (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    civilization TEXT NOT NULL,
                    state TEXT NOT NULL,
                    nomination_ends_at INTEGER NOT NULL,
                    voting_ends_at INTEGER NOT NULL,
                    created_at INTEGER NOT NULL,
                    winner_uuid TEXT
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS election_candidates (
                    election_id INTEGER NOT NULL,
                    candidate_uuid TEXT NOT NULL,
                    confirmed INTEGER NOT NULL DEFAULT 0,
                    withdrawn INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (election_id, candidate_uuid)
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS election_votes (
                    election_id INTEGER NOT NULL,
                    voter_uuid TEXT NOT NULL,
                    candidate_uuid TEXT NOT NULL,
                    timestamp INTEGER NOT NULL,
                    PRIMARY KEY (election_id, voter_uuid)
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    civilization TEXT NOT NULL,
                    player_uuid TEXT,
                    amount REAL NOT NULL,
                    type TEXT NOT NULL,
                    timestamp INTEGER NOT NULL,
                    reason TEXT
                );
            """);

            // Relationships are stored as one row per unordered pair, with
            // civ_a/civ_b always written in a canonical (sorted) order so a
            // pair is never represented by two contradictory rows.
            st.execute("""
                CREATE TABLE IF NOT EXISTS diplomacy_relations (
                    civ_a TEXT NOT NULL,
                    civ_b TEXT NOT NULL,
                    relation TEXT NOT NULL,
                    updated_at INTEGER NOT NULL,
                    PRIMARY KEY (civ_a, civ_b)
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS diplomacy_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    requester_civ TEXT NOT NULL,
                    target_civ TEXT NOT NULL,
                    relation_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at INTEGER NOT NULL
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS weapons (
                    id TEXT PRIMARY KEY,
                    original_civilization TEXT NOT NULL,
                    current_civilization TEXT NOT NULL,
                    instance_id TEXT NOT NULL
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS wars (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    attacker_civ TEXT NOT NULL,
                    defender_civ TEXT NOT NULL,
                    type TEXT NOT NULL,
                    state TEXT NOT NULL,
                    scheduled_start INTEGER NOT NULL DEFAULT 0,
                    started_at INTEGER NOT NULL DEFAULT 0,
                    ended_at INTEGER NOT NULL DEFAULT 0,
                    duration_millis INTEGER NOT NULL DEFAULT 0,
                    objective TEXT,
                    target_weapon TEXT,
                    winner_civ TEXT
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS seasons (
                    number INTEGER PRIMARY KEY,
                    start_date INTEGER NOT NULL,
                    end_date INTEGER NOT NULL DEFAULT 0,
                    state TEXT NOT NULL,
                    winner_civ TEXT,
                    grace_ends_at INTEGER NOT NULL DEFAULT 0
                );
            """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS hall_of_fame (
                    season_number INTEGER PRIMARY KEY,
                    winner_civ_id TEXT NOT NULL,
                    winner_civ_name TEXT NOT NULL,
                    leader_uuid TEXT,
                    leader_name TEXT,
                    start_date INTEGER NOT NULL,
                    end_date INTEGER NOT NULL
                );
            """);
        }
    }

    /** Adds columns to tables created by earlier plugin versions (Part 1 installs upgrading to Part 2). */
    private void migrateSchema() {
        addColumnIfMissing("civilizations", "treasury", "REAL NOT NULL DEFAULT 0");
        addColumnIfMissing("civilizations", "events_won", "INTEGER NOT NULL DEFAULT 0");
        addColumnIfMissing("civilizations", "territory", "INTEGER NOT NULL DEFAULT 0");
        addColumnIfMissing("civilizations", "weapons_controlled", "INTEGER NOT NULL DEFAULT 0");
    }

    private void addColumnIfMissing(String table, String column, String definition) {
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("PRAGMA table_info(" + table + ");")) {
            while (rs.next()) {
                if (rs.getString("name").equalsIgnoreCase(column)) {
                    return; // already present
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Failed to inspect schema for " + table, e);
            return;
        }
        try (Statement st = connection.createStatement()) {
            st.execute("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition + ";");
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Failed to add column " + column + " to " + table, e);
        }
    }

    public void shutdown() {
        executor.shutdown();
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Error closing database connection", e);
        }
    }

    public ExecutorService getExecutor() {
        return executor;
    }

    // ---------------------------------------------------------------
    // Civilizations
    // ---------------------------------------------------------------

    /** Inserts a civilization row if it doesn't already exist. Runs async. */
    public CompletableFuture<Void> ensureCivilizationExists(Civilization civ) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                INSERT OR IGNORE INTO civilizations (id, name, color, prefix)
                VALUES (?, ?, ?, ?);
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, civ.getId());
                ps.setString(2, civ.getName());
                ps.setString(3, civ.getColor());
                ps.setString(4, civ.getPrefix());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to ensure civilization row for " + civ.getId(), e);
            }
        }, executor);
    }

    public CompletableFuture<List<Civilization>> loadCivilizations(Map<String, String[]> defaults) {
        return CompletableFuture.supplyAsync(() -> {
            List<Civilization> result = new ArrayList<>();
            String sql = "SELECT * FROM civilizations;";
            try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    Civilization civ = new Civilization(
                            rs.getString("id"),
                            rs.getString("name"),
                            rs.getString("color"),
                            rs.getString("prefix")
                    );
                    String leaderUuid = rs.getString("leader_uuid");
                    if (leaderUuid != null) civ.setLeaderUuid(UUID.fromString(leaderUuid));

                    String capitalWorld = rs.getString("capital_world");
                    if (capitalWorld != null) {
                        civ.setCapitalRaw(capitalWorld, rs.getDouble("capital_x"),
                                rs.getDouble("capital_y"), rs.getDouble("capital_z"));
                    }

                    civ.getStats().setWarsWon(rs.getInt("wars_won"));
                    civ.getStats().setWarsLost(rs.getInt("wars_lost"));
                    civ.getStats().setEventsWon(rs.getInt("events_won"));
                    civ.getStats().setTerritory(rs.getInt("territory"));
                    civ.getStats().setWeaponsControlled(rs.getInt("weapons_controlled"));
                    civ.setTreasuryBalance(rs.getDouble("treasury"));

                    result.add(civ);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load civilizations", e);
            }
            return result;
        }, executor);
    }

    public CompletableFuture<Void> saveCivilization(Civilization civ) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                INSERT INTO civilizations (id, name, color, prefix, leader_uuid,
                    capital_world, capital_x, capital_y, capital_z, wars_won, wars_lost,
                    treasury, events_won, territory, weapons_controlled)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name,
                    color=excluded.color,
                    prefix=excluded.prefix,
                    leader_uuid=excluded.leader_uuid,
                    capital_world=excluded.capital_world,
                    capital_x=excluded.capital_x,
                    capital_y=excluded.capital_y,
                    capital_z=excluded.capital_z,
                    wars_won=excluded.wars_won,
                    wars_lost=excluded.wars_lost,
                    treasury=excluded.treasury,
                    events_won=excluded.events_won,
                    territory=excluded.territory,
                    weapons_controlled=excluded.weapons_controlled;
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, civ.getId());
                ps.setString(2, civ.getName());
                ps.setString(3, civ.getColor());
                ps.setString(4, civ.getPrefix());
                ps.setString(5, civ.getLeaderUuid() != null ? civ.getLeaderUuid().toString() : null);
                if (civ.hasCapital()) {
                    ps.setString(6, civ.getCapitalWorld());
                    ps.setDouble(7, civ.getCapitalX());
                    ps.setDouble(8, civ.getCapitalY());
                    ps.setDouble(9, civ.getCapitalZ());
                } else {
                    ps.setNull(6, Types.VARCHAR);
                    ps.setNull(7, Types.REAL);
                    ps.setNull(8, Types.REAL);
                    ps.setNull(9, Types.REAL);
                }
                ps.setInt(10, civ.getStats().getWarsWon());
                ps.setInt(11, civ.getStats().getWarsLost());
                ps.setDouble(12, civ.getTreasuryBalance());
                ps.setInt(13, civ.getStats().getEventsWon());
                ps.setInt(14, civ.getStats().getTerritory());
                ps.setInt(15, civ.getStats().getWeaponsControlled());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to save civilization " + civ.getId(), e);
            }
        }, executor);
    }

    // ---------------------------------------------------------------
    // Players
    // ---------------------------------------------------------------

    public CompletableFuture<Optional<CivPlayer>> loadPlayer(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            String sql = "SELECT * FROM players WHERE uuid = ?;";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) return Optional.<CivPlayer>empty();
                    CivPlayer cp = new CivPlayer(uuid, rs.getString("name"));
                    cp.setCivilizationId(rs.getString("civilization"));
                    cp.setLeader(rs.getInt("leader") == 1);
                    cp.setJoinTimestamp(rs.getLong("join_date"));
                    cp.setLastSwitchTimestamp(rs.getLong("last_switch"));
                    return Optional.of(cp);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load player " + uuid, e);
                return Optional.<CivPlayer>empty();
            }
        }, executor);
    }

    public CompletableFuture<List<CivPlayer>> loadAllPlayers() {
        return CompletableFuture.supplyAsync(() -> {
            List<CivPlayer> result = new ArrayList<>();
            String sql = "SELECT * FROM players;";
            try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    CivPlayer cp = new CivPlayer(UUID.fromString(rs.getString("uuid")), rs.getString("name"));
                    cp.setCivilizationId(rs.getString("civilization"));
                    cp.setLeader(rs.getInt("leader") == 1);
                    cp.setJoinTimestamp(rs.getLong("join_date"));
                    cp.setLastSwitchTimestamp(rs.getLong("last_switch"));
                    result.add(cp);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load all players", e);
            }
            return result;
        }, executor);
    }

    public CompletableFuture<Void> savePlayer(CivPlayer cp) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                INSERT INTO players (uuid, name, civilization, leader, join_date, last_switch)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(uuid) DO UPDATE SET
                    name=excluded.name,
                    civilization=excluded.civilization,
                    leader=excluded.leader,
                    join_date=excluded.join_date,
                    last_switch=excluded.last_switch;
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, cp.getUuid().toString());
                ps.setString(2, cp.getName());
                ps.setString(3, cp.getCivilizationId());
                ps.setInt(4, cp.isLeader() ? 1 : 0);
                ps.setLong(5, cp.getJoinTimestamp());
                ps.setLong(6, cp.getLastSwitchTimestamp());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to save player " + cp.getUuid(), e);
            }
        }, executor);
    }

    // ---------------------------------------------------------------
    // Elections
    // ---------------------------------------------------------------

    /** Inserts a new election row and returns the generated id via the Election object passed in. */
    public CompletableFuture<Long> createElection(Election election) {
        return CompletableFuture.supplyAsync(() -> {
            String sql = """
                INSERT INTO elections (civilization, state, nomination_ends_at, voting_ends_at, created_at, winner_uuid)
                VALUES (?, ?, ?, ?, ?, ?);
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, election.getCivilizationId());
                ps.setString(2, election.getState().name());
                ps.setLong(3, election.getNominationEndsAt());
                ps.setLong(4, election.getVotingEndsAt());
                ps.setLong(5, System.currentTimeMillis());
                ps.setString(6, election.getWinner() != null ? election.getWinner().toString() : null);
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) return keys.getLong(1);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to create election for " + election.getCivilizationId(), e);
            }
            return -1L;
        }, executor);
    }

    public CompletableFuture<Void> updateElection(Election election) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                UPDATE elections SET state=?, nomination_ends_at=?, voting_ends_at=?, winner_uuid=?
                WHERE id=?;
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, election.getState().name());
                ps.setLong(2, election.getNominationEndsAt());
                ps.setLong(3, election.getVotingEndsAt());
                ps.setString(4, election.getWinner() != null ? election.getWinner().toString() : null);
                ps.setLong(5, election.getId());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to update election " + election.getId(), e);
            }
        }, executor);
    }

    public CompletableFuture<Void> saveCandidate(long electionId, UUID candidate, boolean confirmed, boolean withdrawn) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                INSERT INTO election_candidates (election_id, candidate_uuid, confirmed, withdrawn)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(election_id, candidate_uuid) DO UPDATE SET
                    confirmed=excluded.confirmed,
                    withdrawn=excluded.withdrawn;
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setLong(1, electionId);
                ps.setString(2, candidate.toString());
                ps.setInt(3, confirmed ? 1 : 0);
                ps.setInt(4, withdrawn ? 1 : 0);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to save election candidate", e);
            }
        }, executor);
    }

    /**
     * Attempts to record a vote. Relies on the (election_id, voter_uuid)
     * primary key to make duplicate voting impossible even under concurrent
     * calls - returns false if the voter already has a row for this election.
     */
    public CompletableFuture<Boolean> recordVote(long electionId, UUID voter, UUID candidate) {
        return CompletableFuture.supplyAsync(() -> {
            String sql = """
                INSERT OR IGNORE INTO election_votes (election_id, voter_uuid, candidate_uuid, timestamp)
                VALUES (?, ?, ?, ?);
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setLong(1, electionId);
                ps.setString(2, voter.toString());
                ps.setString(3, candidate.toString());
                ps.setLong(4, System.currentTimeMillis());
                int rows = ps.executeUpdate();
                return rows > 0;
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to record vote", e);
                return false;
            }
        }, executor);
    }

    // ---------------------------------------------------------------
    // Transactions (treasury ledger)
    // ---------------------------------------------------------------

    public CompletableFuture<Void> logTransaction(String civId, UUID player, double amount, TransactionType type, String reason) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                INSERT INTO transactions (civilization, player_uuid, amount, type, timestamp, reason)
                VALUES (?, ?, ?, ?, ?, ?);
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, civId);
                ps.setString(2, player != null ? player.toString() : null);
                ps.setDouble(3, amount);
                ps.setString(4, type.name());
                ps.setLong(5, System.currentTimeMillis());
                ps.setString(6, reason);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to log transaction for " + civId, e);
            }
        }, executor);
    }

    public CompletableFuture<List<Transaction>> loadRecentTransactions(String civId, int limit) {
        return CompletableFuture.supplyAsync(() -> {
            List<Transaction> result = new ArrayList<>();
            String sql = "SELECT * FROM transactions WHERE civilization = ? ORDER BY timestamp DESC LIMIT ?;";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, civId);
                ps.setInt(2, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String playerStr = rs.getString("player_uuid");
                        result.add(new Transaction(
                                rs.getLong("id"),
                                rs.getString("civilization"),
                                playerStr != null ? UUID.fromString(playerStr) : null,
                                rs.getDouble("amount"),
                                TransactionType.valueOf(rs.getString("type")),
                                rs.getLong("timestamp"),
                                rs.getString("reason")
                        ));
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load transactions for " + civId, e);
            }
            return result;
        }, executor);
    }

    // ---------------------------------------------------------------
    // Diplomacy
    // ---------------------------------------------------------------

    private String[] canonicalPair(String civA, String civB) {
        return civA.compareTo(civB) <= 0 ? new String[]{civA, civB} : new String[]{civB, civA};
    }

    public CompletableFuture<Void> saveRelation(String civA, String civB, RelationType relation) {
        return CompletableFuture.runAsync(() -> {
            String[] pair = canonicalPair(civA, civB);
            String sql = """
                INSERT INTO diplomacy_relations (civ_a, civ_b, relation, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(civ_a, civ_b) DO UPDATE SET relation=excluded.relation, updated_at=excluded.updated_at;
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, pair[0]);
                ps.setString(2, pair[1]);
                ps.setString(3, relation.name());
                ps.setLong(4, System.currentTimeMillis());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to save diplomacy relation", e);
            }
        }, executor);
    }

    /** Loads every stored relation as civA|civB -> RelationType, keyed by the canonical pair joined with "|". */
    public CompletableFuture<Map<String, RelationType>> loadAllRelations() {
        return CompletableFuture.supplyAsync(() -> {
            Map<String, RelationType> result = new HashMap<>();
            String sql = "SELECT * FROM diplomacy_relations;";
            try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    String key = rs.getString("civ_a") + "|" + rs.getString("civ_b");
                    RelationType type = RelationType.fromString(rs.getString("relation"));
                    if (type != null) result.put(key, type);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load diplomacy relations", e);
            }
            return result;
        }, executor);
    }

    public CompletableFuture<Long> createDiplomacyRequest(DiplomacyRequest request) {
        return CompletableFuture.supplyAsync(() -> {
            String sql = """
                INSERT INTO diplomacy_requests (requester_civ, target_civ, relation_type, status, created_at)
                VALUES (?, ?, ?, ?, ?);
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, request.getRequesterCivId());
                ps.setString(2, request.getTargetCivId());
                ps.setString(3, request.getRelationType().name());
                ps.setString(4, request.getStatus().name());
                ps.setLong(5, request.getCreatedAt());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) return keys.getLong(1);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to create diplomacy request", e);
            }
            return -1L;
        }, executor);
    }

    public CompletableFuture<Void> updateDiplomacyRequestStatus(long id, DiplomacyStatus status) {
        return CompletableFuture.runAsync(() -> {
            String sql = "UPDATE diplomacy_requests SET status=? WHERE id=?;";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, status.name());
                ps.setLong(2, id);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to update diplomacy request " + id, e);
            }
        }, executor);
    }

    // ---------------------------------------------------------------
    // Legendary Weapons
    // ---------------------------------------------------------------

    public CompletableFuture<Void> saveWeapon(LegendaryWeapon weapon) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                INSERT INTO weapons (id, original_civilization, current_civilization, instance_id)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    current_civilization=excluded.current_civilization,
                    instance_id=excluded.instance_id;
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, weapon.getId());
                ps.setString(2, weapon.getOriginalCivilizationId());
                ps.setString(3, weapon.getCurrentCivilizationId());
                ps.setString(4, weapon.getInstanceId().toString());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to save weapon " + weapon.getId(), e);
            }
        }, executor);
    }

    /** Returns id -> (currentCivilization, instanceId) for every persisted weapon row. */
    public CompletableFuture<Map<String, String[]>> loadWeaponState() {
        return CompletableFuture.supplyAsync(() -> {
            Map<String, String[]> result = new HashMap<>();
            String sql = "SELECT * FROM weapons;";
            try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    result.put(rs.getString("id"), new String[]{rs.getString("current_civilization"), rs.getString("instance_id")});
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load weapon state", e);
            }
            return result;
        }, executor);
    }

    // ---------------------------------------------------------------
    // Wars
    // ---------------------------------------------------------------

    public CompletableFuture<Long> createWar(War war) {
        return CompletableFuture.supplyAsync(() -> {
            String sql = """
                INSERT INTO wars (attacker_civ, defender_civ, type, state, scheduled_start,
                    started_at, ended_at, duration_millis, objective, target_weapon, winner_civ)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                bindWar(ps, war);
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) return keys.getLong(1);
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to create war", e);
            }
            return -1L;
        }, executor);
    }

    public CompletableFuture<Void> updateWar(War war) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                UPDATE wars SET attacker_civ=?, defender_civ=?, type=?, state=?, scheduled_start=?,
                    started_at=?, ended_at=?, duration_millis=?, objective=?, target_weapon=?, winner_civ=?
                WHERE id=?;
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                bindWar(ps, war);
                ps.setLong(12, war.getId());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to update war " + war.getId(), e);
            }
        }, executor);
    }

    private void bindWar(PreparedStatement ps, War war) throws SQLException {
        ps.setString(1, war.getAttackerCivId());
        ps.setString(2, war.getDefenderCivId());
        ps.setString(3, war.getType().name());
        ps.setString(4, war.getState().name());
        ps.setLong(5, war.getScheduledStart());
        ps.setLong(6, war.getStartedAt());
        ps.setLong(7, war.getEndedAt());
        ps.setLong(8, war.getDurationMillis());
        ps.setString(9, war.getObjective());
        ps.setString(10, war.getTargetWeaponId());
        ps.setString(11, war.getWinnerCivId());
    }

    /** Loads wars that are not in a terminal state (FINISHED/CANCELLED), for restoring after a restart. */
    public CompletableFuture<List<War>> loadActiveWars() {
        return CompletableFuture.supplyAsync(() -> {
            List<War> result = new ArrayList<>();
            String sql = "SELECT * FROM wars WHERE state NOT IN ('FINISHED', 'CANCELLED');";
            try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    result.add(warFromResultSet(rs));
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load active wars", e);
            }
            return result;
        }, executor);
    }

    private War warFromResultSet(ResultSet rs) throws SQLException {
        War war = new War(rs.getString("attacker_civ"), rs.getString("defender_civ"), WarType.valueOf(rs.getString("type")));
        war.setId(rs.getLong("id"));
        war.setState(WarState.valueOf(rs.getString("state")));
        war.setScheduledStart(rs.getLong("scheduled_start"));
        war.setStartedAt(rs.getLong("started_at"));
        war.setEndedAt(rs.getLong("ended_at"));
        war.setDurationMillis(rs.getLong("duration_millis"));
        war.setObjective(rs.getString("objective"));
        war.setTargetWeaponId(rs.getString("target_weapon"));
        war.setWinnerCivId(rs.getString("winner_civ"));
        return war;
    }

    // ---------------------------------------------------------------
    // Seasons & Hall of Fame
    // ---------------------------------------------------------------

    public CompletableFuture<Void> saveSeason(Season season) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                INSERT INTO seasons (number, start_date, end_date, state, winner_civ, grace_ends_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(number) DO UPDATE SET
                    end_date=excluded.end_date, state=excluded.state,
                    winner_civ=excluded.winner_civ, grace_ends_at=excluded.grace_ends_at;
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setInt(1, season.getNumber());
                ps.setLong(2, season.getStartDate());
                ps.setLong(3, season.getEndDate());
                ps.setString(4, season.getState().name());
                ps.setString(5, season.getWinnerCivId());
                ps.setLong(6, season.getGraceEndsAt());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to save season " + season.getNumber(), e);
            }
        }, executor);
    }

    /** Loads the most recent season row (highest number), if any. */
    public CompletableFuture<Optional<Season>> loadCurrentSeason() {
        return CompletableFuture.supplyAsync(() -> {
            String sql = "SELECT * FROM seasons ORDER BY number DESC LIMIT 1;";
            try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                if (!rs.next()) return Optional.<Season>empty();
                Season season = new Season(rs.getInt("number"), rs.getLong("start_date"));
                season.setEndDate(rs.getLong("end_date"));
                season.setState(SeasonState.valueOf(rs.getString("state")));
                season.setWinnerCivId(rs.getString("winner_civ"));
                season.setGraceEndsAt(rs.getLong("grace_ends_at"));
                return Optional.of(season);
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load current season", e);
                return Optional.<Season>empty();
            }
        }, executor);
    }

    public CompletableFuture<Void> saveHallOfFameEntry(HallOfFameEntry entry) {
        return CompletableFuture.runAsync(() -> {
            String sql = """
                INSERT INTO hall_of_fame (season_number, winner_civ_id, winner_civ_name, leader_uuid, leader_name, start_date, end_date)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(season_number) DO UPDATE SET
                    winner_civ_id=excluded.winner_civ_id, winner_civ_name=excluded.winner_civ_name,
                    leader_uuid=excluded.leader_uuid, leader_name=excluded.leader_name,
                    start_date=excluded.start_date, end_date=excluded.end_date;
            """;
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setInt(1, entry.getSeasonNumber());
                ps.setString(2, entry.getWinnerCivId());
                ps.setString(3, entry.getWinnerCivName());
                ps.setString(4, entry.getLeaderUuid());
                ps.setString(5, entry.getLeaderName());
                ps.setLong(6, entry.getStartDate());
                ps.setLong(7, entry.getEndDate());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to save hall of fame entry for season " + entry.getSeasonNumber(), e);
            }
        }, executor);
    }

    public CompletableFuture<List<HallOfFameEntry>> loadHallOfFame() {
        return CompletableFuture.supplyAsync(() -> {
            List<HallOfFameEntry> result = new ArrayList<>();
            String sql = "SELECT * FROM hall_of_fame ORDER BY season_number ASC;";
            try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    result.add(new HallOfFameEntry(
                            rs.getInt("season_number"),
                            rs.getString("winner_civ_id"),
                            rs.getString("winner_civ_name"),
                            rs.getString("leader_uuid"),
                            rs.getString("leader_name"),
                            rs.getLong("start_date"),
                            rs.getLong("end_date")
                    ));
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load hall of fame", e);
            }
            return result;
        }, executor);
    }

    /** Wipes war and weapon-history rows for a fresh season. Player/civilization identity rows are untouched. */
    public CompletableFuture<Void> clearSeasonData() {
        return CompletableFuture.runAsync(() -> {
            try (Statement st = connection.createStatement()) {
                st.execute("DELETE FROM wars;");
                st.execute("DELETE FROM transactions;");
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to clear season data", e);
            }
        }, executor);
    }
}
