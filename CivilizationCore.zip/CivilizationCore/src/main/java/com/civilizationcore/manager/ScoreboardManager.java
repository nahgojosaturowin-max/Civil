package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.CivPlayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.ArrayList;
import java.util.List;

/**
 * Renders a simple per-player sidebar scoreboard with civilization info.
 * Runs on a repeating task at the interval configured under
 * scoreboard.update-interval-ticks. Kept intentionally simple in Part 1;
 * PlaceholderAPI values could be substituted into the lines below if
 * present, but no external placeholders are required for it to function.
 */
public class ScoreboardManager {

    private final CivilizationCore plugin;
    private BukkitTask task;

    public ScoreboardManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        stop();
        if (!plugin.getConfigManager().isScoreboardEnabled()) return;

        long interval = plugin.getConfigManager().getScoreboardUpdateInterval();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::updateAll, 20L, interval);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private void updateAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            update(player);
        }
    }

    public void update(Player player) {
        if (!plugin.getConfigManager().isScoreboardEnabled()) return;

        CivPlayer cp = plugin.getPlayerManager().get(player.getUniqueId()).orElse(null);
        if (cp == null || !cp.hasCivilization()) return;

        Civilization civ = plugin.getCivilizationManager().get(cp.getCivilizationId()).orElse(null);
        if (civ == null) return;

        org.bukkit.scoreboard.ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) return;

        Scoreboard board = manager.getNewScoreboard();
        String title = plugin.getMessageManager().color(
                plugin.getConfigManager().getConfig().getString("scoreboard.title", "&6&lCIVILIZATION SMP"));
        Objective objective = board.registerNewObjective("civcore", "dummy", title);
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        int season = plugin.getSeasonManager().getCurrentSeason() != null
                ? plugin.getSeasonManager().getCurrentSeason().getNumber()
                : plugin.getConfigManager().getConfig().getInt("scoreboard.season", 1);
        String leaderName = "Unclaimed";
        if (civ.hasLeader()) {
            var offline = Bukkit.getOfflinePlayer(civ.getLeaderUuid());
            leaderName = offline.getName() != null ? offline.getName() : "Unknown";
        }
        String capitalName = civ.hasCapital() ? civ.getCapitalWorld() : "Not set";

        List<String> lines = new ArrayList<>();
        lines.add(plugin.getMessageManager().color(civ.getPrefix() + " &f" + civ.getName()));
        lines.add(" ");
        lines.add(plugin.getMessageManager().color("&7Leader: &f" + leaderName));
        lines.add(plugin.getMessageManager().color("&7Members: &f" + civ.getMemberCount()));
        lines.add(plugin.getMessageManager().color("&7Capital: &f" + capitalName));
        lines.add(" ");
        lines.add(plugin.getMessageManager().color("&7Weapons:"));
        for (var weapon : plugin.getWeaponManager().getAll()) {
            boolean owned = weapon.getCurrentCivilizationId().equalsIgnoreCase(civ.getId());
            lines.add(plugin.getMessageManager().color((owned ? "&a\u2713 " : "&c\u2717 ") + "&f" + weapon.getDisplayName()));
        }
        lines.add(" ");
        lines.add(plugin.getMessageManager().color("&7Wars Won: &f" + civ.getStats().getWarsWon()));
        lines.add(plugin.getMessageManager().color("&7Treasury: &f" + String.format("%,.0f", civ.getTreasuryBalance())));
        lines.add(" ");
        lines.add(plugin.getMessageManager().color("&7Season: &f" + season));

        // Scoreboard lines must be unique; pad with invisible color codes if needed.
        int score = lines.size();
        int suffixCounter = 0;
        for (String line : lines) {
            String entry = line;
            while (board.getEntries().contains(entry)) {
                entry = line + "\u00A7".repeat(++suffixCounter);
            }
            objective.getScore(entry).setScore(score--);
        }

        player.setScoreboard(board);
    }

    public void clear(Player player) {
        org.bukkit.scoreboard.ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager != null) {
            player.setScoreboard(manager.getMainScoreboard());
        }
    }
}
