package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Owns the set of civilizations and their cached in-memory state (members,
 * leader, capital, stats). Civilization *definitions* (id/name/color/prefix)
 * come from config.yml; mutable state (leader, capital, members, stats) is
 * loaded from and persisted to the database via StorageManager.
 */
public class CivilizationManager {

    private final CivilizationCore plugin;
    private final Map<String, Civilization> civilizations = new ConcurrentHashMap<>();

    public CivilizationManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    /**
     * Reads civilization definitions from config, ensures DB rows exist,
     * then loads persisted state (leader/capital/stats) on top.
     * Returns a future that completes once everything is loaded.
     */
    public CompletableFuture<Void> loadAll() {
        civilizations.clear();

        ConfigurationSection section = plugin.getConfigManager().getConfig().getConfigurationSection("civilizations");
        if (section == null) {
            plugin.getLogger().warning("No 'civilizations' section found in config.yml!");
            return CompletableFuture.completedFuture(null);
        }

        List<CompletableFuture<Void>> ensureFutures = new ArrayList<>();

        for (String id : section.getKeys(false)) {
            String name = section.getString(id + ".name", id);
            String color = section.getString(id + ".color", "WHITE");
            String prefix = section.getString(id + ".prefix", "[" + id.toUpperCase() + "]");

            Civilization civ = new Civilization(id, name, color, prefix);
            civilizations.put(id, civ);

            ensureFutures.add(plugin.getStorageManager().ensureCivilizationExists(civ));
        }

        return CompletableFuture.allOf(ensureFutures.toArray(new CompletableFuture[0]))
                .thenCompose(v -> plugin.getStorageManager().loadCivilizations(Collections.emptyMap()))
                .thenAccept(loaded -> {
                    for (Civilization persisted : loaded) {
                        Civilization cached = civilizations.get(persisted.getId());
                        if (cached == null) continue; // civ removed from config
                        cached.setLeaderUuid(persisted.getLeaderUuid());
                        if (persisted.hasCapital()) {
                            cached.setCapitalRaw(persisted.getCapitalWorld(), persisted.getCapitalX(),
                                    persisted.getCapitalY(), persisted.getCapitalZ());
                        }
                        cached.getStats().setWarsWon(persisted.getStats().getWarsWon());
                        cached.getStats().setWarsLost(persisted.getStats().getWarsLost());
                    }
                });
    }

    public Collection<Civilization> getAll() {
        return civilizations.values();
    }

    public Optional<Civilization> get(String id) {
        if (id == null) return Optional.empty();
        return Optional.ofNullable(civilizations.get(id.toLowerCase()));
    }

    public boolean exists(String id) {
        return id != null && civilizations.containsKey(id.toLowerCase());
    }

    /** Returns the civilization(s) with the fewest members, for balanced assignment. */
    public List<Civilization> getLowestPopulation() {
        int min = Integer.MAX_VALUE;
        for (Civilization civ : civilizations.values()) {
            min = Math.min(min, civ.getMemberCount());
        }
        List<Civilization> result = new ArrayList<>();
        for (Civilization civ : civilizations.values()) {
            if (civ.getMemberCount() == min) result.add(civ);
        }
        return result;
    }

    public void save(Civilization civ) {
        plugin.getStorageManager().saveCivilization(civ);
    }

    public void saveAll() {
        for (Civilization civ : civilizations.values()) {
            plugin.getStorageManager().saveCivilization(civ);
        }
    }
}
