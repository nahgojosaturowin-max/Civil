package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import org.bukkit.Location;

import java.util.Optional;

/**
 * Provides territory queries. If a compatible external territory plugin has
 * registered a {@link TerritoryProvider} (via {@link #registerProvider}),
 * that provider answers every query. Otherwise, CivilizationCore falls back
 * to a basic sphere-around-the-capital model sized by
 * territory.capital-radius in config, per the PRD's fallback allowance.
 */
public class TerritoryManager {

    /** Implement this in an integration plugin and call registerProvider to replace the basic fallback. */
    public interface TerritoryProvider {
        boolean isCivilizationTerritory(Location location);

        /** Returns the owning civilization id, or null if unclaimed. */
        String getTerritoryOwner(Location location);

        boolean isCapital(Location location);
    }

    private final CivilizationCore plugin;
    private TerritoryProvider externalProvider;

    public TerritoryManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public void registerProvider(TerritoryProvider provider) {
        this.externalProvider = provider;
        plugin.getLogger().info("External territory provider registered - CivilizationCore's basic radius territory is now disabled.");
    }

    public void unregisterProvider() {
        this.externalProvider = null;
    }

    public boolean isCivilizationTerritory(Location location) {
        if (externalProvider != null) return externalProvider.isCivilizationTerritory(location);
        return getTerritoryOwner(location) != null;
    }

    public String getTerritoryOwner(Location location) {
        if (externalProvider != null) return externalProvider.getTerritoryOwner(location);

        double radius = plugin.getConfigManager().getConfig().getDouble("territory.capital-radius", 150);
        for (Civilization civ : plugin.getCivilizationManager().getAll()) {
            Location capital = civ.getCapitalLocation();
            if (capital == null) continue;
            if (!capital.getWorld().equals(location.getWorld())) continue;
            if (capital.distanceSquared(location) <= radius * radius) {
                return civ.getId();
            }
        }
        return null;
    }

    public boolean isCapital(Location location) {
        if (externalProvider != null) return externalProvider.isCapital(location);

        for (Civilization civ : plugin.getCivilizationManager().getAll()) {
            Location capital = civ.getCapitalLocation();
            if (capital == null) continue;
            if (capital.getWorld().equals(location.getWorld())
                    && capital.getBlockX() == location.getBlockX()
                    && capital.getBlockY() == location.getBlockY()
                    && capital.getBlockZ() == location.getBlockZ()) {
                return true;
            }
        }
        return false;
    }

    public Optional<Civilization> getOwningCivilization(Location location) {
        String ownerId = getTerritoryOwner(location);
        return ownerId != null ? plugin.getCivilizationManager().get(ownerId) : Optional.empty();
    }
}
