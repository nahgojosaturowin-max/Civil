package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.TransactionType;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.UUID;
import java.util.logging.Level;

/**
 * Bridges civilization treasuries to Vault's player economy. If Vault or a
 * compatible economy plugin is not installed, deposit/withdraw commands are
 * disabled but the rest of CivilizationCore (including the treasury balance
 * itself, which is plugin-owned data, not Vault's) keeps working normally.
 *
 * Also exposes a small API - {@link #depositToTreasury} - so other plugins
 * (event plugins, war systems, a future Part 3) can pay coins into a
 * civilization's treasury without needing direct database access.
 */
public class EconomyManager {

    private final CivilizationCore plugin;
    private Economy vaultEconomy;

    public EconomyManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    /** Attempts to hook Vault. Safe to call even if Vault isn't installed. */
    public void setup() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().info("Vault not found - civilization economy commands (deposit/withdraw) will be disabled.");
            return;
        }
        try {
            RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp != null) {
                vaultEconomy = rsp.getProvider();
                plugin.getLogger().info("Hooked into Vault economy: " + vaultEconomy.getName());
            } else {
                plugin.getLogger().warning("Vault is installed but no economy provider is registered yet.");
            }
        } catch (Throwable t) {
            plugin.getLogger().log(Level.WARNING, "Failed to hook Vault economy", t);
        }
    }

    public boolean isAvailable() {
        return vaultEconomy != null;
    }

    public boolean isEnabled() {
        return plugin.getConfigManager().getConfig().getBoolean("economy.enabled", true);
    }

    /** Player's personal Vault balance. Returns 0 if Vault is unavailable. */
    public double getPlayerBalance(OfflinePlayer player) {
        if (!isAvailable()) return 0;
        return vaultEconomy.getBalance(player);
    }

    public boolean hasEnough(OfflinePlayer player, double amount) {
        return isAvailable() && vaultEconomy.has(player, amount);
    }

    /**
     * Moves coins from a player's personal Vault balance into their
     * civilization's treasury, logging the transaction. Returns false if
     * Vault is unavailable or the player doesn't have enough.
     */
    public boolean deposit(Civilization civ, OfflinePlayer player, double amount, String reason) {
        if (!isAvailable() || amount <= 0) return false;
        if (!vaultEconomy.has(player, amount)) return false;

        var response = vaultEconomy.withdrawPlayer(player, amount);
        if (!response.transactionSuccess()) return false;

        civ.setTreasuryBalance(civ.getTreasuryBalance() + amount);
        plugin.getCivilizationManager().save(civ);
        plugin.getStorageManager().logTransaction(civ.getId(), player.getUniqueId(), amount, TransactionType.PLAYER_DEPOSIT, reason);
        return true;
    }

    /**
     * Moves coins out of a civilization's treasury into a player's personal
     * Vault balance. Caller is responsible for checking withdrawal
     * permission (see LeaderManager) before calling this.
     */
    public boolean withdraw(Civilization civ, OfflinePlayer player, double amount, String reason) {
        if (!isAvailable() || amount <= 0) return false;
        if (civ.getTreasuryBalance() < amount) return false;

        var response = vaultEconomy.depositPlayer(player, amount);
        if (!response.transactionSuccess()) return false;

        civ.setTreasuryBalance(civ.getTreasuryBalance() - amount);
        plugin.getCivilizationManager().save(civ);
        plugin.getStorageManager().logTransaction(civ.getId(), player.getUniqueId(), amount, TransactionType.PLAYER_WITHDRAW, reason);
        return true;
    }

    /**
     * Adds coins directly to a civilization's treasury with no player-side
     * Vault transaction - used for tax collection, war/event rewards, and
     * admin adjustments, and exposed for other plugins to hook into.
     */
    public void depositToTreasury(String civId, double amount, TransactionType type, UUID relatedPlayer, String reason) {
        plugin.getCivilizationManager().get(civId).ifPresent(civ -> {
            civ.setTreasuryBalance(civ.getTreasuryBalance() + amount);
            plugin.getCivilizationManager().save(civ);
            plugin.getStorageManager().logTransaction(civId, relatedPlayer, amount, type, reason);
        });
    }

    /**
     * Applies the configured tax percentage to a deposit amount and routes
     * the taxed portion into the treasury as a separate TAX transaction.
     * Returns the post-tax amount that actually reaches the treasury as a
     * player deposit (kept separate from the tax cut for clarity in the ledger).
     */
    public double applyTax(String civId, double grossAmount) {
        boolean taxEnabled = plugin.getConfigManager().getConfig().getBoolean("economy.tax.enabled", true);
        if (!taxEnabled) return grossAmount;

        double percentage = plugin.getConfigManager().getConfig().getDouble("economy.tax.percentage", 5);
        double taxCut = grossAmount * (percentage / 100.0);
        return grossAmount - taxCut;
    }
}
