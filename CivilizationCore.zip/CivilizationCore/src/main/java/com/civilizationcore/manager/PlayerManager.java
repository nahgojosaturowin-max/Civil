package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.CivPlayer;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Caches CivPlayer data for online (and recently-online) players so command
 * handlers and listeners never need to hit the database on the main thread.
 */
public class PlayerManager {

    private final CivilizationCore plugin;
    private final Map<UUID, CivPlayer> cache = new ConcurrentHashMap<>();

    public PlayerManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    /** Loads (or creates) a player's data async, caches it, and returns it back on the main thread. */
    public CompletableFuture<CivPlayer> loadOrCreate(UUID uuid, String name) {
        return plugin.getStorageManager().loadPlayer(uuid).thenApply(optional -> {
            CivPlayer cp = optional.orElseGet(() -> new CivPlayer(uuid, name));
            cp.setName(name); // keep name fresh in case they changed it
            cache.put(uuid, cp);
            return cp;
        });
    }

    public Optional<CivPlayer> get(UUID uuid) {
        return Optional.ofNullable(cache.get(uuid));
    }

    public CivPlayer getOrEmpty(UUID uuid, String name) {
        return cache.computeIfAbsent(uuid, u -> new CivPlayer(u, name));
    }

    public void save(CivPlayer cp) {
        plugin.getStorageManager().savePlayer(cp);
    }

    public void unload(UUID uuid) {
        CivPlayer cp = cache.remove(uuid);
        if (cp != null) {
            plugin.getStorageManager().savePlayer(cp);
        }
    }

    public Map<UUID, CivPlayer> getCache() {
        return cache;
    }
}
