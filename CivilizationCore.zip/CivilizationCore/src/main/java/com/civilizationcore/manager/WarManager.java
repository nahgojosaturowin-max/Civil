package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.event.WarEndEvent;
import com.civilizationcore.event.WarStartEvent;
import com.civilizationcore.model.*;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Drives the war lifecycle (PROPOSED -> ACCEPTED -> SCHEDULED -> ACTIVE ->
 * FINISHED/CANCELLED). Winner determination in Part 3 is intentionally
 * simple - an admin or the war's own timer resolves it (see
 * {@link #finishWar}) - rather than building full siege/objective combat
 * detection, which the PRD frames as configurable per-war objectives best
 * left to server-specific setup. What CivilizationCore guarantees is the
 * lifecycle, scheduling, rewards, and - for WEAPON_WAR - the actual
 * ownership transfer via WeaponManager.
 */
public class WarManager {

    private final CivilizationCore plugin;
    private final Map<Long, War> wars = new ConcurrentHashMap<>();
    private BukkitTask tickTask;

    public WarManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        stop();
        tickTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 100L, 100L);
    }

    public void stop() {
        if (tickTask != null) {
            tickTask.cancel();
            tickTask = null;
        }
    }

    public void loadAll() {
        wars.clear();
        plugin.getStorageManager().loadActiveWars().thenAccept(list -> Bukkit.getScheduler().runTask(plugin, () -> {
            for (War war : list) wars.put(war.getId(), war);
        }));
    }

    public void saveAll() {
        for (War war : wars.values()) {
            plugin.getStorageManager().updateWar(war);
        }
    }

    public boolean isEnabled() {
        return plugin.getConfigManager().getConfig().getBoolean("war.enabled", true);
    }

    public Collection<War> getAll() {
        return wars.values();
    }

    public Optional<War> get(long id) {
        return Optional.ofNullable(wars.get(id));
    }

    public List<War> getActiveFor(String civId) {
        return wars.values().stream()
                .filter(w -> w.involves(civId) && w.getState() != WarState.FINISHED && w.getState() != WarState.CANCELLED)
                .toList();
    }

    private void tick() {
        long now = System.currentTimeMillis();
        for (War war : List.copyOf(wars.values())) {
            if (war.getState() == WarState.SCHEDULED && war.getScheduledStart() > 0 && now >= war.getScheduledStart()) {
                activateWar(war);
            } else if (war.getState() == WarState.ACTIVE && war.getStartedAt() > 0
                    && now >= war.getStartedAt() + war.getDurationMillis()) {
                finishWar(war, null); // duration expired with no explicit winner - draw, no rewards
            }
        }
    }

    // ---------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------

    public War createWar(Civilization attacker, Civilization defender, WarType type) {
        War war = new War(attacker.getId(), defender.getId(), type);
        war.setDurationMillis(AssignmentManager.parseDuration(
                plugin.getConfigManager().getConfig().getString("war.default-duration", "45m")));
        if (type == WarType.WEAPON_WAR) {
            // Target the highest-value weapon the defender currently controls, if any.
            plugin.getWeaponManager().getOwnedBy(defender.getId()).stream().findFirst()
                    .ifPresent(w -> war.setTargetWeaponId(w.getId()));
        }
        wars.put(-1L, war); // temporary key until the DB assigns a real id
        plugin.getStorageManager().createWar(war).thenAccept(id -> Bukkit.getScheduler().runTask(plugin, () -> {
            wars.remove(-1L);
            war.setId(id);
            wars.put(id, war);
        }));
        return war;
    }

    public void accept(War war) {
        war.setState(WarState.ACCEPTED);
        plugin.getStorageManager().updateWar(war);
    }

    public void deny(War war) {
        war.setState(WarState.CANCELLED);
        plugin.getStorageManager().updateWar(war);
        wars.remove(war.getId());
    }

    public void cancel(War war) {
        war.setState(WarState.CANCELLED);
        plugin.getStorageManager().updateWar(war);
        wars.remove(war.getId());
    }

    public boolean schedule(War war, long startTimeMillis) {
        if (war.getState() != WarState.ACCEPTED) return false;
        war.setScheduledStart(startTimeMillis);
        war.setState(WarState.SCHEDULED);
        plugin.getStorageManager().updateWar(war);
        return true;
    }

    private void activateWar(War war) {
        war.setState(WarState.ACTIVE);
        war.setStartedAt(System.currentTimeMillis());
        plugin.getStorageManager().updateWar(war);

        Bukkit.getPluginManager().callEvent(new WarStartEvent(war));

        String message = plugin.getMessageManager().raw("war-started", Map.of(
                "attacker", nameOf(war.getAttackerCivId()), "defender", nameOf(war.getDefenderCivId())));
        Bukkit.broadcastMessage(message);
    }

    /**
     * Ends a war with the given winner (null = draw/no winner). Distributes
     * coin rewards, updates win/loss stats, and - for WEAPON_WAR - transfers
     * the targeted weapon to the winner via WeaponManager.
     */
    public void finishWar(War war, String winnerCivId) {
        war.setState(WarState.FINISHED);
        war.setEndedAt(System.currentTimeMillis());
        war.setWinnerCivId(winnerCivId);
        plugin.getStorageManager().updateWar(war);
        wars.remove(war.getId());

        if (winnerCivId != null) {
            String loserCivId = war.otherSide(winnerCivId);
            plugin.getCivilizationManager().get(winnerCivId).ifPresent(w -> {
                w.getStats().setWarsWon(w.getStats().getWarsWon() + 1);
                plugin.getCivilizationManager().save(w);
            });
            plugin.getCivilizationManager().get(loserCivId).ifPresent(l -> {
                l.getStats().setWarsLost(l.getStats().getWarsLost() + 1);
                plugin.getCivilizationManager().save(l);
            });

            double victoryCoins = plugin.getConfigManager().getConfig().getDouble("war.rewards.victory-coins", 10000);
            double defeatCoins = plugin.getConfigManager().getConfig().getDouble("war.rewards.defeat-coins", 2500);
            plugin.getEconomyManager().depositToTreasury(winnerCivId, victoryCoins, TransactionType.WAR_REWARD, null, "War victory: " + war.getType());
            plugin.getEconomyManager().depositToTreasury(loserCivId, defeatCoins, TransactionType.WAR_REWARD, null, "War participation: " + war.getType());

            if (war.getType() == WarType.WEAPON_WAR && war.getTargetWeaponId() != null) {
                plugin.getWeaponManager().get(war.getTargetWeaponId()).ifPresent(weapon ->
                        plugin.getCivilizationManager().get(winnerCivId).ifPresent(winnerCiv ->
                                plugin.getWeaponManager().capture(weapon, winnerCiv, null, war)));
            }

            Bukkit.broadcastMessage(plugin.getMessageManager().raw("war-ended", Map.of("winner", nameOf(winnerCivId))));
        }

        Bukkit.getPluginManager().callEvent(new WarEndEvent(war, winnerCivId));
    }

    private String nameOf(String civId) {
        return plugin.getCivilizationManager().get(civId).map(Civilization::getName).orElse(civId);
    }
}
