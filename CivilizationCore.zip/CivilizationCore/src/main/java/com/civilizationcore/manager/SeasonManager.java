package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.event.CivilizationVictoryEvent;
import com.civilizationcore.event.SeasonEndEvent;
import com.civilizationcore.model.*;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;
import java.util.Optional;

/**
 * Detects the season victory condition (one civilization controlling all
 * three Legendary Weapons), runs the grace period that follows, records
 * Hall of Fame entries, and handles admin-triggered season resets.
 */
public class SeasonManager {

    private final CivilizationCore plugin;
    private Season currentSeason;
    private BukkitTask graceTask;

    public SeasonManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public void loadOrStartSeason() {
        plugin.getStorageManager().loadCurrentSeason().thenAccept(opt -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (opt.isPresent() && opt.get().getState() != SeasonState.FINISHED) {
                currentSeason = opt.get();
            } else {
                int nextNumber = opt.map(s -> s.getNumber() + 1)
                        .orElse(plugin.getConfigManager().getConfig().getInt("season.number", 1));
                currentSeason = new Season(nextNumber, System.currentTimeMillis());
                plugin.getStorageManager().saveSeason(currentSeason);
            }
            plugin.getLogger().info("Active season: " + currentSeason.getNumber() + " (" + currentSeason.getState() + ")");
        }));
    }

    public Season getCurrentSeason() {
        return currentSeason;
    }

    public boolean isGracePeriod() {
        return currentSeason != null && currentSeason.getState() == SeasonState.GRACE_PERIOD;
    }

    public boolean isSeasonFinished() {
        return currentSeason != null && currentSeason.getState() == SeasonState.FINISHED;
    }

    /** Called by WeaponManager after every ownership change to check for the win condition. */
    public void checkVictoryCondition(String civId) {
        if (currentSeason == null || currentSeason.getState() != SeasonState.ACTIVE) return;
        if (!plugin.getWeaponManager().controlsAllWeapons(civId)) return;

        plugin.getCivilizationManager().get(civId).ifPresent(this::declareVictory);
    }

    private void declareVictory(Civilization civ) {
        currentSeason.setWinnerCivId(civ.getId());
        boolean endOnVictory = plugin.getConfigManager().getConfig().getBoolean("season.end-on-victory", true);
        currentSeason.setState(endOnVictory ? SeasonState.GRACE_PERIOD : SeasonState.ACTIVE);

        long graceMillis = AssignmentManager.parseDuration(plugin.getConfigManager().getConfig().getString("season.grace-period", "30m"));
        currentSeason.setGraceEndsAt(System.currentTimeMillis() + graceMillis);
        plugin.getStorageManager().saveSeason(currentSeason);

        Bukkit.getPluginManager().callEvent(new CivilizationVictoryEvent(civ.getId(), currentSeason.getNumber()));

        announceVictory(civ);

        if (endOnVictory) {
            scheduleGraceEnd(graceMillis);
        }
    }

    private void announceVictory(Civilization civ) {
        String leaderName = "Unknown";
        if (civ.hasLeader()) {
            OfflinePlayer leader = Bukkit.getOfflinePlayer(civ.getLeaderUuid());
            leaderName = leader.getName() != null ? leader.getName() : leaderName;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("\n").append("\u00A76\u00A7l━━━━━━━━━━━━━━━━━━━━━━━━\n");
        sb.append("\uD83C\uDFC6 SEASON COMPLETE\n");
        sb.append("\u00A76━━━━━━━━━━━━━━━━━━━━━━━━\n\n");
        sb.append(plugin.getMessageManager().color(civ.getPrefix())).append(" \u00A7f").append(civ.getName().toUpperCase()).append("\n\n");
        sb.append("HAS WON SEASON ").append(currentSeason.getNumber()).append("!\n\n");
        sb.append("They now control all three\nLegendary Weapons.\n\n");
        sb.append("\uD83D\uDC51 Leader: ").append(leaderName).append("\n");
        sb.append("\u00A76━━━━━━━━━━━━━━━━━━━━━━━━");
        Bukkit.broadcastMessage(sb.toString());

        boolean titleEnabled = plugin.getConfigManager().getConfig().getBoolean("notifications.title-enabled", true);
        boolean soundEnabled = plugin.getConfigManager().getConfig().getBoolean("notifications.sound-enabled", true);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (titleEnabled) {
                p.sendTitle("\u00A76\u00A7lSEASON COMPLETE", "\u00A7f" + civ.getName() + " has won!", 10, 100, 20);
            }
            if (soundEnabled) {
                p.playSound(p.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            }
        }

        plugin.getDiscordIntegrationManager().announceSeasonVictory(civ.getName(), leaderName, currentSeason.getNumber());
    }

    private void scheduleGraceEnd(long graceMillis) {
        if (graceTask != null) graceTask.cancel();
        graceTask = Bukkit.getScheduler().runTaskLater(plugin, this::finishSeason, graceMillis / 50L);
    }

    private void finishSeason() {
        if (currentSeason == null || currentSeason.getWinnerCivId() == null) return;

        currentSeason.setState(SeasonState.FINISHED);
        currentSeason.setEndDate(System.currentTimeMillis());
        plugin.getStorageManager().saveSeason(currentSeason);

        Civilization winner = plugin.getCivilizationManager().get(currentSeason.getWinnerCivId()).orElse(null);
        if (winner != null) {
            String leaderUuid = winner.hasLeader() ? winner.getLeaderUuid().toString() : null;
            String leaderName = winner.hasLeader() ? Bukkit.getOfflinePlayer(winner.getLeaderUuid()).getName() : null;

            HallOfFameEntry entry = new HallOfFameEntry(
                    currentSeason.getNumber(), winner.getId(), winner.getName(),
                    leaderUuid, leaderName, currentSeason.getStartDate(), currentSeason.getEndDate());
            plugin.getStorageManager().saveHallOfFameEntry(entry);
        }

        Bukkit.getPluginManager().callEvent(new SeasonEndEvent(currentSeason));
        Bukkit.broadcastMessage(plugin.getMessageManager().color("&6The season has ended. A new season will begin shortly."));
    }

    /** During GRACE_PERIOD (or FINISHED), no new wars or weapon transfers should be allowed. */
    public boolean areWarsAllowed() {
        return currentSeason == null || currentSeason.getState() == SeasonState.ACTIVE;
    }

    public List<HallOfFameEntry> getHallOfFame() {
        // Synchronous accessor backed by an async load is awkward; callers needing
        // this should use plugin.getStorageManager().loadHallOfFame() directly
        // for a CompletableFuture. Kept here only as a documented pointer.
        throw new UnsupportedOperationException("Use plugin.getStorageManager().loadHallOfFame() for async access.");
    }

    /** Admin-triggered reset per config's season.reset toggles. Starts a brand-new season afterward. */
    public void resetSeason() {
        var reset = plugin.getConfigManager().getConfig().getConfigurationSection("season.reset");
        boolean resetWeapons = reset == null || reset.getBoolean("weapon-ownership", true);
        boolean resetWarStats = reset == null || reset.getBoolean("war-statistics", true);
        boolean resetPoints = reset == null || reset.getBoolean("civilization-points", true);
        boolean resetEconomy = reset != null && reset.getBoolean("economy", false);
        boolean resetLeaders = reset != null && reset.getBoolean("leaders", false);

        if (resetWeapons) {
            for (LegendaryWeapon weapon : plugin.getWeaponManager().getAll()) {
                weapon.setCurrentCivilizationId(weapon.getOriginalCivilizationId());
                weapon.regenerateInstanceId();
                plugin.getStorageManager().saveWeapon(weapon);
            }
        }

        for (Civilization civ : plugin.getCivilizationManager().getAll()) {
            if (resetWarStats) {
                civ.getStats().setWarsWon(0);
                civ.getStats().setWarsLost(0);
                civ.getStats().setWeaponsControlled(resetWeapons ? 1 : civ.getStats().getWeaponsControlled());
            }
            if (resetPoints) {
                civ.getStats().setEventsWon(0);
                civ.getStats().setTerritory(0);
            }
            if (resetEconomy) {
                civ.setTreasuryBalance(0);
            }
            if (resetLeaders) {
                plugin.getLeaderManager().clearLeader(civ);
            }
            plugin.getCivilizationManager().save(civ);
        }

        plugin.getStorageManager().clearSeasonData();

        int nextNumber = (currentSeason != null ? currentSeason.getNumber() : 0) + 1;
        currentSeason = new Season(nextNumber, System.currentTimeMillis());
        plugin.getStorageManager().saveSeason(currentSeason);

        plugin.getScoreboardManager().start();
    }
}
