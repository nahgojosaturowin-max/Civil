package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import github.scarsz.discordsrv.DiscordSRV;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.TextChannel;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Optional bridge to DiscordSRV. Every entry point here is defensive: it
 * checks the plugin is actually installed before touching any of its
 * classes, and wraps the DiscordSRV/JDA calls in try/catch so a Discord
 * hiccup (missing channel, API change, rate limit) never breaks in-game
 * functionality. CivilizationCore must - and does - work identically with
 * DiscordSRV completely absent.
 */
public class DiscordIntegrationManager {

    private final CivilizationCore plugin;

    public DiscordIntegrationManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    private boolean isDiscordSrvPresent() {
        return plugin.getServer().getPluginManager().getPlugin("DiscordSRV") != null;
    }

    public boolean isEnabled() {
        return plugin.getConfigManager().getConfig().getBoolean("discord.enabled", false) && isDiscordSrvPresent();
    }

    /** Announces an election result in DiscordSRV's configured main text channel. */
    public void announceElectionResult(String civilizationName, String winnerName) {
        if (!isEnabled()) return;
        try {
            String template = plugin.getConfigManager().getConfig()
                    .getString("discord.election-announcement", "\uD83D\uDC51 **%player%** has been elected Leader of **%civilization%**.");
            String message = template.replace("%player%", winnerName).replace("%civilization%", civilizationName);

            TextChannel channel = DiscordSRV.getPlugin().getMainTextChannel();
            if (channel != null) {
                channel.sendMessage(message).queue();
            }
        } catch (Throwable t) {
            plugin.getLogger().log(Level.WARNING, "Failed to send Discord election announcement", t);
        }
    }

    /** Announces a season victory in DiscordSRV's main text channel. */
    public void announceSeasonVictory(String civilizationName, String leaderName, int seasonNumber) {
        if (!isEnabled()) return;
        try {
            String message = "\uD83C\uDFC6 **" + civilizationName + "** has won Season " + seasonNumber
                    + "! Led by **" + leaderName + "**, they now control all three Legendary Weapons.";
            TextChannel channel = DiscordSRV.getPlugin().getMainTextChannel();
            if (channel != null) {
                channel.sendMessage(message).queue();
            }
        } catch (Throwable t) {
            plugin.getLogger().log(Level.WARNING, "Failed to send Discord season victory announcement", t);
        }
    }

    /**
     * Assigns the civilization/leader Discord roles to the new leader and
     * strips the leader role from whoever previously held it, if linked and
     * configured. No-ops silently if role sync is disabled or a player
     * isn't linked to Discord.
     */
    public void syncLeaderRoles(String civilizationId, UUID previousLeader, UUID newLeader) {
        if (!isEnabled()) return;
        if (!plugin.getConfigManager().getConfig().getBoolean("discord.sync-roles", false)) return;

        try {
            String roleFormat = plugin.getConfigManager().getConfig().getString("discord.role-format", "%civilization%");
            String leaderRoleFormat = plugin.getConfigManager().getConfig().getString("discord.leader-role-format", "%civilization%-Leader");
            String civLabel = capitalize(civilizationId);
            String leaderRoleName = leaderRoleFormat.replace("%civilization%", civLabel);

            for (Guild guild : DiscordSRV.getPlugin().getJda().getGuilds()) {
                List<Role> leaderRoles = guild.getRolesByName(leaderRoleName, true);
                if (leaderRoles.isEmpty()) continue;
                Role leaderRole = leaderRoles.get(0);

                if (previousLeader != null) {
                    String oldDiscordId = DiscordSRV.getPlugin().getAccountLinkManager().getDiscordId(previousLeader);
                    Member oldMember = oldDiscordId != null ? guild.getMemberById(oldDiscordId) : null;
                    if (oldMember != null) {
                        guild.removeRoleFromMember(oldMember, leaderRole).queue(v -> {}, e -> {});
                    }
                }

                if (newLeader != null) {
                    String newDiscordId = DiscordSRV.getPlugin().getAccountLinkManager().getDiscordId(newLeader);
                    Member newMember = newDiscordId != null ? guild.getMemberById(newDiscordId) : null;
                    if (newMember != null) {
                        guild.addRoleToMember(newMember, leaderRole).queue(v -> {}, e -> {});
                    }
                }
            }
        } catch (Throwable t) {
            plugin.getLogger().log(Level.WARNING, "Failed to sync Discord leader roles", t);
        }
    }

    private String capitalize(String input) {
        if (input == null || input.isEmpty()) return input;
        return Character.toUpperCase(input.charAt(0)) + input.substring(1).toLowerCase();
    }
}
