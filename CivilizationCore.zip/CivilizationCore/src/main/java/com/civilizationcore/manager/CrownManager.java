package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Handles the Civilization Crown. The crown's identity is stored entirely
 * in its PersistentDataContainer (item type + civilization id) rather than
 * display name, lore, or material, so renaming or reskinning it elsewhere
 * can never spoof or break leader detection.
 */
public class CrownManager {

    public static final String ITEM_TYPE_VALUE = "CROWN";

    private final CivilizationCore plugin;
    private final NamespacedKey itemTypeKey;
    private final NamespacedKey civIdKey;

    public CrownManager(CivilizationCore plugin) {
        this.plugin = plugin;
        this.itemTypeKey = new NamespacedKey(plugin, "civilization_item_type");
        this.civIdKey = new NamespacedKey(plugin, "civilization_id");
    }

    public NamespacedKey getItemTypeKey() {
        return itemTypeKey;
    }

    public NamespacedKey getCivIdKey() {
        return civIdKey;
    }

    /** Builds a fresh crown ItemStack for the given civilization. Does not give it to anyone. */
    public ItemStack createCrown(Civilization civ) {
        String materialName = plugin.getConfigManager().getConfig().getString("crown.material", "GOLDEN_HELMET");
        Material material = Material.matchMaterial(materialName);
        if (material == null) material = Material.GOLDEN_HELMET;

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        String nameFormat = plugin.getConfigManager().getConfig().getString("crown.name-format", "&6&lCrown of %civilization%");
        meta.setDisplayName(plugin.getMessageManager().color(nameFormat.replace("%civilization%", civ.getName())));

        List<String> loreLines = plugin.getConfigManager().getConfig().getStringList("crown.lore");
        List<String> lore = new ArrayList<>();
        for (String line : loreLines) {
            lore.add(plugin.getMessageManager().color(line.replace("%civilization%", civ.getName())));
        }
        meta.setLore(lore);

        meta.getPersistentDataContainer().set(itemTypeKey, PersistentDataType.STRING, ITEM_TYPE_VALUE);
        meta.getPersistentDataContainer().set(civIdKey, PersistentDataType.STRING, civ.getId());

        item.setItemMeta(meta);
        return item;
    }

    /** Gives (or replaces) the leader's crown, dropping it on the ground if their inventory is full. */
    public void giveCrown(Player player, Civilization civ) {
        ItemStack crown = createCrown(civ);
        var leftover = player.getInventory().addItem(crown);
        if (!leftover.isEmpty()) {
            leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        }
    }

    public boolean isCrown(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        String type = meta.getPersistentDataContainer().get(itemTypeKey, PersistentDataType.STRING);
        return ITEM_TYPE_VALUE.equals(type);
    }

    public Optional<String> getCrownCivilizationId(ItemStack item) {
        if (!isCrown(item)) return Optional.empty();
        ItemMeta meta = item.getItemMeta();
        return Optional.ofNullable(meta.getPersistentDataContainer().get(civIdKey, PersistentDataType.STRING));
    }

    /**
     * A crown is valid only if the holding player is still the current
     * leader of the civilization it's tagged with.
     */
    public boolean isCrownValidFor(Player holder, ItemStack item) {
        Optional<String> civId = getCrownCivilizationId(item);
        if (civId.isEmpty()) return false;
        return plugin.getCivilizationManager().get(civId.get())
                .map(civ -> civ.hasLeader() && civ.getLeaderUuid().equals(holder.getUniqueId()))
                .orElse(false);
    }
}
