package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.ChatChannel;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.RelationType;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Routes civilization/alliance/leader chat. Each player has a "current"
 * channel (default CIVILIZATION) that /civ chat <message> posts to when no
 * explicit channel is given; /civ chat with no message toggles which
 * channel subsequent normal typing... is intentionally NOT hijacked here -
 * Part 2 keeps this to the explicit /civ chat command rather than
 * intercepting the player's regular chat, to avoid surprising interactions
 * with other chat plugins.
 */
public class ChatManager {

    private final CivilizationCore plugin;
    private final Map<UUID, ChatChannel> activeChannel = new ConcurrentHashMap<>();

    public ChatManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public boolean isEnabled() {
        return plugin.getConfigManager().getConfig().getBoolean("chat.enabled", true);
    }

    public ChatChannel getChannel(Player player) {
        return activeChannel.getOrDefault(player.getUniqueId(), ChatChannel.CIVILIZATION);
    }

    public void setChannel(Player player, ChatChannel channel) {
        activeChannel.put(player.getUniqueId(), channel);
    }

    /** Sends a message on the given channel from the player, formatted per config. */
    public void send(Player sender, Civilization civ, ChatChannel channel, String message) {
        String formatKey = switch (channel) {
            case CIVILIZATION -> "chat.format.civilization";
            case ALLIANCE -> "chat.format.alliance";
            case LEADER -> "chat.format.leader";
            case GLOBAL -> null; // global chat is handled by the server/another plugin, not this manager
        };
        if (formatKey == null) return;

        String format = plugin.getConfigManager().getConfig().getString(formatKey, "%player%: %message%");
        String formatted = plugin.getMessageManager().color(format
                .replace("%civilization_prefix%", civ.getPrefix())
                .replace("%civilization%", civ.getName())
                .replace("%player%", sender.getName())
                .replace("%message%", message));

        for (Player recipient : audienceFor(civ, channel)) {
            recipient.sendMessage(formatted);
        }
        // Console visibility for logging/moderation.
        Bukkit.getConsoleSender().sendMessage(formatted);
    }

    private Iterable<Player> audienceFor(Civilization civ, ChatChannel channel) {
        return switch (channel) {
            case CIVILIZATION -> onlineMembers(civ);
            case LEADER -> onlineLeaders();
            case ALLIANCE -> onlineAllianceMembers(civ);
            case GLOBAL -> Bukkit.getOnlinePlayers();
        };
    }

    private Iterable<Player> onlineMembers(Civilization civ) {
        return Bukkit.getOnlinePlayers().stream()
                .filter(p -> civ.getMembers().contains(p.getUniqueId()))
                .toList();
    }

    private Iterable<Player> onlineLeaders() {
        return Bukkit.getOnlinePlayers().stream()
                .filter(p -> plugin.getPlayerManager().get(p.getUniqueId()).map(cp -> cp.isLeader()).orElse(false))
                .toList();
    }

    private Iterable<Player> onlineAllianceMembers(Civilization civ) {
        if (!plugin.getDiplomacyManager().isAllianceChatShared()) {
            return onlineMembers(civ);
        }
        return Bukkit.getOnlinePlayers().stream()
                .filter(p -> {
                    if (civ.getMembers().contains(p.getUniqueId())) return true;
                    var cpOpt = plugin.getPlayerManager().get(p.getUniqueId());
                    if (cpOpt.isEmpty() || !cpOpt.get().hasCivilization()) return false;
                    RelationType relation = plugin.getDiplomacyManager().getRelation(civ.getId(), cpOpt.get().getCivilizationId());
                    return relation == RelationType.ALLY;
                })
                .toList();
    }
}
