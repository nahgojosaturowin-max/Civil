package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.event.CapitalChangeEvent;
import com.civilizationcore.model.Civilization;
import org.bukkit.Bukkit;
import org.bukkit.Location;

/**
 * Handles capital assignment. Part 1 only stores and displays the capital
 * location - no territory protection is implemented here (that's future
 * scope per the PRD).
 */
public class CapitalManager {

    private final CivilizationCore plugin;

    public CapitalManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    /** Sets the civilization's capital to the given location. Main thread only. */
    public void setCapital(Civilization civ, Location location) {
        civ.setCapital(location);
        plugin.getCivilizationManager().save(civ);
        Bukkit.getPluginManager().callEvent(new CapitalChangeEvent(civ, location));
    }

    public String formatCapital(Civilization civ) {
        if (!civ.hasCapital()) return "Not set";
        return String.format("%s (%.0f, %.0f, %.0f)",
                civ.getCapitalWorld(), civ.getCapitalX(), civ.getCapitalY(), civ.getCapitalZ());
    }
}
