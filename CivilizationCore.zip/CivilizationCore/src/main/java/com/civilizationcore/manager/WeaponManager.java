package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.event.WeaponCapturedEvent;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.LegendaryWeapon;
import com.civilizationcore.model.War;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Owns the exactly-three Legendary Weapons: their config-driven definitions
 * (name, material, abilities, cooldown), their persisted ownership state,
 * and the PersistentDataContainer identity that makes a physical item
 * genuine. A weapon is only ever "real" if its (weapon_id, instance_id)
 * pair matches this manager's current record for that weapon - anything
 * else (a renamed/lore-edited copy, a dupe, an old instance from before a
 * capture) is inert, since {@link #isGenuine} is what every ability check
 * and protection listener relies on rather than trusting the item alone.
 */
public class WeaponManager {

    public static final String WEAPON_TYPE_VALUE = "LEGENDARY";

    private final CivilizationCore plugin;
    private final Map<String, LegendaryWeapon> weapons = new LinkedHashMap<>();

    // player uuid -> (weapon id -> ability ready timestamp)
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();

    private final NamespacedKey typeKey;
    private final NamespacedKey idKey;
    private final NamespacedKey instanceKey;

    public WeaponManager(CivilizationCore plugin) {
        this.plugin = plugin;
        this.typeKey = new NamespacedKey(plugin, "weapon_type");
        this.idKey = new NamespacedKey(plugin, "weapon_id");
        this.instanceKey = new NamespacedKey(plugin, "instance_id");
    }

    public NamespacedKey getTypeKey() {
        return typeKey;
    }

    public NamespacedKey getIdKey() {
        return idKey;
    }

    public NamespacedKey getInstanceKey() {
        return instanceKey;
    }

    /** Reads weapon definitions from config, then overlays persisted ownership/instance state from the DB. */
    public void loadAll() {
        weapons.clear();
        ConfigurationSection section = plugin.getConfigManager().getConfig().getConfigurationSection("weapons");
        if (section == null) {
            plugin.getLogger().warning("No 'weapons' section in config.yml - Legendary Weapons are disabled.");
            return;
        }

        for (String id : section.getKeys(false)) {
            String civId = section.getString(id + ".civilization", "");
            LegendaryWeapon weapon = new LegendaryWeapon(id, civId);
            weapon.setDisplayName(section.getString(id + ".display-name", id));
            weapon.setMaterialName(section.getString(id + ".material", "NETHERITE_SWORD"));
            weapon.setCustomModelData(section.getInt(id + ".custom-model-data", 0));
            weapon.setAbilities(section.getStringList(id + ".abilities"));
            weapon.setCooldownMillis(AssignmentManager.parseDuration(section.getString(id + ".cooldown", "10s")));
            weapons.put(id, weapon);
        }

        plugin.getStorageManager().loadWeaponState().thenAccept(state -> Bukkit.getScheduler().runTask(plugin, () -> {
            for (var entry : state.entrySet()) {
                LegendaryWeapon weapon = weapons.get(entry.getKey());
                if (weapon == null) continue;
                weapon.setCurrentCivilizationId(entry.getValue()[0]);
                try {
                    weapon.setInstanceId(UUID.fromString(entry.getValue()[1]));
                } catch (IllegalArgumentException ignored) {
                    // corrupt row - keep the freshly generated instance id instead
                }
            }
            // Ensure any brand-new weapon (not yet in the DB) gets persisted with its initial state.
            for (LegendaryWeapon weapon : weapons.values()) {
                if (!state.containsKey(weapon.getId())) {
                    plugin.getStorageManager().saveWeapon(weapon);
                }
            }
        }));
    }

    public void saveAll() {
        for (LegendaryWeapon weapon : weapons.values()) {
            plugin.getStorageManager().saveWeapon(weapon);
        }
    }

    public Collection<LegendaryWeapon> getAll() {
        return weapons.values();
    }

    public Optional<LegendaryWeapon> get(String id) {
        return Optional.ofNullable(weapons.get(id.toLowerCase()));
    }

    public List<LegendaryWeapon> getOwnedBy(String civId) {
        return weapons.values().stream().filter(w -> w.getCurrentCivilizationId().equalsIgnoreCase(civId)).toList();
    }

    public boolean controlsAllWeapons(String civId) {
        if (weapons.isEmpty()) return false;
        return weapons.values().stream().allMatch(w -> w.getCurrentCivilizationId().equalsIgnoreCase(civId));
    }

    // ---------------------------------------------------------------
    // Item creation & identity
    // ---------------------------------------------------------------

    public ItemStack createItem(LegendaryWeapon weapon) {
        Material material = Material.matchMaterial(weapon.getMaterialName());
        if (material == null) material = Material.NETHERITE_SWORD;

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(plugin.getMessageManager().color(weapon.getDisplayName()));
        if (weapon.getCustomModelData() > 0) {
            meta.setCustomModelData(weapon.getCustomModelData());
        }

        List<String> lore = new ArrayList<>();
        lore.add(plugin.getMessageManager().color("&7A Legendary Weapon."));
        lore.add(plugin.getMessageManager().color("&7Abilities: &f" + String.join(", ", weapon.getAbilities())));
        meta.setLore(lore);

        meta.getPersistentDataContainer().set(typeKey, PersistentDataType.STRING, WEAPON_TYPE_VALUE);
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, weapon.getId());
        meta.getPersistentDataContainer().set(instanceKey, PersistentDataType.STRING, weapon.getInstanceId().toString());

        item.setItemMeta(meta);
        return item;
    }

    public boolean isLegendaryItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        String type = item.getItemMeta().getPersistentDataContainer().get(typeKey, PersistentDataType.STRING);
        return WEAPON_TYPE_VALUE.equals(type);
    }

    public Optional<String> getWeaponId(ItemStack item) {
        if (!isLegendaryItem(item)) return Optional.empty();
        return Optional.ofNullable(item.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING));
    }

    /** True only if this exact item is the current, non-superseded instance of its weapon - i.e. not a stale copy from before a capture. */
    public boolean isGenuine(ItemStack item) {
        Optional<String> idOpt = getWeaponId(item);
        if (idOpt.isEmpty()) return false;
        LegendaryWeapon weapon = weapons.get(idOpt.get());
        if (weapon == null) return false;
        String instanceStr = item.getItemMeta().getPersistentDataContainer().get(instanceKey, PersistentDataType.STRING);
        return weapon.getInstanceId().toString().equals(instanceStr);
    }

    /** Only the current leader of the weapon's current owning civilization may use its abilities. */
    public boolean canUseAbilities(Player player, LegendaryWeapon weapon) {
        return plugin.getCivilizationManager().get(weapon.getCurrentCivilizationId())
                .map(civ -> civ.hasLeader() && civ.getLeaderUuid().equals(player.getUniqueId()))
                .orElse(false);
    }

    // ---------------------------------------------------------------
    // Ownership changes
    // ---------------------------------------------------------------

    /** Gives the physical item to a civilization's current leader, if online. Does not change ownership by itself. */
    public void giveToLeader(Civilization civ) {
        if (!civ.hasLeader()) return;
        Player leader = Bukkit.getPlayer(civ.getLeaderUuid());
        if (leader == null) return;
        for (LegendaryWeapon weapon : getOwnedBy(civ.getId())) {
            var leftover = leader.getInventory().addItem(createItem(weapon));
            leftover.values().forEach(item -> leader.getWorld().dropItemNaturally(leader.getLocation(), item));
        }
    }

    /**
     * Transfers a weapon's ownership from its current civilization to a new
     * one as the result of a war, invalidating the old physical item
     * (regenerating its instance id) and giving a fresh one to the new
     * owner's leader if they're online. Fires WeaponCapturedEvent and
     * checks the season victory condition.
     */
    public void capture(LegendaryWeapon weapon, Civilization newOwner, UUID capturedBy, War war) {
        String previousOwnerId = weapon.getCurrentCivilizationId();
        weapon.setCurrentCivilizationId(newOwner.getId());
        weapon.regenerateInstanceId();
        plugin.getStorageManager().saveWeapon(weapon);

        newOwner.getStats().setWeaponsControlled(getOwnedBy(newOwner.getId()).size());
        plugin.getCivilizationManager().get(previousOwnerId).ifPresent(prev ->
                prev.getStats().setWeaponsControlled(getOwnedBy(prev.getId()).size()));
        plugin.getCivilizationManager().save(newOwner);

        giveToLeader(newOwner);

        Bukkit.getPluginManager().callEvent(new WeaponCapturedEvent(weapon, previousOwnerId, newOwner.getId(), capturedBy, war));

        Bukkit.broadcastMessage(plugin.getMessageManager().color("&6&l" + weapon.getDisplayName() + " &6has been captured by &f"
                + newOwner.getName() + "&6!"));

        plugin.getSeasonManager().checkVictoryCondition(newOwner.getId());
    }

    /** Admin override: force-transfers a weapon to a civilization/player regardless of war state. */
    public void adminTransfer(LegendaryWeapon weapon, Civilization newOwner, UUID targetPlayer) {
        String previousOwnerId = weapon.getCurrentCivilizationId();
        weapon.setCurrentCivilizationId(newOwner.getId());
        weapon.regenerateInstanceId();
        plugin.getStorageManager().saveWeapon(weapon);
        plugin.getCivilizationManager().save(newOwner);

        Player target = Bukkit.getPlayer(targetPlayer);
        if (target != null) {
            var leftover = target.getInventory().addItem(createItem(weapon));
            leftover.values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
        }

        Bukkit.getPluginManager().callEvent(new WeaponCapturedEvent(weapon, previousOwnerId, newOwner.getId(), targetPlayer, null));
        plugin.getSeasonManager().checkVictoryCondition(newOwner.getId());
    }

    // ---------------------------------------------------------------
    // Cooldowns
    // ---------------------------------------------------------------

    public boolean isOnCooldown(Player player, LegendaryWeapon weapon) {
        Long readyAt = cooldowns.getOrDefault(player.getUniqueId(), Map.of()).get(weapon.getId());
        return readyAt != null && readyAt > System.currentTimeMillis();
    }

    public long getRemainingCooldownMillis(Player player, LegendaryWeapon weapon) {
        Long readyAt = cooldowns.getOrDefault(player.getUniqueId(), Map.of()).get(weapon.getId());
        if (readyAt == null) return 0;
        return Math.max(0, readyAt - System.currentTimeMillis());
    }

    public void applyCooldown(Player player, LegendaryWeapon weapon) {
        cooldowns.computeIfAbsent(player.getUniqueId(), u -> new ConcurrentHashMap<>())
                .put(weapon.getId(), System.currentTimeMillis() + weapon.getCooldownMillis());
    }
}
