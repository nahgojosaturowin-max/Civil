package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.event.LeaderChangeEvent;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.CivPlayer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Owns leader assignment for civilizations. Leadership is always tracked by
 * UUID (never by display name). Permission attachments are tracked per
 * player so they can be cleanly removed when leadership changes or the
 * player leaves the server.
 */
public class LeaderManager {

    private final CivilizationCore plugin;
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();

    public LeaderManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    /**
     * Sets a new leader for the civilization. Clears the previous leader's
     * permissions/crown validity first. Must run on the main thread.
     */
    public boolean setLeader(Civilization civ, Player newLeader, CivPlayer newLeaderData) {
        if (!civ.getId().equalsIgnoreCase(newLeaderData.getCivilizationId())) {
            return false; // player must be a member of the civilization first
        }

        UUID oldLeaderUuid = civ.getLeaderUuid();

        // Demote old leader, if any and if they're online.
        if (oldLeaderUuid != null) {
            Player oldLeader = Bukkit.getPlayer(oldLeaderUuid);
            if (oldLeader != null) {
                revokeLeaderPermissions(oldLeader);
            }
            plugin.getPlayerManager().get(oldLeaderUuid).ifPresent(oldData -> {
                oldData.setLeader(false);
                plugin.getPlayerManager().save(oldData);
            });
        }

        civ.setLeaderUuid(newLeader.getUniqueId());
        newLeaderData.setLeader(true);

        grantLeaderPermissions(newLeader);
        plugin.getPlayerManager().save(newLeaderData);
        plugin.getCivilizationManager().save(civ);

        // Give the crown (also invalidates any stale crown elsewhere via PDC checks).
        plugin.getCrownManager().giveCrown(newLeader, civ);

        Bukkit.getPluginManager().callEvent(new LeaderChangeEvent(civ, oldLeaderUuid, newLeader.getUniqueId()));

        if (plugin.getConfigManager().getConfig().getBoolean("leader.announce-on-change", true)) {
            String msg = plugin.getMessageManager().raw("leader-set", Map.of(
                    "player", newLeader.getName(),
                    "civilization", civ.getName()
            ));
            Bukkit.broadcastMessage(plugin.getMessageManager().color(
                    plugin.getConfigManager().getConfig().getString("messages.prefix", "")) + msg);
        }

        return true;
    }

    /** Removes leadership without assigning a replacement. Main thread only. */
    public void clearLeader(Civilization civ) {
        UUID oldLeaderUuid = civ.getLeaderUuid();
        if (oldLeaderUuid == null) return;

        Player oldLeader = Bukkit.getPlayer(oldLeaderUuid);
        if (oldLeader != null) {
            revokeLeaderPermissions(oldLeader);
        }
        plugin.getPlayerManager().get(oldLeaderUuid).ifPresent(oldData -> {
            oldData.setLeader(false);
            plugin.getPlayerManager().save(oldData);
        });

        civ.setLeaderUuid(null);
        plugin.getCivilizationManager().save(civ);

        Bukkit.getPluginManager().callEvent(new LeaderChangeEvent(civ, oldLeaderUuid, null));
    }

    public void grantLeaderPermissions(Player player) {
        revokeLeaderPermissions(player); // avoid stacking attachments
        String node = plugin.getConfigManager().getConfig().getString("leader.permission", "civilization.leader");
        PermissionAttachment attachment = player.addAttachment(plugin);
        attachment.setPermission(node, true);
        // Scoped leader sub-permissions (Part 2). Deliberately narrow - never
        // grant unrestricted server permissions, per the PRD.
        attachment.setPermission("civilization.leader.economy", true);
        attachment.setPermission("civilization.leader.diplomacy", true);
        attachments.put(player.getUniqueId(), attachment);
    }

    /**
     * Sets a new leader who is currently offline (e.g. they won an election
     * while logged out). Permissions and the crown item can't be applied
     * until they're actually online, so this only updates persisted state;
     * PlayerJoinListener calls {@link #catchUpLeaderStateOnJoin} to finish
     * the job the next time they log in.
     */
    public boolean setLeaderOffline(Civilization civ, UUID newLeaderUuid, CivPlayer newLeaderData) {
        if (!civ.getId().equalsIgnoreCase(newLeaderData.getCivilizationId())) {
            return false;
        }

        UUID oldLeaderUuid = civ.getLeaderUuid();
        if (oldLeaderUuid != null) {
            Player oldLeader = Bukkit.getPlayer(oldLeaderUuid);
            if (oldLeader != null) revokeLeaderPermissions(oldLeader);
            plugin.getPlayerManager().get(oldLeaderUuid).ifPresent(oldData -> {
                oldData.setLeader(false);
                plugin.getPlayerManager().save(oldData);
            });
        }

        civ.setLeaderUuid(newLeaderUuid);
        newLeaderData.setLeader(true);
        plugin.getPlayerManager().save(newLeaderData);
        plugin.getCivilizationManager().save(civ);

        Bukkit.getPluginManager().callEvent(new LeaderChangeEvent(civ, oldLeaderUuid, newLeaderUuid));
        return true;
    }

    /**
     * Called on join: grants permissions if the player is their
     * civilization's leader, and gives them a crown if they don't already
     * have a valid one (covers players who became leader while offline).
     */
    public void catchUpLeaderStateOnJoin(Player player, Civilization civ) {
        if (civ == null || !civ.hasLeader() || !civ.getLeaderUuid().equals(player.getUniqueId())) return;

        grantLeaderPermissions(player);

        boolean hasValidCrown = false;
        for (var item : player.getInventory().getContents()) {
            if (item != null && plugin.getCrownManager().isCrown(item) && plugin.getCrownManager().isCrownValidFor(player, item)) {
                hasValidCrown = true;
                break;
            }
        }
        if (!hasValidCrown) {
            plugin.getCrownManager().giveCrown(player, civ);
        }
    }

    public void revokeLeaderPermissions(Player player) {
        PermissionAttachment existing = attachments.remove(player.getUniqueId());
        if (existing != null) {
            try {
                player.removeAttachment(existing);
            } catch (IllegalArgumentException ignored) {
                // already removed (e.g. player relogged)
            }
        }
    }

    /**
     * Re-applies leader permissions on join for whoever is currently the
     * leader of their civilization, since attachments do not persist
     * across sessions.
     */
    public void reapplyOnJoin(Player player, Civilization civ) {
        if (civ != null && civ.hasLeader() && civ.getLeaderUuid().equals(player.getUniqueId())) {
            grantLeaderPermissions(player);
        }
    }

    public boolean isLeaderOf(OfflinePlayer player, Civilization civ) {
        return civ.hasLeader() && civ.getLeaderUuid().equals(player.getUniqueId());
    }
}
