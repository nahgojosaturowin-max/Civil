package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.event.CivilizationJoinEvent;
import com.civilizationcore.event.CivilizationLeaveEvent;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.CivPlayer;
import com.civilizationcore.model.SwitchMode;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles automatic balanced assignment for new players, plus the rules
 * around whether an existing player is allowed to switch civilizations.
 */
public class AssignmentManager {

    private static final Pattern DURATION_PATTERN = Pattern.compile("(\\d+)\\s*([smhd])", Pattern.CASE_INSENSITIVE);
    private final Random random = new Random();

    private final CivilizationCore plugin;

    public AssignmentManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    /**
     * Assigns a brand-new player to the civilization with the lowest
     * population, breaking ties randomly. Must be called on the main thread
     * (it fires a Bukkit event and mutates cached civilization state).
     */
    public Civilization assignNewPlayer(Player player, CivPlayer cp) {
        List<Civilization> candidates = plugin.getCivilizationManager().getLowestPopulation();
        if (candidates.isEmpty()) {
            plugin.getLogger().warning("No civilizations configured - cannot assign " + player.getName());
            return null;
        }
        Civilization chosen = candidates.size() == 1
                ? candidates.get(0)
                : candidates.get(random.nextInt(candidates.size()));

        cp.setCivilizationId(chosen.getId());
        cp.setJoinTimestamp(System.currentTimeMillis());
        chosen.addMember(player.getUniqueId());

        plugin.getPlayerManager().save(cp);
        plugin.getCivilizationManager().save(chosen);

        Bukkit.getPluginManager().callEvent(new CivilizationJoinEvent(player, chosen, true));
        return chosen;
    }

    /** Moves a player into a civilization (admin action or approved switch). Main thread only. */
    public void movePlayer(Player player, CivPlayer cp, Civilization target, boolean isSwitch) {
        Civilization current = cp.hasCivilization()
                ? plugin.getCivilizationManager().get(cp.getCivilizationId()).orElse(null)
                : null;

        if (current != null) {
            current.removeMember(player.getUniqueId());
            Bukkit.getPluginManager().callEvent(new CivilizationLeaveEvent(player, current));
            plugin.getCivilizationManager().save(current);

            // Losing membership means losing leadership of the old civilization.
            if (current.hasLeader() && current.getLeaderUuid().equals(player.getUniqueId())) {
                plugin.getLeaderManager().clearLeader(current);
            }
        }

        cp.setCivilizationId(target.getId());
        if (isSwitch) {
            cp.setLastSwitchTimestamp(System.currentTimeMillis());
        } else if (cp.getJoinTimestamp() == 0) {
            cp.setJoinTimestamp(System.currentTimeMillis());
        }
        target.addMember(player.getUniqueId());

        plugin.getPlayerManager().save(cp);
        plugin.getCivilizationManager().save(target);

        Bukkit.getPluginManager().callEvent(new CivilizationJoinEvent(player, target, false));
    }

    /** Result of a switch-eligibility check. */
    public record SwitchEligibility(boolean eligible, String reasonMessageKey, long remainingMillis) {}

    public SwitchEligibility checkEligibility(CivPlayer cp) {
        if (!plugin.getConfigManager().isSwitchingEnabled()) {
            return new SwitchEligibility(false, "switch-disabled", 0);
        }

        SwitchMode mode = SwitchMode.fromString(plugin.getConfigManager().getSwitchModeRaw());

        switch (mode) {
            case DISABLED -> {
                return new SwitchEligibility(false, "switch-disabled", 0);
            }
            case COOLDOWN -> {
                long cooldownMillis = parseDuration(plugin.getConfigManager().getSwitchCooldownRaw());
                long last = cp.getLastSwitchTimestamp();
                if (last == 0) {
                    return new SwitchEligibility(true, "switch-eligible", 0);
                }
                long elapsed = System.currentTimeMillis() - last;
                long remaining = cooldownMillis - elapsed;
                if (remaining > 0) {
                    return new SwitchEligibility(false, "switch-on-cooldown", remaining);
                }
                return new SwitchEligibility(true, "switch-eligible", 0);
            }
            case COINS, ADMIN_APPROVAL -> {
                // Reserved for a future part; treat as disabled for now so
                // Part 1 never promises functionality it doesn't have.
                return new SwitchEligibility(false, "switch-disabled", 0);
            }
            default -> {
                return new SwitchEligibility(false, "switch-disabled", 0);
            }
        }
    }

    /** Parses simple durations like "7d", "24h", "30m", "45s". Defaults to 0 on bad input. */
    public static long parseDuration(String input) {
        if (input == null || input.isBlank()) return 0;
        Matcher m = DURATION_PATTERN.matcher(input.trim());
        long totalMillis = 0;
        boolean matchedAny = false;
        while (m.find()) {
            matchedAny = true;
            long value = Long.parseLong(m.group(1));
            char unit = Character.toLowerCase(m.group(2).charAt(0));
            totalMillis += switch (unit) {
                case 's' -> value * 1000L;
                case 'm' -> value * 60_000L;
                case 'h' -> value * 3_600_000L;
                case 'd' -> value * 86_400_000L;
                default -> 0;
            };
        }
        return matchedAny ? totalMillis : 0;
    }

    public static String formatDuration(long millis) {
        if (millis <= 0) return "0s";
        long seconds = millis / 1000;
        long days = seconds / 86400;
        seconds %= 86400;
        long hours = seconds / 3600;
        seconds %= 3600;
        long minutes = seconds / 60;
        seconds %= 60;

        StringBuilder sb = new StringBuilder();
        if (days > 0) sb.append(days).append("d ");
        if (hours > 0) sb.append(hours).append("h ");
        if (minutes > 0) sb.append(minutes).append("m ");
        if (days == 0 && hours == 0) sb.append(seconds).append("s");
        return sb.toString().trim();
    }
}
