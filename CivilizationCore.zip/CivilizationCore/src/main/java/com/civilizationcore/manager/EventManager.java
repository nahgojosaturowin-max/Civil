package com.civilizationcore.manager;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.EventType;
import com.civilizationcore.model.GameEvent;
import com.civilizationcore.model.TransactionType;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Framework for civilization events (PVP_TOURNAMENT, PARKOUR, BUILD_BATTLE,
 * QUIZ, TREASURE_HUNT, BOSS_EVENT). CivilizationCore provides creation,
 * participant tracking, and reward distribution; the actual minigame logic
 * for each event type (arenas, judging, scoring) is expected to be driven
 * by admins/other plugins calling into this framework's start/join/end
 * hooks, per the PRD's framing of Part 3 as an "events framework" rather
 * than a set of built minigames.
 */
public class EventManager {

    private final CivilizationCore plugin;
    private final Map<Long, GameEvent> activeEvents = new ConcurrentHashMap<>();
    private long nextId = 1;

    public EventManager(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    public boolean isEnabled() {
        return plugin.getConfigManager().getConfig().getBoolean("events.enabled", true);
    }

    public GameEvent start(EventType type) {
        GameEvent event = new GameEvent(type);
        event.setId(nextId++);
        activeEvents.put(event.getId(), event);
        return event;
    }

    public Optional<GameEvent> get(long id) {
        return Optional.ofNullable(activeEvents.get(id));
    }

    public Collection<GameEvent> getActive() {
        return activeEvents.values();
    }

    public void join(GameEvent event, Player player) {
        event.getParticipants().add(player.getUniqueId());
    }

    /**
     * Ends the event and, if a winning civilization is set, distributes the
     * configured default coin reward and civilization points (events-won
     * counter) to it. Coins go through EconomyManager as an EVENT_REWARD
     * transaction so it's logged like any other treasury change.
     */
    public void end(GameEvent event, String winnerCivId) {
        event.setActive(false);
        event.setEndedAt(System.currentTimeMillis());
        event.setWinnerCivId(winnerCivId);
        activeEvents.remove(event.getId());

        if (winnerCivId == null) return;

        double coins = plugin.getConfigManager().getConfig().getDouble("events.default-reward-coins", 5000);
        plugin.getEconomyManager().depositToTreasury(winnerCivId, coins, TransactionType.EVENT_REWARD, null,
                "Event reward: " + event.getType());

        plugin.getCivilizationManager().get(winnerCivId).ifPresent(civ -> {
            civ.getStats().setEventsWon(civ.getStats().getEventsWon() + 1);
            plugin.getCivilizationManager().save(civ);
        });
    }
}
