package com.civilizationcore.model;

public class HallOfFameEntry {

    private final int seasonNumber;
    private final String winnerCivId;
    private final String winnerCivName;
    private final String leaderUuid; // stored as string, leader may be offline/unknown by the time this is read
    private final String leaderName;
    private final long startDate;
    private final long endDate;

    public HallOfFameEntry(int seasonNumber, String winnerCivId, String winnerCivName,
                            String leaderUuid, String leaderName, long startDate, long endDate) {
        this.seasonNumber = seasonNumber;
        this.winnerCivId = winnerCivId;
        this.winnerCivName = winnerCivName;
        this.leaderUuid = leaderUuid;
        this.leaderName = leaderName;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public int getSeasonNumber() {
        return seasonNumber;
    }

    public String getWinnerCivId() {
        return winnerCivId;
    }

    public String getWinnerCivName() {
        return winnerCivName;
    }

    public String getLeaderUuid() {
        return leaderUuid;
    }

    public String getLeaderName() {
        return leaderName;
    }

    public long getStartDate() {
        return startDate;
    }

    public long getEndDate() {
        return endDate;
    }
}
