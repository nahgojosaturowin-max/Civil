package com.civilizationcore.model;

public enum WarType {
    TERRITORY_WAR,
    CASTLE_SIEGE,
    WEAPON_WAR,
    CIVILIZATION_BATTLE;

    public static WarType fromString(String value) {
        if (value == null) return null;
        try {
            return WarType.valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
