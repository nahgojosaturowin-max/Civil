package com.civilizationcore.model;

import java.util.UUID;

/**
 * Per-player civilization data. One instance per player, cached in memory
 * by PlayerManager and persisted through StorageManager.
 */
public class CivPlayer {

    private final UUID uuid;
    private String name;
    private String civilizationId; // null = unassigned
    private boolean leader;
    private long joinTimestamp;     // when they first joined a civilization
    private long lastSwitchTimestamp; // 0 = never switched

    public CivPlayer(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCivilizationId() {
        return civilizationId;
    }

    public void setCivilizationId(String civilizationId) {
        this.civilizationId = civilizationId;
    }

    public boolean hasCivilization() {
        return civilizationId != null;
    }

    public boolean isLeader() {
        return leader;
    }

    public void setLeader(boolean leader) {
        this.leader = leader;
    }

    public long getJoinTimestamp() {
        return joinTimestamp;
    }

    public void setJoinTimestamp(long joinTimestamp) {
        this.joinTimestamp = joinTimestamp;
    }

    public long getLastSwitchTimestamp() {
        return lastSwitchTimestamp;
    }

    public void setLastSwitchTimestamp(long lastSwitchTimestamp) {
        this.lastSwitchTimestamp = lastSwitchTimestamp;
    }
}
