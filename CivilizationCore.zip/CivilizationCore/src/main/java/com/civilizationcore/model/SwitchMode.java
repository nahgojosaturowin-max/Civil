package com.civilizationcore.model;

/**
 * Supported civilization-switching modes. Only DISABLED and COOLDOWN are
 * implemented in Part 1; COINS and ADMIN_APPROVAL are reserved for later
 * parts but kept here so config validation / future work has a home.
 */
public enum SwitchMode {
    DISABLED,
    COOLDOWN,
    COINS,
    ADMIN_APPROVAL;

    public static SwitchMode fromString(String value) {
        if (value == null) return DISABLED;
        try {
            return SwitchMode.valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return DISABLED;
        }
    }
}
