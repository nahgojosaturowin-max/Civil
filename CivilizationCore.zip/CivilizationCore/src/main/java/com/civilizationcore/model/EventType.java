package com.civilizationcore.model;

public enum EventType {
    PVP_TOURNAMENT,
    PARKOUR,
    BUILD_BATTLE,
    QUIZ,
    TREASURE_HUNT,
    BOSS_EVENT;

    public static EventType fromString(String value) {
        if (value == null) return null;
        try {
            return EventType.valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
