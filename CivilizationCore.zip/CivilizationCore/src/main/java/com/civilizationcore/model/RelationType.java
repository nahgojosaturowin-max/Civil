package com.civilizationcore.model;

public enum RelationType {
    NEUTRAL,
    ALLY,
    PEACE,
    TRADE,
    WAR;

    public static RelationType fromString(String value) {
        if (value == null) return null;
        try {
            return RelationType.valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /**
     * Two relation types are contradictory if they cannot both apply to the
     * same pair of civilizations at once - most notably ALLY and WAR.
     * NEUTRAL is compatible with nothing else being active (it simply means
     * "no special relationship"), so any non-NEUTRAL relation replaces it.
     */
    public boolean conflictsWith(RelationType other) {
        if (other == null || this == other) return false;
        if (this == WAR && (other == ALLY || other == PEACE || other == TRADE)) return true;
        if (other == WAR && (this == ALLY || this == PEACE || this == TRADE)) return true;
        return false;
    }
}
