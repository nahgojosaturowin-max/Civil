package com.civilizationcore.model;

/**
 * A single war between two civilizations. Territory/allowed-area and
 * friendly-fire rules are read from config at war-resolution time rather
 * than snapshotted per-war in Part 3's implementation, keeping the model
 * simple; the fields that matter for tracking a specific war's outcome
 * (objective, weapon target, winner, timestamps) are stored here.
 */
public class War {

    private long id = -1;
    private final String attackerCivId;
    private final String defenderCivId;
    private final WarType type;
    private WarState state = WarState.PROPOSED;

    private long scheduledStart; // 0 = not yet scheduled
    private long startedAt;      // 0 = not yet started
    private long endedAt;        // 0 = not yet ended
    private long durationMillis;

    private String objective;      // free-text description, e.g. "Hold the Crimson Castle Core for 10 minutes"
    private String targetWeaponId; // set only for WEAPON_WAR

    private String winnerCivId; // null until finished

    public War(String attackerCivId, String defenderCivId, WarType type) {
        this.attackerCivId = attackerCivId;
        this.defenderCivId = defenderCivId;
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAttackerCivId() {
        return attackerCivId;
    }

    public String getDefenderCivId() {
        return defenderCivId;
    }

    public WarType getType() {
        return type;
    }

    public WarState getState() {
        return state;
    }

    public void setState(WarState state) {
        this.state = state;
    }

    public long getScheduledStart() {
        return scheduledStart;
    }

    public void setScheduledStart(long scheduledStart) {
        this.scheduledStart = scheduledStart;
    }

    public long getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(long startedAt) {
        this.startedAt = startedAt;
    }

    public long getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(long endedAt) {
        this.endedAt = endedAt;
    }

    public long getDurationMillis() {
        return durationMillis;
    }

    public void setDurationMillis(long durationMillis) {
        this.durationMillis = durationMillis;
    }

    public String getObjective() {
        return objective;
    }

    public void setObjective(String objective) {
        this.objective = objective;
    }

    public String getTargetWeaponId() {
        return targetWeaponId;
    }

    public void setTargetWeaponId(String targetWeaponId) {
        this.targetWeaponId = targetWeaponId;
    }

    public String getWinnerCivId() {
        return winnerCivId;
    }

    public void setWinnerCivId(String winnerCivId) {
        this.winnerCivId = winnerCivId;
    }

    public boolean involves(String civId) {
        return attackerCivId.equalsIgnoreCase(civId) || defenderCivId.equalsIgnoreCase(civId);
    }

    public String otherSide(String civId) {
        return attackerCivId.equalsIgnoreCase(civId) ? defenderCivId : attackerCivId;
    }
}
