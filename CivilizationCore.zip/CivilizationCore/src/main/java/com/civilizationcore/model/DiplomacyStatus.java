package com.civilizationcore.model;

public enum DiplomacyStatus {
    PENDING,
    ACCEPTED,
    DENIED,
    CANCELLED
}
