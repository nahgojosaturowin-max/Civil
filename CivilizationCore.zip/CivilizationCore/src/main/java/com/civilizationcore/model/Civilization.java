package com.civilizationcore.model;

import org.bukkit.Location;
import org.bukkit.World;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Represents a single civilization. Holds only in-memory state; persistence
 * is handled by StorageManager. Keep this class free of Bukkit scheduling
 * or command logic - it is a pure data holder plus small helpers.
 */
public class Civilization {

    private final String id;
    private String name;
    private String color;
    private String prefix;

    private UUID leaderUuid;

    // Members tracked by UUID. LinkedHashSet keeps a stable iteration order.
    private final Set<UUID> members = Collections.synchronizedSet(new LinkedHashSet<>());

    private String capitalWorld;
    private double capitalX;
    private double capitalY;
    private double capitalZ;
    private boolean capitalSet = false;

    private final CivilizationStats stats = new CivilizationStats();

    // Treasury balance, kept on the civilization itself (rather than a
    // separate model) since it's simple scalar state that's always loaded
    // alongside the civilization anyway. All mutations should go through
    // EconomyManager so transactions get logged consistently.
    private double treasuryBalance = 0;

    public Civilization(String id, String name, String color, String prefix) {
        this.id = id;
        this.name = name;
        this.color = color;
        this.prefix = prefix;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public UUID getLeaderUuid() {
        return leaderUuid;
    }

    public void setLeaderUuid(UUID leaderUuid) {
        this.leaderUuid = leaderUuid;
    }

    public boolean hasLeader() {
        return leaderUuid != null;
    }

    public Set<UUID> getMembers() {
        return members;
    }

    public int getMemberCount() {
        return members.size();
    }

    public void addMember(UUID uuid) {
        members.add(uuid);
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }

    public boolean hasCapital() {
        return capitalSet;
    }

    public void setCapital(Location location) {
        this.capitalWorld = location.getWorld().getName();
        this.capitalX = location.getX();
        this.capitalY = location.getY();
        this.capitalZ = location.getZ();
        this.capitalSet = true;
    }

    /** Used when loading from storage, where we have raw coordinate fields. */
    public void setCapitalRaw(String world, double x, double y, double z) {
        if (world == null) {
            this.capitalSet = false;
            return;
        }
        this.capitalWorld = world;
        this.capitalX = x;
        this.capitalY = y;
        this.capitalZ = z;
        this.capitalSet = true;
    }

    public Location getCapitalLocation() {
        if (!capitalSet) return null;
        World world = org.bukkit.Bukkit.getWorld(capitalWorld);
        if (world == null) return null;
        return new Location(world, capitalX, capitalY, capitalZ);
    }

    public String getCapitalWorld() {
        return capitalWorld;
    }

    public double getCapitalX() {
        return capitalX;
    }

    public double getCapitalY() {
        return capitalY;
    }

    public double getCapitalZ() {
        return capitalZ;
    }

    public CivilizationStats getStats() {
        return stats;
    }

    public double getTreasuryBalance() {
        return treasuryBalance;
    }

    public void setTreasuryBalance(double treasuryBalance) {
        this.treasuryBalance = treasuryBalance;
    }

    /**
     * Statistics holder. Wars won/lost were tracked from Part 1; Part 2 adds
     * the remaining fields from the PRD's statistics framework (events won,
     * territory, weapons controlled) as simple counters ready for Part 3 to
     * actually populate - nothing in Part 1/2 writes to territory or
     * weaponsControlled yet.
     */
    public static class CivilizationStats {
        private int warsWon = 0;
        private int warsLost = 0;
        private int eventsWon = 0;
        private int territory = 0;
        private int weaponsControlled = 0;

        public int getWarsWon() {
            return warsWon;
        }

        public void setWarsWon(int warsWon) {
            this.warsWon = warsWon;
        }

        public int getWarsLost() {
            return warsLost;
        }

        public void setWarsLost(int warsLost) {
            this.warsLost = warsLost;
        }

        public int getEventsWon() {
            return eventsWon;
        }

        public void setEventsWon(int eventsWon) {
            this.eventsWon = eventsWon;
        }

        public int getTerritory() {
            return territory;
        }

        public void setTerritory(int territory) {
            this.territory = territory;
        }

        public int getWeaponsControlled() {
            return weaponsControlled;
        }

        public void setWeaponsControlled(int weaponsControlled) {
            this.weaponsControlled = weaponsControlled;
        }
    }
}
