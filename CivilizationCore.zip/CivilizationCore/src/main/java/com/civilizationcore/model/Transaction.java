package com.civilizationcore.model;

import java.util.UUID;

/** Read-only record of a single treasury transaction, as stored/logged in the DB. */
public class Transaction {

    private final long id;
    private final String civilizationId;
    private final UUID playerUuid; // null for system-generated transactions (e.g. TAX applied civ-wide)
    private final double amount;
    private final TransactionType type;
    private final long timestamp;
    private final String reason;

    public Transaction(long id, String civilizationId, UUID playerUuid, double amount,
                        TransactionType type, long timestamp, String reason) {
        this.id = id;
        this.civilizationId = civilizationId;
        this.playerUuid = playerUuid;
        this.amount = amount;
        this.type = type;
        this.timestamp = timestamp;
        this.reason = reason;
    }

    public long getId() {
        return id;
    }

    public String getCivilizationId() {
        return civilizationId;
    }

    public UUID getPlayerUuid() {
        return playerUuid;
    }

    public double getAmount() {
        return amount;
    }

    public TransactionType getType() {
        return type;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getReason() {
        return reason;
    }
}
