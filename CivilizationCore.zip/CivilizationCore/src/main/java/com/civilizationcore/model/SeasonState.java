package com.civilizationcore.model;

public enum SeasonState {
    ACTIVE,
    GRACE_PERIOD,
    FINISHED
}
