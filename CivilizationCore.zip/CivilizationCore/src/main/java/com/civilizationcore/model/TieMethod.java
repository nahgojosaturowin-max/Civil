package com.civilizationcore.model;

public enum TieMethod {
    RUNOFF,
    RANDOM,
    ADMIN_DECISION,
    PREVIOUS_LEADER;

    public static TieMethod fromString(String value) {
        if (value == null) return RUNOFF;
        try {
            return TieMethod.valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return RUNOFF;
        }
    }
}
