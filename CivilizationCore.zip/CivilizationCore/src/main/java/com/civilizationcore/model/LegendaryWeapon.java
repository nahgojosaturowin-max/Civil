package com.civilizationcore.model;

import java.util.List;
import java.util.UUID;

/**
 * Represents one of the exactly-three Legendary Weapons. Ownership lives at
 * the civilization level ("current civilization"); the "current holder" is
 * whoever is that civilization's leader, since usage is leader-only and
 * automatically follows leadership changes (see WeaponManager). The
 * instanceId is the PersistentDataContainer value that makes the physical
 * item unforgeable/uncopyable - only an item carrying the matching
 * (weaponId, instanceId) pair is treated as the genuine article.
 */
public class LegendaryWeapon {

    private final String id; // e.g. "inferno_blade"
    private final String originalCivilizationId;
    private String currentCivilizationId;
    private UUID instanceId;

    private String displayName;
    private String materialName;
    private int customModelData;
    private List<String> abilities;
    private long cooldownMillis;

    public LegendaryWeapon(String id, String originalCivilizationId) {
        this.id = id;
        this.originalCivilizationId = originalCivilizationId;
        this.currentCivilizationId = originalCivilizationId;
        this.instanceId = UUID.randomUUID();
    }

    public String getId() {
        return id;
    }

    public String getOriginalCivilizationId() {
        return originalCivilizationId;
    }

    public String getCurrentCivilizationId() {
        return currentCivilizationId;
    }

    public void setCurrentCivilizationId(String currentCivilizationId) {
        this.currentCivilizationId = currentCivilizationId;
    }

    public UUID getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(UUID instanceId) {
        this.instanceId = instanceId;
    }

    /** Mints a new instance id, invalidating any previously-issued physical item. */
    public void regenerateInstanceId() {
        this.instanceId = UUID.randomUUID();
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public int getCustomModelData() {
        return customModelData;
    }

    public void setCustomModelData(int customModelData) {
        this.customModelData = customModelData;
    }

    public List<String> getAbilities() {
        return abilities;
    }

    public void setAbilities(List<String> abilities) {
        this.abilities = abilities;
    }

    public long getCooldownMillis() {
        return cooldownMillis;
    }

    public void setCooldownMillis(long cooldownMillis) {
        this.cooldownMillis = cooldownMillis;
    }
}
