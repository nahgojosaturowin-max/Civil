package com.civilizationcore.model;

public enum ElectionState {
    IDLE,
    NOMINATION,
    VOTING,
    FINISHED
}
