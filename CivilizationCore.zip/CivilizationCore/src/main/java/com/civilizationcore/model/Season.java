package com.civilizationcore.model;

public class Season {

    private int number;
    private long startDate;
    private long endDate; // 0 while active
    private SeasonState state = SeasonState.ACTIVE;
    private String winnerCivId; // null until won
    private long graceEndsAt;   // valid only during GRACE_PERIOD

    public Season(int number, long startDate) {
        this.number = number;
        this.startDate = startDate;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public long getStartDate() {
        return startDate;
    }

    public void setStartDate(long startDate) {
        this.startDate = startDate;
    }

    public long getEndDate() {
        return endDate;
    }

    public void setEndDate(long endDate) {
        this.endDate = endDate;
    }

    public SeasonState getState() {
        return state;
    }

    public void setState(SeasonState state) {
        this.state = state;
    }

    public String getWinnerCivId() {
        return winnerCivId;
    }

    public void setWinnerCivId(String winnerCivId) {
        this.winnerCivId = winnerCivId;
    }

    public long getGraceEndsAt() {
        return graceEndsAt;
    }

    public void setGraceEndsAt(long graceEndsAt) {
        this.graceEndsAt = graceEndsAt;
    }
}
