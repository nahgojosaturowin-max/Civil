package com.civilizationcore.model;

/**
 * A pending (or resolved) diplomacy proposal from one civilization to
 * another. Both sides must agree before the relation actually changes -
 * see DiplomacyManager for the acceptance flow.
 */
public class DiplomacyRequest {

    private long id = -1;
    private final String requesterCivId;
    private final String targetCivId;
    private final RelationType relationType;
    private DiplomacyStatus status = DiplomacyStatus.PENDING;
    private long createdAt = System.currentTimeMillis();

    public DiplomacyRequest(String requesterCivId, String targetCivId, RelationType relationType) {
        this.requesterCivId = requesterCivId;
        this.targetCivId = targetCivId;
        this.relationType = relationType;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRequesterCivId() {
        return requesterCivId;
    }

    public String getTargetCivId() {
        return targetCivId;
    }

    public RelationType getRelationType() {
        return relationType;
    }

    public DiplomacyStatus getStatus() {
        return status;
    }

    public void setStatus(DiplomacyStatus status) {
        this.status = status;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
}
