package com.civilizationcore.model;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Represents one run of a civilization event. Part 3 provides the
 * framework (creation, participant tracking, reward distribution) rather
 * than fully-built minigames for each type - actual gameplay for e.g.
 * PARKOUR or BUILD_BATTLE is expected to be wired up by server-specific
 * setup (arenas, judges, etc.) using this framework's start/end hooks and
 * the coin/point rewards it distributes.
 */
public class GameEvent {

    private long id = -1;
    private final EventType type;
    private boolean active = true;
    private final long startedAt = System.currentTimeMillis();
    private long endedAt;

    private final Set<UUID> participants = new LinkedHashSet<>();
    private String winnerCivId; // may be null for events without a civ-level winner

    public GameEvent(EventType type) {
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public EventType getType() {
        return type;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public long getStartedAt() {
        return startedAt;
    }

    public long getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(long endedAt) {
        this.endedAt = endedAt;
    }

    public Set<UUID> getParticipants() {
        return participants;
    }

    public String getWinnerCivId() {
        return winnerCivId;
    }

    public void setWinnerCivId(String winnerCivId) {
        this.winnerCivId = winnerCivId;
    }
}
