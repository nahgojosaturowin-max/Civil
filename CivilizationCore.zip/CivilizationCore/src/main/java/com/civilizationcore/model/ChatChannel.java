package com.civilizationcore.model;

public enum ChatChannel {
    GLOBAL,
    CIVILIZATION,
    ALLIANCE,
    LEADER
}
