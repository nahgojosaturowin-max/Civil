package com.civilizationcore.model;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Represents one election cycle for a civilization. Elections are cached
 * in memory while active (IDLE elections aren't tracked at all) and
 * persisted to the database as they progress so a server restart mid-cycle
 * doesn't lose nominations or votes. Vote *choices* are kept in memory and
 * mirrored to the DB primarily so duplicate voting can be enforced even
 * across a restart.
 */
public class Election {

    private long id = -1; // DB row id once persisted, -1 until then
    private final String civilizationId;
    private ElectionState state = ElectionState.IDLE;

    private long nominationEndsAt;
    private long votingEndsAt;

    // candidate UUID -> confirmed?
    private final Map<UUID, Boolean> candidates = new ConcurrentHashMap<>();
    private final Set<UUID> withdrawn = ConcurrentHashMap.newKeySet();

    // voter UUID -> candidate UUID
    private final Map<UUID, UUID> votes = new ConcurrentHashMap<>();

    private UUID winner;

    // Snapshot of who led the civilization when the election began, used by
    // the PREVIOUS_LEADER tie-break method.
    private UUID previousLeader;

    // How many RUNOFF rounds have already run for this election. Capped at
    // 1 by ElectionManager to guarantee elections always terminate.
    private int runoffCount = 0;

    public Election(String civilizationId) {
        this.civilizationId = civilizationId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCivilizationId() {
        return civilizationId;
    }

    public ElectionState getState() {
        return state;
    }

    public void setState(ElectionState state) {
        this.state = state;
    }

    public long getNominationEndsAt() {
        return nominationEndsAt;
    }

    public void setNominationEndsAt(long nominationEndsAt) {
        this.nominationEndsAt = nominationEndsAt;
    }

    public long getVotingEndsAt() {
        return votingEndsAt;
    }

    public void setVotingEndsAt(long votingEndsAt) {
        this.votingEndsAt = votingEndsAt;
    }

    public Map<UUID, Boolean> getCandidates() {
        return candidates;
    }

    /** Candidates who are confirmed and have not withdrawn - i.e. actually votable. */
    public List<UUID> getActiveCandidates() {
        List<UUID> result = new ArrayList<>();
        for (Map.Entry<UUID, Boolean> entry : candidates.entrySet()) {
            if (Boolean.TRUE.equals(entry.getValue()) && !withdrawn.contains(entry.getKey())) {
                result.add(entry.getKey());
            }
        }
        return result;
    }

    /** All non-withdrawn candidates regardless of confirmation, for /civ election candidates display. */
    public List<UUID> getAllNonWithdrawnCandidates() {
        List<UUID> result = new ArrayList<>();
        for (UUID uuid : candidates.keySet()) {
            if (!withdrawn.contains(uuid)) result.add(uuid);
        }
        return result;
    }

    public boolean isConfirmed(UUID uuid) {
        return Boolean.TRUE.equals(candidates.get(uuid));
    }

    public void addCandidate(UUID uuid, boolean confirmed) {
        candidates.put(uuid, confirmed);
        withdrawn.remove(uuid);
    }

    public void withdrawCandidate(UUID uuid) {
        withdrawn.add(uuid);
    }

    /** True if the uuid is a confirmed, non-withdrawn (i.e. votable) candidate. */
    public boolean isCandidate(UUID uuid) {
        return isConfirmed(uuid) && !withdrawn.contains(uuid);
    }

    public Map<UUID, UUID> getVotes() {
        return votes;
    }

    public boolean hasVoted(UUID voter) {
        return votes.containsKey(voter);
    }

    /** Returns false if the voter already voted (duplicate voting prevention). */
    public boolean castVote(UUID voter, UUID candidate) {
        if (votes.containsKey(voter)) return false;
        votes.put(voter, candidate);
        return true;
    }

    public Map<UUID, Integer> tally() {
        Map<UUID, Integer> counts = new HashMap<>();
        for (UUID candidate : getActiveCandidates()) {
            counts.put(candidate, 0);
        }
        for (UUID candidate : votes.values()) {
            counts.merge(candidate, 1, Integer::sum);
        }
        return counts;
    }

    public UUID getWinner() {
        return winner;
    }

    public void setWinner(UUID winner) {
        this.winner = winner;
    }

    public UUID getPreviousLeader() {
        return previousLeader;
    }

    public void setPreviousLeader(UUID previousLeader) {
        this.previousLeader = previousLeader;
    }

    public int getRunoffCount() {
        return runoffCount;
    }

    public void incrementRunoffCount() {
        this.runoffCount++;
    }

    /** Resets vote state for a runoff round, keeping only the given candidates. */
    public void resetForRunoff(Collection<UUID> keepCandidates) {
        candidates.keySet().retainAll(keepCandidates);
        withdrawn.clear();
        votes.clear();
    }
}
