package com.civilizationcore.model;

public enum WarState {
    PROPOSED,
    ACCEPTED,
    SCHEDULED,
    ACTIVE,
    FINISHED,
    CANCELLED
}
