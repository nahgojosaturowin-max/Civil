package com.civilizationcore.model;

public enum TransactionType {
    PLAYER_DEPOSIT,
    PLAYER_WITHDRAW,
    TAX,
    WAR_REWARD,
    EVENT_REWARD,
    ADMIN
}
