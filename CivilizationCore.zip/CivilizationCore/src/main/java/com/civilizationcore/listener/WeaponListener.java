package com.civilizationcore.listener;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.manager.AssignmentManager;
import com.civilizationcore.model.LegendaryWeapon;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Maps physical interactions with a genuine Legendary Weapon to one of its
 * configured abilities, restricted to the current leader of the weapon's
 * current owning civilization (see WeaponManager#canUseAbilities, which is
 * re-checked on every activation attempt so a leadership change takes
 * effect immediately - there's no cached "you were leader" state here).
 *
 * Input mapping (simple, since Bukkit doesn't expose a rich combo system):
 *   right-click                 -> ability[0]
 *   shift + right-click         -> ability[1]
 *   left-click a block          -> ability[2]
 *   swap-hand (F key) w/ weapon -> ability[3]
 * Any ability index beyond the weapon's configured list is simply unavailable.
 */
public class WeaponListener implements Listener {

    private final CivilizationCore plugin;

    public WeaponListener(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        ItemStack item = event.getItem();
        if (item == null) return;
        Optional<String> weaponIdOpt = plugin.getWeaponManager().getWeaponId(item);
        if (weaponIdOpt.isEmpty()) return;

        int abilityIndex;
        if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            abilityIndex = event.getPlayer().isSneaking() ? 1 : 0;
        } else if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
            abilityIndex = 2;
        } else {
            return;
        }

        activate(event.getPlayer(), item, weaponIdOpt.get(), abilityIndex);
    }

    @EventHandler
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        ItemStack item = event.getMainHandItem();
        if (item == null) return;
        Optional<String> weaponIdOpt = plugin.getWeaponManager().getWeaponId(item);
        if (weaponIdOpt.isEmpty()) return;

        event.setCancelled(true); // don't actually swap - this input is repurposed for ability 4
        activate(event.getPlayer(), item, weaponIdOpt.get(), 3);
    }

    private void activate(Player player, ItemStack item, String weaponId, int abilityIndex) {
        Optional<LegendaryWeapon> weaponOpt = plugin.getWeaponManager().get(weaponId);
        if (weaponOpt.isEmpty()) return;
        LegendaryWeapon weapon = weaponOpt.get();

        if (!plugin.getWeaponManager().isGenuine(item)) {
            plugin.getMessageManager().sendRaw(player, "&cThis weapon is not genuine and has no power.");
            return;
        }
        if (!plugin.getWeaponManager().canUseAbilities(player, weapon)) {
            plugin.getMessageManager().send(player, "weapon-not-leader");
            return;
        }

        List<String> abilities = weapon.getAbilities();
        if (abilities == null || abilityIndex >= abilities.size()) return;
        String ability = abilities.get(abilityIndex);

        if (plugin.getWeaponManager().isOnCooldown(player, weapon)) {
            plugin.getMessageManager().send(player, "weapon-on-cooldown", Map.of(
                    "time", AssignmentManager.formatDuration(plugin.getWeaponManager().getRemainingCooldownMillis(player, weapon))));
            return;
        }

        applyAbilityEffect(player, ability);
        plugin.getWeaponManager().applyCooldown(player, weapon);
    }

    /**
     * Applies a simple, real gameplay effect for each named ability. These
     * are deliberately lightweight (particles/sound/potion effects/short-range
     * impact) rather than full custom-combat systems, matching the scope of
     * a "leader-only special ability" rather than a full ability-kit plugin.
     */
    private void applyAbilityEffect(Player player, String ability) {
        Location loc = player.getLocation();

        switch (ability) {
            // Inferno Blade
            case "fire_slash" -> {
                for (LivingEntity target : nearbyEnemies(player, 4)) {
                    target.setFireTicks(60);
                    target.damage(4, player);
                }
                player.getWorld().spawnParticle(Particle.FLAME, loc, 30, 1, 0.5, 1, 0.05);
                player.getWorld().playSound(loc, Sound.ITEM_FIRECHARGE_USE, 1f, 0.8f);
            }
            case "fire_dash" -> {
                Vector dash = loc.getDirection().normalize().multiply(1.6).setY(0.3);
                player.setVelocity(dash);
                player.setFireTicks(0); // the wielder doesn't burn themselves
                player.getWorld().spawnParticle(Particle.FLAME, loc, 40, 0.3, 0.3, 0.3, 0.02);
                player.getWorld().playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
            }
            case "burning_strike" -> {
                for (LivingEntity target : nearbyEnemies(player, 3)) {
                    target.setFireTicks(100);
                }
                player.getWorld().playSound(loc, Sound.ENTITY_GENERIC_BURN, 1f, 1f);
            }
            case "area_fire" -> {
                for (LivingEntity target : nearbyEnemies(player, 6)) {
                    target.setFireTicks(140);
                    target.damage(2, player);
                }
                player.getWorld().spawnParticle(Particle.LAVA, loc, 40, 3, 0.5, 3, 0);
                player.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.2f);
            }

            // Storm Trident
            case "lightning_strike" -> {
                nearestTarget(player, 20).ifPresentOrElse(
                        target -> player.getWorld().strikeLightning(target.getLocation()),
                        () -> player.getWorld().strikeLightningEffect(loc.clone().add(loc.getDirection().multiply(5))));
            }
            case "lightning_dash" -> {
                Vector dash = loc.getDirection().normalize().multiply(1.8).setY(0.4);
                player.setVelocity(dash);
                player.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 40, 0.3, 0.3, 0.3, 0.05);
                player.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.6f, 1.5f);
            }
            case "knockback" -> {
                for (LivingEntity target : nearbyEnemies(player, 4)) {
                    Vector push = target.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(1.5).setY(0.4);
                    target.setVelocity(push);
                }
                player.getWorld().playSound(loc, Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1f, 1f);
            }
            case "chain_lightning" -> {
                List<LivingEntity> targets = nearbyEnemies(player, 8);
                for (int i = 0; i < Math.min(3, targets.size()); i++) {
                    player.getWorld().strikeLightningEffect(targets.get(i).getLocation());
                    targets.get(i).damage(3, player);
                }
            }

            // Nature Hammer
            case "healing_pulse" -> {
                for (org.bukkit.entity.Entity nearby : player.getNearbyEntities(6, 6, 6)) {
                    if (nearby instanceof Player ally && isAlly(player, ally)) {
                        ally.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
                    }
                }
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
                player.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 30, 2, 1, 2, 0);
            }
            case "root" -> {
                for (LivingEntity target : nearbyEnemies(player, 4)) {
                    target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 4));
                }
                player.getWorld().spawnParticle(Particle.BLOCK, loc, 30, 1, 0.2, 1, 0, org.bukkit.Material.MOSS_BLOCK.createBlockData());
            }
            case "earthquake" -> {
                for (LivingEntity target : nearbyEnemies(player, 6)) {
                    target.damage(3, player);
                    target.setVelocity(target.getVelocity().setY(0.5));
                }
                player.getWorld().spawnParticle(Particle.EXPLOSION, loc, 3, 2, 0.2, 2, 0);
                player.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.6f);
            }

            default -> plugin.getLogger().fine("Unhandled weapon ability: " + ability);
        }
    }

    private List<LivingEntity> nearbyEnemies(Player player, double radius) {
        return player.getNearbyEntities(radius, radius, radius).stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(e -> !(e instanceof Player p) || !isAlly(player, p))
                .toList();
    }

    private Optional<LivingEntity> nearestTarget(Player player, double radius) {
        return nearbyEnemies(player, radius).stream()
                .min((a, b) -> Double.compare(a.getLocation().distanceSquared(player.getLocation()),
                        b.getLocation().distanceSquared(player.getLocation())));
    }

    /** Same civilization, or an allied civilization (per DiplomacyManager), counts as an ally for these effects. */
    private boolean isAlly(Player player, Player other) {
        if (player.getUniqueId().equals(other.getUniqueId())) return true;
        var cpA = plugin.getPlayerManager().get(player.getUniqueId()).orElse(null);
        var cpB = plugin.getPlayerManager().get(other.getUniqueId()).orElse(null);
        if (cpA == null || cpB == null || !cpA.hasCivilization() || !cpB.hasCivilization()) return false;
        if (cpA.getCivilizationId().equalsIgnoreCase(cpB.getCivilizationId())) return true;
        var relation = plugin.getDiplomacyManager().getRelation(cpA.getCivilizationId(), cpB.getCivilizationId());
        return relation == com.civilizationcore.model.RelationType.ALLY;
    }
}
