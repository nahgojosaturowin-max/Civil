package com.civilizationcore.listener;

import com.civilizationcore.CivilizationCore;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Iterator;

/**
 * Blocks the most common duplication/laundering vectors for Legendary
 * Weapons: crafting, anvil combination, and grindstone stripping (which
 * could otherwise be used to try to launder a genuine item's identity or
 * combine/duplicate it via recipe exploits). Also prevents a weapon from
 * being lost to death drops - it's removed from the drop list and silently
 * returned to its owner on respawn, since the weapon's true "location" is
 * always tracked at the civilization level (WeaponManager), not by wherever
 * the physical item happens to be sitting in the world.
 *
 * This is not an exhaustive anti-dupe suite (that would require auditing
 * every third-party plugin interaction on a given server) but covers the
 * vanilla-mechanic vectors named in the PRD.
 */
public class WeaponProtectionListener implements Listener {

    private final CivilizationCore plugin;

    public WeaponProtectionListener(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        for (ItemStack item : event.getInventory().getMatrix()) {
            if (plugin.getWeaponManager().isLegendaryItem(item)) {
                event.getInventory().setResult(null);
                return;
            }
        }
    }

    @EventHandler
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        ItemStack first = event.getInventory().getItem(0);
        ItemStack second = event.getInventory().getItem(1);
        if (plugin.getWeaponManager().isLegendaryItem(first) || plugin.getWeaponManager().isLegendaryItem(second)) {
            event.setResult(null);
        }
    }

    @EventHandler
    public void onPrepareGrindstone(PrepareGrindstoneEvent event) {
        ItemStack first = event.getInventory().getItem(0);
        ItemStack second = event.getInventory().getItem(1);
        if (plugin.getWeaponManager().isLegendaryItem(first) || plugin.getWeaponManager().isLegendaryItem(second)) {
            event.setResult(null);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Iterator<ItemStack> it = event.getDrops().iterator();
        while (it.hasNext()) {
            ItemStack item = it.next();
            if (plugin.getWeaponManager().isLegendaryItem(item)) {
                it.remove();
            }
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        plugin.getPlayerManager().get(player.getUniqueId()).ifPresent(cp -> {
            if (!cp.isLeader() || !cp.hasCivilization()) return;
            plugin.getCivilizationManager().get(cp.getCivilizationId()).ifPresent(civ -> {
                for (var weapon : plugin.getWeaponManager().getOwnedBy(civ.getId())) {
                    boolean alreadyHolding = player.getInventory().contains(plugin.getWeaponManager().createItem(weapon).getType());
                    if (!alreadyHolding) {
                        player.getInventory().addItem(plugin.getWeaponManager().createItem(weapon));
                    }
                }
            });
        });
    }
}
