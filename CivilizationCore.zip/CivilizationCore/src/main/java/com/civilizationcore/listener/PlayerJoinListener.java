package com.civilizationcore.listener;

import com.civilizationcore.CivilizationCore;
import com.civilizationcore.model.Civilization;
import com.civilizationcore.model.CivPlayer;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;

public class PlayerJoinListener implements Listener {

    private final CivilizationCore plugin;

    public PlayerJoinListener(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        var player = event.getPlayer();

        plugin.getPlayerManager().loadOrCreate(player.getUniqueId(), player.getName())
                .thenAccept(cp -> Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!player.isOnline()) return;

                    if (!cp.hasCivilization()) {
                        // First-time player: auto-assign to lowest-population civilization.
                        Civilization assigned = plugin.getAssignmentManager().assignNewPlayer(player, cp);
                        if (assigned != null) {
                            plugin.getMessageManager().send(player, "assigned", Map.of("civilization", assigned.getName()));
                        }
                    } else {
                        // Returning player: make sure they're counted as a member and
                        // reapply leader permissions (attachments don't persist across sessions).
                        plugin.getCivilizationManager().get(cp.getCivilizationId()).ifPresent(civ -> {
                            civ.addMember(player.getUniqueId());
                            plugin.getLeaderManager().catchUpLeaderStateOnJoin(player, civ);
                        });
                    }

                    plugin.getScoreboardManager().update(player);
                }));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        var player = event.getPlayer();
        plugin.getLeaderManager().revokeLeaderPermissions(player);
        plugin.getPlayerManager().get(player.getUniqueId()).ifPresent(cp -> plugin.getPlayerManager().save(cp));
        // Keep the CivPlayer cached (not unloaded) - Part 1 keeps things simple
        // and the cache is small enough for 50-100 concurrent players. Data
        // is saved above regardless so nothing is lost if memory is ever cleared.
    }
}
