package com.civilizationcore.listener;

import com.civilizationcore.CivilizationCore;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;

/**
 * The crown's validity is defined purely by PersistentDataContainer +
 * current leader lookup (see CrownManager#isCrownValidFor) - nothing here
 * needs to "destroy" an old crown, since any code checking leader status
 * (permissions, commands, future features) should call isCrownValidFor
 * rather than trusting item possession alone. This listener just gives
 * players a heads-up if they're holding a crown that no longer means
 * anything, so it doesn't look like a bug.
 */
public class CrownListener implements Listener {

    private final CivilizationCore plugin;

    public CrownListener(CivilizationCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        for (ItemStack item : player.getInventory().getContents()) {
            if (item == null) continue;
            if (plugin.getCrownManager().isCrown(item) && !plugin.getCrownManager().isCrownValidFor(player, item)) {
                plugin.getCrownManager().getCrownCivilizationId(item).ifPresent(civId ->
                        plugin.getCivilizationManager().get(civId).ifPresent(civ ->
                                plugin.getMessageManager().sendRaw(player,
                                        "&7Note: the crown of " + civ.getName() + " you're carrying is no longer valid - you are not its leader.")
                        )
                );
            }
        }
    }
}
