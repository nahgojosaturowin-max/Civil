package com.civilizationcore;

import com.civilizationcore.command.*;
import com.civilizationcore.listener.*;
import com.civilizationcore.manager.*;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class CivilizationCore extends JavaPlugin {

    // Part 1
    private ConfigManager configManager;
    private MessageManager messageManager;
    private StorageManager storageManager;
    private CivilizationManager civilizationManager;
    private PlayerManager playerManager;
    private LeaderManager leaderManager;
    private CapitalManager capitalManager;
    private CrownManager crownManager;
    private AssignmentManager assignmentManager;
    private ScoreboardManager scoreboardManager;

    // Part 2
    private ElectionManager electionManager;
    private EconomyManager economyManager;
    private DiplomacyManager diplomacyManager;
    private ChatManager chatManager;
    private StatisticsManager statisticsManager;
    private DiscordIntegrationManager discordIntegrationManager;

    // Part 3
    private WeaponManager weaponManager;
    private WarManager warManager;
    private EventManager eventManager;
    private SeasonManager seasonManager;
    private TerritoryManager territoryManager;

    @Override
    public void onEnable() {
        // Order matters: config -> messages -> storage -> everything else.
        configManager = new ConfigManager(this);
        configManager.load();

        messageManager = new MessageManager(this);
        storageManager = new StorageManager(this);
        storageManager.init();

        civilizationManager = new CivilizationManager(this);
        playerManager = new PlayerManager(this);
        leaderManager = new LeaderManager(this);
        capitalManager = new CapitalManager(this);
        crownManager = new CrownManager(this);
        assignmentManager = new AssignmentManager(this);
        scoreboardManager = new ScoreboardManager(this);

        electionManager = new ElectionManager(this);
        economyManager = new EconomyManager(this);
        diplomacyManager = new DiplomacyManager(this);
        chatManager = new ChatManager(this);
        statisticsManager = new StatisticsManager(this);
        discordIntegrationManager = new DiscordIntegrationManager(this);

        territoryManager = new TerritoryManager(this);
        weaponManager = new WeaponManager(this);
        warManager = new WarManager(this);
        eventManager = new EventManager(this);
        seasonManager = new SeasonManager(this);

        civilizationManager.loadAll().thenRun(() -> {
            getLogger().info("Loaded " + civilizationManager.getAll().size() + " civilizations.");
            // These depend on civilizations already being cached.
            diplomacyManager.loadAll();
            weaponManager.loadAll();
            warManager.loadAll();
            seasonManager.loadOrStartSeason();
        }).exceptionally(ex -> {
            getLogger().severe("Failed to load civilizations: " + ex.getMessage());
            return null;
        });

        economyManager.setup();

        registerCommands();
        registerListeners();

        scoreboardManager.start();
        electionManager.start();
        warManager.start();

        getLogger().info("CivilizationCore has been enabled.");
    }

    @Override
    public void onDisable() {
        if (scoreboardManager != null) scoreboardManager.stop();
        if (electionManager != null) electionManager.stop();
        if (warManager != null) warManager.stop();

        // Flush every cached player and civilization to disk before shutdown.
        if (playerManager != null) {
            playerManager.getCache().values().forEach(cp -> playerManager.save(cp));
        }
        if (civilizationManager != null) {
            civilizationManager.saveAll();
        }
        if (weaponManager != null) {
            weaponManager.saveAll();
        }
        if (warManager != null) {
            warManager.saveAll();
        }
        if (storageManager != null) {
            storageManager.shutdown();
        }

        getLogger().info("CivilizationCore has been disabled.");
    }

    private void registerCommands() {
        CivCommand civCommand = new CivCommand(this);
        getCommand("civ").setExecutor(civCommand);
        getCommand("civ").setTabCompleter(civCommand);

        CivAdminCommand adminCommand = new CivAdminCommand(this);
        getCommand("civadmin").setExecutor(adminCommand);
        getCommand("civadmin").setTabCompleter(adminCommand);

        DiplomacyCommand diplomacyCommand = new DiplomacyCommand(this);
        getCommand("diplomacy").setExecutor(diplomacyCommand);
        getCommand("diplomacy").setTabCompleter(diplomacyCommand);

        WarCommand warCommand = new WarCommand(this);
        getCommand("war").setExecutor(warCommand);
        getCommand("war").setTabCompleter(warCommand);

        SeasonCommand seasonCommand = new SeasonCommand(this);
        getCommand("season").setExecutor(seasonCommand);
        getCommand("season").setTabCompleter(seasonCommand);
    }

    private void registerListeners() {
        Bukkit.getPluginManager().registerEvents(new PlayerJoinListener(this), this);
        Bukkit.getPluginManager().registerEvents(new CrownListener(this), this);
        Bukkit.getPluginManager().registerEvents(new WeaponListener(this), this);
        Bukkit.getPluginManager().registerEvents(new WeaponProtectionListener(this), this);
    }

    public void reload() {
        configManager.reload();
        civilizationManager.loadAll();
        scoreboardManager.start();
    }

    // ---- Getters -----------------------------------------------------

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }

    public StorageManager getStorageManager() {
        return storageManager;
    }

    public CivilizationManager getCivilizationManager() {
        return civilizationManager;
    }

    public PlayerManager getPlayerManager() {
        return playerManager;
    }

    public LeaderManager getLeaderManager() {
        return leaderManager;
    }

    public CapitalManager getCapitalManager() {
        return capitalManager;
    }

    public CrownManager getCrownManager() {
        return crownManager;
    }

    public AssignmentManager getAssignmentManager() {
        return assignmentManager;
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public ElectionManager getElectionManager() {
        return electionManager;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public DiplomacyManager getDiplomacyManager() {
        return diplomacyManager;
    }

    public ChatManager getChatManager() {
        return chatManager;
    }

    public StatisticsManager getStatisticsManager() {
        return statisticsManager;
    }

    public DiscordIntegrationManager getDiscordIntegrationManager() {
        return discordIntegrationManager;
    }

    public WeaponManager getWeaponManager() {
        return weaponManager;
    }

    public WarManager getWarManager() {
        return warManager;
    }

    public EventManager getEventManager() {
        return eventManager;
    }

    public SeasonManager getSeasonManager() {
        return seasonManager;
    }

    public TerritoryManager getTerritoryManager() {
        return territoryManager;
    }
}
