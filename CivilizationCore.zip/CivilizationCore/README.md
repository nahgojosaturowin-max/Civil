# CivilizationCore

A Paper plugin (targeting Paper **26.2**, JDK 25) implementing the full
CivilizationCore PRD: Part 1 (civilizations, leaders, crowns, capitals),
Part 2 (elections, economy/treasury, diplomacy, chat, statistics), and
Part 3 (Legendary Weapons, wars, events, seasons).

## Getting a build jar (no local setup required)

This repo includes `.github/workflows/build.yml`, which builds the plugin
with JDK 25 + Maven on every push and attaches the resulting jar as a
downloadable artifact.

1. Push this repository to GitHub (create a new repo, then
   `git init && git add . && git commit -m "init" && git remote add origin <your-repo-url> && git push -u origin main`).
2. Open the **Actions** tab on GitHub - the workflow runs automatically.
   If it doesn't, click **Run workflow** (workflow_dispatch is enabled).
3. Once the run finishes (green check), open it and download the
   **CivilizationCore-jar** artifact from the run summary page. That zip
   contains the built `.jar` - drop it straight into your server's
   `plugins/` folder.

No local Java or Maven installation is needed for this path.

## Building locally instead

Requirements: JDK 25, Maven 3.9+, internet access (to pull the Paper API,
SQLite driver, and the optional Vault/DiscordSRV dependencies).

```bash
mvn package
```

The built jar will be at `target/CivilizationCore.jar`.

## Notes

- Vault and DiscordSRV are **soft dependencies** - the plugin works fully
  without them installed; only `/civ deposit|withdraw` (needs Vault) and
  Discord announcements (needs DiscordSRV) are disabled if they're absent.
- Default storage is SQLite, created automatically in the plugin's data
  folder on first run.
- See `src/main/resources/config.yml` for every configurable option
  (civilizations, elections, economy/tax, diplomacy, chat, weapons, wars,
  events, seasons, notifications).
